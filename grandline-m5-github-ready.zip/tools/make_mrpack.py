#!/usr/bin/env python3
"""
Builds a Modrinth modpack (.mrpack) from the mod jar you just built.

  ./gradlew build
  python3 tools/make_mrpack.py

Output: build/mrpack/grandline-<version>.mrpack
Import it in the Modrinth App (Add instance > From file) or any launcher that supports .mrpack.
It creates a Minecraft + NeoForge instance with the mod already inside.

Anything in the folder  mrpack-overrides/  is copied into the instance (for example
mrpack-overrides/config/grandline-common.toml to ship default settings).
"""
import json
import sys
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parent.parent

props = {}
for line in (root / "gradle.properties").read_text(encoding="utf-8").splitlines():
    line = line.strip()
    if line and not line.startswith("#") and "=" in line:
        key, value = line.split("=", 1)
        props[key.strip()] = value.strip()

mod_id = props["mod_id"]
version = props["mod_version"]
jar = root / "build" / "libs" / f"{mod_id}-{version}.jar"
if not jar.exists():
    sys.exit(f"Mod jar not found: {jar}\nBuild it first with: ./gradlew build")

index = {
    "formatVersion": 1,
    "game": "minecraft",
    "versionId": version,
    "name": props["mod_name"],
    "summary": "A One Piece RPG sandbox: Devil Fruits, Haki, abilities and cutscenes.",
    "files": [],
    "dependencies": {
        "minecraft": props["minecraft_version"],
        "neoforge": props["neo_version"],
    },
}

out_dir = root / "build" / "mrpack"
out_dir.mkdir(parents=True, exist_ok=True)
out = out_dir / f"{mod_id}-{version}.mrpack"

with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as pack:
    pack.writestr("modrinth.index.json", json.dumps(index, indent=2))
    pack.write(jar, f"overrides/mods/{jar.name}")
    extra = root / "mrpack-overrides"
    if extra.is_dir():
        for path in sorted(extra.rglob("*")):
            if path.is_file():
                pack.write(path, "overrides/" + path.relative_to(extra).as_posix())

print(f"Wrote {out}")
