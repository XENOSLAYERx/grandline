# One Piece: Grand Line: controls and commands (v0.5.0)

## 1. Keys

All keys can be changed in **Options > Controls > One Piece: Grand Line**.

| Key | What it does |
|---|---|
| **Z X C V G** | Ability slots 1 to 5. What they do depends on your fruit (section 3). |
| **N** | Observation Haki (toggle) |
| **B** | Armament Haki (toggle) |
| **J** | Advanced Armament (hold, then release) |
| **M** | Conqueror's Haki (press) |
| **Backspace** | Skip a cutscene |
| **Right-click (hold)** | Eat a Devil Fruit item |

How the four kinds of ability respond to a key:

- **Press**: tap once, it fires.
- **Toggle**: tap to turn on, tap again to turn off. It drains energy every second while on.
- **Hold**: active only while the key is held. It drains energy every second.
- **Charge**: hold to charge, release to fire. Longer = stronger. Releasing too early does nothing.

The HUD (bottom right) shows a blue **stamina** bar, a purple **Haki** bar, the Haki keys you have unlocked and your five slots. Green = on, red = cooling down, fill bar = charging.

## 2. Getting started in 30 seconds

1. Make yourself a Creator (see section 7), or play singleplayer (the world owner is a Creator automatically).
2. `/onepiece fruit give leopard` (or `gum`, `mera`)
3. `/onepiece mastery max` (so every ability is usable)
4. `/onepiece haki unlock all` (to use Haki)
5. Press Z, X, C, V, G, and N, B, J, M.

## 3. Abilities by fruit

Slot order = Z X C V G. Costs are stamina, or Haki energy for Haki.

**Gum-Gum Fruit (Paramecia)**: no fall damage, immune to lightning.

| Key | Ability | Type | Cost | Cooldown | Needs |
|---|---|---|---|---|---|
| Z | Pistol | press | 12 | 0.7 s | none |
| X | Rocket | press | 10 | 2 s | none |
| C | Balloon | toggle, 5/s | 10 | 2 s | fruit mastery 15 |
| V | Bazooka | charge 0.4-1.5 s | 28 | 4 s | fruit mastery 30 |
| G | Gatling | hold, 10/s | 5 | 1.5 s | fruit mastery 20 |

**Flame-Flame Fruit (Logia)**: immune to fire and lava. Flame Body lets attacks from living things pass through you; water, Armament Haki and the environment still hurt.

| Key | Ability | Type | Cost | Cooldown | Needs |
|---|---|---|---|---|---|
| Z | Flame Body | toggle, 6/s | 15 | 3 s | fruit mastery 10 |
| X | Fire Fist | charge 0.3-1.2 s | 26 | 3.5 s | fruit mastery 25 |
| C | Flame Dash | press | 14 | 2.5 s | none |
| V | Flame Jet | hold, 9/s | 4 | 1.5 s | fruit mastery 5 |

**Cat-Cat Fruit, Model: Leopard (Zoan)**: slightly faster at all times. Hybrid and Beast cannot be on together.

| Key | Ability | Type | Cost | Cooldown | Needs |
|---|---|---|---|---|---|
| Z | Hybrid | toggle, 2/s | 20 | 3 s | none |
| X | Beast | toggle, 3/s | 25 | 3 s | fruit mastery 15 |
| C | Claw | press | 10 | 0.6 s | none |
| V | Pounce | charge 0.2-0.9 s | 22 | 3.5 s | fruit mastery 20 |

**Haki** (fixed keys, Haki energy, needs the Haki level shown):

| Key | Ability | Type | Cost | Cooldown | Needs |
|---|---|---|---|---|---|
| N | Observation | toggle, 1.5/s | 6 | 1 s | Observation level 1 (Future Sight at 25) |
| B | Armament | toggle, 2/s | 8 | 1 s | Armament level 1 |
| J | Advanced Armament | charge 0.3-1 s | 30 | 6 s | Armament level 60 and Armament toggle on |
| M | Conqueror's | press | 40 | 15 s | Conqueror's level 1 |

**Test kit** (`/onepiece test`): Z Shockwave (press), X Aura (toggle), C Guard (hold), V Dash (charge). Shockwave needs Rokushiki mastery 10.

**Awakening**: unlocks automatically when fruit mastery reaches 100 (mastery rises as you use fruit abilities), or with `/onepiece fruit awaken`.

## 4. Commands

Everything starts with `/onepiece`. Permission tiers: PLAYER, MODERATOR, ADMIN, CREATOR (see section 7). Tab-complete works everywhere.

### Everyone (PLAYER)
| Command | What it does |
|---|---|
| `/onepiece` or `/onepiece help [command]` | Lists the commands you can use, or explains one. |
| `/onepiece ability list` | Every ability, whether you have it, and which slot it is on. |
| `/onepiece ability status` | Your stamina, Haki, cooldowns and slots. |
| `/onepiece ability equip <slot 1-5> <ability>` | Puts an unlocked ability on a key. |
| `/onepiece ability unequip <slot 1-5>` | Empties a slot. |

### Moderator and above
| Command | What it does |
|---|---|
| `/onepiece debug` | Versions, your tier, side, registries. |
| `/onepiece debug permissions` | Why you have your tier, and your UUID. |
| `/onepiece debug config` | Current config values. |
| `/onepiece debug registries` | Registered content counts. |
| `/onepiece debug data [player]` | A player's saved data (server copy) with a checksum. |

### Creator
| Command | What it does |
|---|---|
| `/onepiece test` | Gives you the four test abilities on slots 1-4 and Rokushiki mastery 10. |
| `/onepiece fruit give <fruit>` | Gives you the fruit's power directly (no item). Fruits: `gum`, `mera`, `leopard`. |
| `/onepiece fruit remove` | Removes your fruit and its effects. |
| `/onepiece fruit awaken` | Awakens your fruit. |
| `/onepiece fruit list` | Lists the fruits. |
| `/onepiece unlock fruits` | Unlocks every fruit in your data without equipping one. |
| `/onepiece transform <form>` | Turns a body form on or off with no cost (for example `leopard_hybrid`, `leopard_beast`, `gum_balloon`, `mera_flame_body`). |
| `/onepiece ability give <ability>` | Unlocks an ability. |
| `/onepiece mastery max` | Sets fruit, style and rokushiki mastery to 100. |
| `/onepiece mastery set <fruit\|style\|rokushiki> <0-100>` | Sets one mastery. |
| `/onepiece haki set <observation\|armament\|conquerors> <0-100>` | Sets a Haki level (1+ unlocks it). |
| `/onepiece haki unlock all` | All three Haki branches to level 100. |
| `/onepiece haki infinite` | Toggles infinite Haki energy. |
| `/onepiece stamina infinite` | Toggles infinite stamina. |
| `/onepiece cooldown reset` | Clears all your ability cooldowns. |
| `/onepiece bounty set <amount>` | Sets your bounty (0 to 100 billion). |
| `/onepiece bounty add <amount>` | Adds (or subtracts) bounty. |
| `/onepiece bounty reset` | Bounty back to 0. |
| `/onepiece cutscene play <id>` | Plays a cutscene (try `grandline:test_intro`). |
| `/onepiece cutscene stop` | Stops it. |
| `/onepiece debug data fill` | Writes test values into every data field. |
| `/onepiece debug data reset confirm` | Resets all your player data to defaults. |

### Client commands (no permission, run on your own game)
| Command | What it does |
|---|---|
| `/glclient data` | Your client copy of the player data (compare its checksum with `/onepiece debug data`). |
| `/glclient cutscene play <id>` / `stop` / `list` | Plays, stops or lists cutscenes without a server. |
| `/glclient shake [intensity]` | Tests the screen shake. |
| `/glclient vfx demo` | Plays every effect type in front of you. |

### Vanilla commands that help
- `/give @s grandline:devil_fruit_gum` (also `devil_fruit_mera`, `devil_fruit_leopard`). The creative tab is called "One Piece: Grand Line".
- `/summon zombie ~ ~ ~` to test on.

## 5. Config files

- `config/grandline-common.toml`: permissions (`creatorUuids`, op levels), `staminaMax`, `staminaRegenPerSecond`, `hakiMax`, `hakiRegenPerSecond`, `cooldownMultiplier`, `abilityCostMultiplier`, `masteryGainMultiplier`, `verboseLogging`.
- `config/grandline-client.toml`: `vfxDensity` (lower it if FPS drops), `screenShake`.

## 6. Cutscenes

Files live in `assets/grandline/cutscenes/*.json` (camera keys, subtitles, fades). Press **F3 + T** to reload them while editing. Positions are relative to where you stand.

## 7. Becoming a Creator

You are a Creator if any one of these is true:
- you own a singleplayer world (default on),
- your UUID is in `creatorUuids` in `grandline-common.toml` (run `/onepiece debug permissions` to see your UUID),
- you are a server operator (op level 4 = Creator, 3 = Admin, 2 = Moderator).
