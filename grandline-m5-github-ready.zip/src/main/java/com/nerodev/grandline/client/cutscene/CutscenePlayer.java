package com.nerodev.grandline.client.cutscene;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.phys.Vec3;

/**
 * Plays a Cutscene on this client. The camera is a detached armor stand that never joins the
 * world: the game renders from it exactly like spectating, and moves smoothly between ticks.
 * While a cutscene plays, ClientEvents blocks movement, attacking and the vanilla HUD, and
 * CutsceneOverlay draws the letterbox, fades and subtitles. The player can be hurt during a
 * cutscene; use them in safe moments until the server-side freeze arrives with the boss milestone.
 */
public final class CutscenePlayer {

    private static Cutscene current = null;
    private static int tick = 0;
    private static ArmorStand camera = null;
    private static Vec3 origin = Vec3.ZERO;
    private static float originYaw = 0.0f;
    private static float savedYaw = 0.0f;
    private static float savedPitch = 0.0f;
    private static float fovPrevious = 70.0f;
    private static float fovCurrent = 70.0f;

    public static boolean isPlaying() {
        return current != null;
    }

    public static Cutscene current() {
        return current;
    }

    public static int tick() {
        return tick;
    }

    public static float fov(float partialTick) {
        return Mth.lerp(partialTick, fovPrevious, fovCurrent);
    }

    public static void start(ResourceLocation id) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || minecraft.level == null) {
            return;
        }
        Cutscene cutscene = CutsceneLoader.get(id);
        if (cutscene == null) {
            minecraft.player.displayClientMessage(Component.literal("Unknown cutscene " + id
                    + ". Known: " + CutsceneLoader.ids()), false);
            return;
        }
        if (isPlaying()) {
            stop();
        }

        current = cutscene;
        tick = 0;
        origin = minecraft.player.position();
        originYaw = minecraft.player.getYRot();
        savedYaw = minecraft.player.getYRot();
        savedPitch = minecraft.player.getXRot();
        camera = new ArmorStand(EntityType.ARMOR_STAND, minecraft.level);
        applyFrame(true);
        minecraft.setCameraEntity(camera);
    }

    /** Ends the cutscene and gives the camera and view direction back to the player. */
    public static void stop() {
        if (current == null) {
            return;
        }
        current = null;
        camera = null;
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null) {
            minecraft.setCameraEntity(minecraft.player);
            minecraft.player.setYRot(savedYaw);
            minecraft.player.setXRot(savedPitch);
        }
    }

    /** Forget everything without touching the game (used when disconnecting). */
    public static void reset() {
        current = null;
        camera = null;
    }

    public static void skip() {
        if (current != null && current.skippable()) {
            stop();
        }
    }

    public static void tickClient() {
        if (current == null) {
            return;
        }
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || minecraft.level == null || !minecraft.player.isAlive()) {
            stop();
            return;
        }
        tick++;
        if (tick > current.length()) {
            stop();
            return;
        }
        applyFrame(false);
    }

    private static void applyFrame(boolean snap) {
        Cutscene.Frame frame = current.sample(tick);

        double radians = Math.toRadians(originYaw);
        double cos = Math.cos(radians);
        double sin = Math.sin(radians);
        // player's right = (-cos, -sin), player's forward = (-sin, cos) in world (x, z)
        double x = origin.x + (-cos) * frame.pos().x + (-sin) * frame.pos().z;
        double y = origin.y + frame.pos().y;
        double z = origin.z + (-sin) * frame.pos().x + cos * frame.pos().z;

        if (!snap) {
            rememberOld();
        }
        camera.setPos(x, y - camera.getEyeHeight(), z);
        camera.setYRot(originYaw + frame.yaw());
        camera.setXRot(frame.pitch());
        if (snap) {
            rememberOld();
        }

        fovPrevious = snap ? frame.fov() : fovCurrent;
        fovCurrent = frame.fov();
    }

    // The game interpolates the camera between the "old" and current values every frame.
    private static void rememberOld() {
        camera.xo = camera.getX();
        camera.yo = camera.getY();
        camera.zo = camera.getZ();
        camera.xRotO = camera.getXRot();
        camera.yRotO = camera.getYRot();
    }

    private CutscenePlayer() {
    }
}
