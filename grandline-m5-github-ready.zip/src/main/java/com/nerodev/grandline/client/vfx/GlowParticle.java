package com.nerodev.grandline.client.vfx;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.util.Mth;

/**
 * The one particle behind all Grand Line effects. Full-bright (ignores world light so it glows at
 * night and in caves), tinted by an RGB colour, grows from startSize to endSize and fades out.
 * Created directly by ClientVfx so each effect can pick its own colour, size and lifetime.
 */
public final class GlowParticle extends TextureSheetParticle {

    private static final int FULL_BRIGHT = 15728880;

    private final float startSize;
    private final float endSize;

    public GlowParticle(ClientLevel level, SpriteSet sprites,
                        double x, double y, double z,
                        double vx, double vy, double vz,
                        int rgb, float startSize, float endSize,
                        int life, float gravity, float drag) {
        super(level, x, y, z);
        this.pickSprite(sprites);
        this.xd = vx;
        this.yd = vy;
        this.zd = vz;
        this.rCol = ((rgb >> 16) & 0xFF) / 255.0f;
        this.gCol = ((rgb >> 8) & 0xFF) / 255.0f;
        this.bCol = (rgb & 0xFF) / 255.0f;
        this.alpha = 1.0f;
        this.startSize = startSize;
        this.endSize = endSize;
        this.quadSize = startSize;
        this.lifetime = Math.max(1, life);
        this.gravity = gravity;
        this.friction = drag;
        this.hasPhysics = false;
    }

    @Override
    public void tick() {
        super.tick();
        float t = this.age / (float) this.lifetime;
        this.alpha = Mth.clamp(1.0f - t * t, 0.0f, 1.0f);
    }

    @Override
    public float getQuadSize(float partialTick) {
        float t = Mth.clamp((this.age + partialTick) / this.lifetime, 0.0f, 1.0f);
        return Mth.lerp(t, startSize, endSize);
    }

    @Override
    protected int getLightColor(float partialTick) {
        return FULL_BRIGHT;
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }
}
