package com.nerodev.grandline.client.cutscene;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.mojang.serialization.JsonOps;
import com.nerodev.grandline.GrandLineMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/** Loads every assets/<namespace>/cutscenes/*.json on resource (re)load. Press F3+T to reload while editing. */
public final class CutsceneLoader extends SimpleJsonResourceReloadListener {

    private static final Map<ResourceLocation, Cutscene> CUTSCENES = new HashMap<>();

    public CutsceneLoader() {
        super(new Gson(), "cutscenes");
    }

    @Override
    protected void apply(Map<ResourceLocation, JsonElement> objects, ResourceManager resourceManager, ProfilerFiller profiler) {
        CUTSCENES.clear();
        objects.forEach((id, json) -> Cutscene.CODEC.parse(JsonOps.INSTANCE, json)
                .resultOrPartial(message -> GrandLineMod.LOGGER.error("[GrandLine] Bad cutscene {}: {}", id, message))
                .filter(cutscene -> !cutscene.keys().isEmpty())
                .ifPresent(cutscene -> CUTSCENES.put(id, cutscene)));
        GrandLineMod.LOGGER.info("[GrandLine] Loaded {} cutscene(s)", CUTSCENES.size());
    }

    public static Cutscene get(ResourceLocation id) {
        return CUTSCENES.get(id);
    }

    public static Set<ResourceLocation> ids() {
        return Set.copyOf(CUTSCENES.keySet());
    }
}
