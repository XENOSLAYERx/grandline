package com.nerodev.grandline.client;

import com.nerodev.grandline.haki.HakiSlots;

/** Which ability keys the client has told the server are held, and since when (for the charge bar). */
public final class ClientInputState {

    private static final boolean[] SENT = new boolean[HakiSlots.TOTAL_KEYS];
    private static final long[] SINCE = new long[HakiSlots.TOTAL_KEYS];

    public static boolean isSent(int slot) {
        return SENT[slot];
    }

    public static void markPressed(int slot, long gameTime) {
        SENT[slot] = true;
        SINCE[slot] = gameTime;
    }

    public static void markReleased(int slot) {
        SENT[slot] = false;
    }

    public static long heldTicks(int slot, long now) {
        return SENT[slot] ? Math.max(0L, now - SINCE[slot]) : 0L;
    }

    public static void reset() {
        for (int i = 0; i < HakiSlots.TOTAL_KEYS; i++) {
            SENT[i] = false;
        }
    }

    private ClientInputState() {
    }
}
