package com.nerodev.grandline.client;

import com.nerodev.grandline.GrandLineMod;
import com.nerodev.grandline.haki.ObservationCache;
import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.LayeredDraw;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.phys.Vec3;

/**
 * Observation Haki markers. Each presence the server reported is projected onto your screen, so it
 * shows through walls; if it is off-screen (or behind you) the marker sits on the screen edge in its
 * direction. Red = hostile creature, white = player. Cheap: a few small rectangles, no particles.
 */
public final class ObservationOverlay implements LayeredDraw.Layer {

    public static final ResourceLocation ID = GrandLineMod.id("observation_overlay");

    @Override
    public void render(GuiGraphics graphics, DeltaTracker deltaTracker) {
        Minecraft minecraft = Minecraft.getInstance();
        if (!ObservationCache.isFresh() || minecraft.level == null || minecraft.player == null || minecraft.options.hideGui) {
            return;
        }
        Camera camera = minecraft.gameRenderer.getMainCamera();
        Vec3 cameraPos = camera.getPosition();
        double yaw = Math.toRadians(camera.getYRot());
        double pitch = Math.toRadians(camera.getXRot());
        double cy = Math.cos(yaw), sy = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
        Vec3 forward = new Vec3(-sy * cp, -sp, cy * cp);
        Vec3 right = new Vec3(-cy, 0.0, -sy);
        Vec3 up = right.cross(forward);

        double tanHalf = Math.tan(Math.toRadians(minecraft.options.fov().get()) / 2.0);
        int width = graphics.guiWidth();
        int height = graphics.guiHeight();
        double aspect = (double) width / height;

        for (int id : ObservationCache.ids()) {
            Entity entity = minecraft.level.getEntity(id);
            if (entity == null || entity == minecraft.player) {
                continue;
            }
            Vec3 to = entity.getBoundingBox().getCenter().subtract(cameraPos);
            double dz = to.dot(forward);
            double dx = to.dot(right);
            double dy = to.dot(up);

            double x = 0.0;
            double y = 0.0;
            boolean onScreen = dz > 0.2;
            if (onScreen) {
                x = width / 2.0 * (1.0 + dx / (dz * tanHalf * aspect));
                y = height / 2.0 * (1.0 - dy / (dz * tanHalf));
                onScreen = x > 8 && x < width - 8 && y > 8 && y < height - 8;
            }
            if (!onScreen) {
                double length = Math.hypot(dx, dy);
                if (length < 1.0e-4) {
                    continue;
                }
                double ux = dx / length;
                double uy = dy / length;
                double margin = 14.0;
                double scale = Math.min((width / 2.0 - margin) / Math.max(1.0e-4, Math.abs(ux)),
                        (height / 2.0 - margin) / Math.max(1.0e-4, Math.abs(uy)));
                x = width / 2.0 + ux * scale;
                y = height / 2.0 - uy * scale;
            }

            int color = entity instanceof Enemy ? 0xFFFF4040 : 0xFFEAF4FF;
            int arm = onScreen ? 4 : 3;
            int px = (int) x;
            int py = (int) y;
            graphics.fill(px - 1, py - arm, px + 1, py + arm, color);
            graphics.fill(px - arm, py - 1, px + arm, py + 1, color);
            if (onScreen) {
                String distance = (int) Math.sqrt(minecraft.player.distanceToSqr(entity)) + "m";
                graphics.drawString(minecraft.font, distance, px + 6, py - 4, color, true);
            }
        }
    }
}
