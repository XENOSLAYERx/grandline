package com.nerodev.grandline.client;

import com.nerodev.grandline.GrandLineMod;
import com.nerodev.grandline.ability.Ability;
import com.nerodev.grandline.ability.AbilityView;
import com.nerodev.grandline.ability.AbilityViewCache;
import com.nerodev.grandline.ability.ActivationType;
import com.nerodev.grandline.ability.ClientActiveVisuals;
import com.nerodev.grandline.ability.GLAbilities;
import com.nerodev.grandline.data.AbilitySlots;
import com.nerodev.grandline.data.GLPlayerData;
import com.nerodev.grandline.data.PlayerData;
import com.nerodev.grandline.haki.HakiSlots;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.LayeredDraw;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

import java.util.List;
import java.util.Locale;
import java.util.Optional;

/**
 * Bottom-right HUD: stamina bar (blue), Haki bar (purple), a Haki key row for the Haki you have
 * unlocked, and the five ability slots. A green box is an ability that is on (toggle or hold), a red
 * box is cooling down, and a charge ability shows a fill bar while you hold its key. Reads synced
 * data only; bars and cooldowns are extrapolated from the last snapshot, so nothing is sent per tick.
 */
public final class AbilityHud implements LayeredDraw.Layer {

    public static final ResourceLocation ID = GrandLineMod.id("ability_hud");

    private static final int SLOT_W = 52;
    private static final int SLOT_H = 24;
    private static final int HAKI_H = 18;
    private static final int GAP = 2;

    @Override
    public void render(GuiGraphics graphics, DeltaTracker deltaTracker) {
        Minecraft minecraft = Minecraft.getInstance();
        LocalPlayer player = minecraft.player;
        if (player == null || minecraft.level == null || minecraft.options.hideGui) {
            return;
        }

        PlayerData data = GLPlayerData.get(player);
        AbilitySlots slots = data.abilitySlots();
        boolean anyEquipped = false;
        for (int i = 0; i < AbilitySlots.COUNT; i++) {
            if (slots.get(i).isPresent()) {
                anyEquipped = true;
            }
        }
        boolean anyHaki = false;
        for (ResourceLocation id : HakiSlots.ABILITIES) {
            Optional<Ability> ability = GLAbilities.REGISTRY.getOptional(id);
            if (ability.isPresent() && ability.get().isUnlocked(data)) {
                anyHaki = true;
            }
        }
        if (!anyEquipped && !anyHaki) {
            return;
        }

        AbilityView view = AbilityViewCache.get();
        List<ResourceLocation> active = ClientActiveVisuals.get(player.getId());
        long now = minecraft.level.getGameTime();
        Font font = minecraft.font;

        int totalWidth = AbilitySlots.COUNT * SLOT_W + (AbilitySlots.COUNT - 1) * GAP;
        int x0 = graphics.guiWidth() - totalWidth - 6;
        int y0 = graphics.guiHeight() - SLOT_H - 6;

        if (view != null) {
            bar(graphics, x0, y0 - 8, totalWidth, view.max() > 0 ? view.staminaAt(now) / view.max() : 0.0,
                    view.infinite() ? 0xFFD4AF37 : 0xFF3FA7D6);
            if (anyHaki && view.hakiMax() > 0) {
                bar(graphics, x0, y0 - 14, totalWidth, view.hakiAt(now) / view.hakiMax(),
                        view.infiniteHaki() ? 0xFFD4AF37 : 0xFF8A5CD6);
            }
        }

        // Haki row: only the Haki you have unlocked
        if (anyHaki) {
            int column = 0;
            int rowY = y0 - 14 - 4 - HAKI_H;
            for (int i = 0; i < HakiSlots.COUNT; i++) {
                ResourceLocation id = HakiSlots.ABILITIES.get(i);
                Optional<Ability> ability = GLAbilities.REGISTRY.getOptional(id);
                if (ability.isEmpty() || !ability.get().isUnlocked(data)) {
                    continue;
                }
                int key = AbilitySlots.COUNT + i;
                box(graphics, font, x0 + column * (SLOT_W + GAP), rowY, SLOT_W, HAKI_H,
                        ClientKeys.keyFor(key).getTranslatedKeyMessage().getString(), ability.get(), id,
                        false, active.contains(id), view == null ? 0L : view.cooldownRemaining(id, now),
                        key, now);
                column++;
            }
        }

        // The five ability slots
        if (anyEquipped) {
            for (int i = 0; i < AbilitySlots.COUNT; i++) {
                Optional<ResourceLocation> slot = slots.get(i);
                int x = x0 + i * (SLOT_W + GAP);
                if (slot.isEmpty()) {
                    graphics.fill(x, y0, x + SLOT_W, y0 + SLOT_H, 0x55000000);
                    graphics.drawString(font, ClientKeys.keyFor(i).getTranslatedKeyMessage(), x + 3, y0 + 3, 0xFFFFFFFF, true);
                    continue;
                }
                ResourceLocation id = slot.get();
                Optional<Ability> ability = GLAbilities.REGISTRY.getOptional(id);
                boolean locked = !data.unlocks().abilities().contains(id);
                box(graphics, font, x, y0, SLOT_W, SLOT_H,
                        ClientKeys.keyFor(i).getTranslatedKeyMessage().getString(), ability.orElse(null), id,
                        locked, active.contains(id), view == null ? 0L : view.cooldownRemaining(id, now), i, now);
            }
        }
    }

    private static void bar(GuiGraphics graphics, int x, int y, int width, double fraction, int color) {
        double f = Mth.clamp(fraction, 0.0, 1.0);
        graphics.fill(x, y, x + width, y + 5, 0xAA000000);
        graphics.fill(x, y, x + (int) (width * f), y + 5, color);
    }

    private static void box(GuiGraphics graphics, Font font, int x, int y, int width, int height,
                            String keyName, Ability ability, ResourceLocation id,
                            boolean locked, boolean isActive, long remaining, int keyIndex, long now) {
        int background;
        if (isActive) {
            background = 0xAA1F6B33;
        } else if (remaining > 0) {
            background = 0xAA7A1F1F;
        } else {
            background = 0xAA000000;
        }
        graphics.fill(x, y, x + width, y + height, background);
        graphics.drawString(font, keyName, x + 3, y + 3, 0xFFFFFFFF, true);

        String name = ability != null ? ability.displayName().getString() : id.getPath();
        int nameY = height >= SLOT_H ? y + 13 : y + 3;
        int nameX = height >= SLOT_H ? x + 3 : x + 3 + font.width(keyName) + 4;
        graphics.drawString(font, font.plainSubstrByWidth(name, width - (nameX - x) - 3), nameX, nameY,
                locked ? 0xFF888888 : 0xFFE0E0E0, true);

        if (remaining > 0) {
            String text = String.format(Locale.ROOT, "%.1f", remaining / 20.0);
            graphics.drawString(font, text, x + width - 3 - font.width(text), y + 3, 0xFFFFD27F, true);
        }
        if (ability != null && ability.activation() == ActivationType.CHARGE && ClientInputState.isSent(keyIndex)) {
            float charge = Mth.clamp(ClientInputState.heldTicks(keyIndex, now)
                    / (float) Math.max(1, ability.maxChargeTicks()), 0.0f, 1.0f);
            graphics.fill(x, y + height - 3, x + (int) (width * charge), y + height,
                    charge >= 1.0f ? 0xFFFFE066 : 0xFFFF7A3D);
        }
    }
}
