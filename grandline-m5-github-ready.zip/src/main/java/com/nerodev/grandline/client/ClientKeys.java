package com.nerodev.grandline.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.nerodev.grandline.data.AbilitySlots;
import com.nerodev.grandline.haki.HakiSlots;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

/**
 * Keybinds, all remappable in Options > Controls under "One Piece: Grand Line".
 * Abilities Z X C V G, Haki N (Observation) B (Armament) J (Advanced Armament) M (Conqueror's),
 * Backspace skips a cutscene.
 */
public final class ClientKeys {

    private static final int[] DEFAULT_KEYS = {
            GLFW.GLFW_KEY_Z, GLFW.GLFW_KEY_X, GLFW.GLFW_KEY_C, GLFW.GLFW_KEY_V, GLFW.GLFW_KEY_G
    };
    private static final int[] HAKI_DEFAULTS = {
            GLFW.GLFW_KEY_N, GLFW.GLFW_KEY_B, GLFW.GLFW_KEY_J, GLFW.GLFW_KEY_M
    };
    private static final String[] HAKI_NAMES = {"observation", "armament", "armament_advanced", "conquerors"};

    public static final KeyMapping[] ABILITY_KEYS = new KeyMapping[AbilitySlots.COUNT];
    public static final KeyMapping[] HAKI_KEYS = new KeyMapping[HakiSlots.COUNT];

    public static final KeyMapping SKIP_CUTSCENE = new KeyMapping(
            "key.grandline.skip_cutscene",
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_BACKSPACE,
            "key.categories.grandline");

    static {
        for (int i = 0; i < AbilitySlots.COUNT; i++) {
            ABILITY_KEYS[i] = new KeyMapping(
                    "key.grandline.ability_" + (i + 1),
                    InputConstants.Type.KEYSYM,
                    DEFAULT_KEYS[i],
                    "key.categories.grandline");
        }
        for (int i = 0; i < HakiSlots.COUNT; i++) {
            HAKI_KEYS[i] = new KeyMapping(
                    "key.grandline.haki_" + HAKI_NAMES[i],
                    InputConstants.Type.KEYSYM,
                    HAKI_DEFAULTS[i],
                    "key.categories.grandline");
        }
    }

    /** Key index 0..4 = ability slots, 5..8 = Haki keys (same numbering the server uses). */
    public static KeyMapping keyFor(int index) {
        return index < AbilitySlots.COUNT ? ABILITY_KEYS[index] : HAKI_KEYS[index - AbilitySlots.COUNT];
    }

    private ClientKeys() {
    }
}
