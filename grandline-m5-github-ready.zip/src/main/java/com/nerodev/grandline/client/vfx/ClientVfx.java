package com.nerodev.grandline.client.vfx;

import com.nerodev.grandline.config.GLClientConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Map;

/**
 * Client-only effect toolkit. Abilities describe their visuals with a few calls (ring, burst,
 * sparks, shockwave, rise) and a colour. Every count is multiplied by the player's vfxDensity
 * setting, so effects can be turned down without touching any ability.
 *
 * Only call this from client hooks (Ability.clientEffects / clientTick). Calls with a non-client
 * level do nothing.
 */
public final class ClientVfx {

    private static final Map<String, SpriteSet> SPRITES = new HashMap<>();

    /** Called by the particle provider registration for each sprite set. */
    public static void registerSprites(String name, SpriteSet sprites) {
        SPRITES.put(name, sprites);
    }

    private static ClientLevel clientLevel(Level level) {
        return level instanceof ClientLevel client ? client : null;
    }

    private static int scaled(int count) {
        return Math.max(0, Math.round(count * GLClientConfig.vfxDensity()));
    }

    private static void spawn(ClientLevel level, String sprite,
                              double x, double y, double z,
                              double vx, double vy, double vz,
                              int rgb, float startSize, float endSize,
                              int life, float gravity, float drag) {
        SpriteSet sprites = SPRITES.get(sprite);
        if (sprites == null) {
            return;
        }
        Minecraft.getInstance().particleEngine.add(
                new GlowParticle(level, sprites, x, y, z, vx, vy, vz, rgb, startSize, endSize, life, gravity, drag));
    }

    /** Glowing dots flying out in every direction. */
    public static void burst(Level level, double x, double y, double z,
                             int count, int rgb, float speed, float size, int life) {
        ClientLevel client = clientLevel(level);
        if (client == null) {
            return;
        }
        RandomSource random = client.random;
        int n = scaled(count);
        for (int i = 0; i < n; i++) {
            double theta = random.nextDouble() * Math.PI * 2.0;
            double v = random.nextDouble() * 2.0 - 1.0;
            double s = Math.sqrt(1.0 - v * v);
            double velocity = speed * (0.5 + random.nextDouble() * 0.5);
            float particleSize = size * (0.7f + random.nextFloat() * 0.6f);
            spawn(client, "glow", x, y, z,
                    s * Math.cos(theta) * velocity, v * velocity, s * Math.sin(theta) * velocity,
                    rgb, particleSize, particleSize * 1.3f, life + random.nextInt(4), 0.0f, 0.9f);
        }
    }

    /** Dots on a flat circle moving outward (outSpeed 0 = a ring that stays and fades). */
    public static void ring(Level level, double x, double y, double z,
                            float radius, int points, int rgb, float outSpeed, float size, int life) {
        ClientLevel client = clientLevel(level);
        if (client == null) {
            return;
        }
        int n = Math.max(3, scaled(points));
        for (int i = 0; i < n; i++) {
            double angle = i * (Math.PI * 2.0 / n);
            double cos = Math.cos(angle);
            double sin = Math.sin(angle);
            spawn(client, "glow",
                    x + cos * radius, y, z + sin * radius,
                    cos * outSpeed, 0.0, sin * outSpeed,
                    rgb, size, size * 0.6f, life, 0.0f, 0.92f);
        }
    }

    /** Small bright stars that fly out and fall a little. */
    public static void sparks(Level level, double x, double y, double z, int count, int rgb, float speed) {
        ClientLevel client = clientLevel(level);
        if (client == null) {
            return;
        }
        RandomSource random = client.random;
        int n = scaled(count);
        for (int i = 0; i < n; i++) {
            double theta = random.nextDouble() * Math.PI * 2.0;
            double up = random.nextDouble() * 0.9;
            double velocity = speed * (0.5 + random.nextDouble() * 0.5);
            spawn(client, "spark", x, y, z,
                    Math.cos(theta) * velocity, up * velocity + 0.05, Math.sin(theta) * velocity,
                    rgb, 0.22f, 0.05f, 10 + random.nextInt(6), 0.15f, 0.9f);
        }
    }

    /** One big ring sprite that expands quickly. Always faces the camera. */
    public static void shockwave(Level level, double x, double y, double z,
                                 int rgb, float startSize, float endSize, int life) {
        ClientLevel client = clientLevel(level);
        if (client == null || GLClientConfig.vfxDensity() <= 0.0f) {
            return;
        }
        spawn(client, "ring", x, y, z, 0.0, 0.0, 0.0, rgb, startSize, endSize, life, 0.0f, 1.0f);
    }

    /** A crescent sprite (camera-facing). Ready for combat slashes. */
    public static void slash(Level level, double x, double y, double z, int rgb, float size, int life) {
        ClientLevel client = clientLevel(level);
        if (client == null || GLClientConfig.vfxDensity() <= 0.0f) {
            return;
        }
        spawn(client, "slash", x, y, z, 0.0, 0.0, 0.0, rgb, size, size * 1.25f, life, 0.0f, 1.0f);
    }

    /** Soft dots drifting upward around an entity. For auras: call every few ticks with a small count. */
    public static void rise(Level level, Entity entity, int rgb, int count) {
        ClientLevel client = clientLevel(level);
        if (client == null) {
            return;
        }
        RandomSource random = client.random;
        int n = scaled(count);
        for (int i = 0; i < n; i++) {
            double x = entity.getX() + (random.nextDouble() - 0.5) * entity.getBbWidth() * 1.4;
            double y = entity.getY() + random.nextDouble() * entity.getBbHeight();
            double z = entity.getZ() + (random.nextDouble() - 0.5) * entity.getBbWidth() * 1.4;
            spawn(client, "glow", x, y, z,
                    0.0, 0.04 + random.nextDouble() * 0.04, 0.0,
                    rgb, 0.18f, 0.05f, 18, 0.0f, 0.96f);
        }
    }

    /** Glowing dots along a straight line (a stretched arm, a beam). */
    public static void line(Level level, Vec3 from, Vec3 to, int rgb, int points, float size) {
        ClientLevel client = clientLevel(level);
        if (client == null) {
            return;
        }
        int n = Math.max(2, scaled(points));
        for (int i = 0; i < n; i++) {
            Vec3 p = from.lerp(to, i / (n - 1.0));
            spawn(client, "glow", p.x, p.y, p.z, 0.0, 0.0, 0.0, rgb, size, size * 0.4f, 7, 0.0f, 1.0f);
        }
    }

    /** A jagged bolt from one point to another, built from short straight pieces. */
    public static void lightning(Level level, Vec3 from, Vec3 to, int rgb, int segments, double jag, float size) {
        ClientLevel client = clientLevel(level);
        if (client == null) {
            return;
        }
        RandomSource random = client.random;
        int n = Math.max(2, segments);
        Vec3 previous = from;
        for (int i = 1; i <= n; i++) {
            Vec3 point = from.lerp(to, i / (double) n);
            if (i < n) {
                point = point.add((random.nextDouble() - 0.5) * jag, (random.nextDouble() - 0.5) * jag,
                        (random.nextDouble() - 0.5) * jag);
            }
            line(level, previous, point, rgb, 6, size);
            previous = point;
        }
    }

    /** A stream of dots shot along a direction with some spread, drifting upward like flame. */
    public static void stream(Level level, Vec3 origin, Vec3 direction, double spread,
                              int count, int rgb, float speed, float size, int life) {
        ClientLevel client = clientLevel(level);
        if (client == null) {
            return;
        }
        RandomSource random = client.random;
        int n = scaled(count);
        for (int i = 0; i < n; i++) {
            Vec3 d = direction.add((random.nextDouble() - 0.5) * spread,
                    (random.nextDouble() - 0.5) * spread, (random.nextDouble() - 0.5) * spread)
                    .normalize().scale(speed * (0.6 + 0.8 * random.nextDouble()));
            spawn(client, "glow", origin.x, origin.y, origin.z, d.x, d.y, d.z,
                    rgb, size, size * 1.6f, life, -0.02f, 0.94f);
        }
    }

    /** Shakes the screen, but only if the entity is the local player. */
    public static void localShake(Entity entity, float intensity, int ticks) {
        if (entity == Minecraft.getInstance().player) {
            CameraEffects.shake(intensity, ticks);
        }
    }

    /** Quick zoom-out punch, but only if the entity is the local player. */
    public static void localFovPunch(Entity entity, float degrees, int ticks) {
        if (entity == Minecraft.getInstance().player) {
            CameraEffects.fovPunch(degrees, ticks);
        }
    }

    private ClientVfx() {
    }
}
