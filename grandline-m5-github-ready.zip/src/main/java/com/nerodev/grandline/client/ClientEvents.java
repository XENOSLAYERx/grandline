package com.nerodev.grandline.client;

import com.nerodev.grandline.GrandLineMod;
import com.nerodev.grandline.ability.Ability;
import com.nerodev.grandline.ability.AbilityViewCache;
import com.nerodev.grandline.ability.ClientActiveVisuals;
import com.nerodev.grandline.ability.GLAbilities;
import com.nerodev.grandline.client.cutscene.CutscenePlayer;
import com.nerodev.grandline.client.vfx.CameraEffects;
import com.nerodev.grandline.haki.HakiSlots;
import com.nerodev.grandline.haki.ObservationCache;
import com.nerodev.grandline.network.AbilityInputPayload;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.Input;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.neoforge.client.event.MovementInputUpdateEvent;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;
import net.neoforged.neoforge.client.event.RenderHandEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/** Client-only game-bus events. */
@EventBusSubscriber(modid = GrandLineMod.MODID, value = Dist.CLIENT)
public final class ClientEvents {

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft minecraft = Minecraft.getInstance();
        CameraEffects.tick();
        CutscenePlayer.tickClient();
        tickActiveVisuals(minecraft);
        handleKeys(minecraft);
    }

    /**
     * One tiny packet per press and per release. The server decides what a press means; the
     * client only reports the key. A release is always sent after a press, even if a menu opens.
     */
    private static void handleKeys(Minecraft minecraft) {
        boolean canSend = minecraft.player != null
                && minecraft.level != null
                && minecraft.screen == null
                && !CutscenePlayer.isPlaying();
        long now = minecraft.level != null ? minecraft.level.getGameTime() : 0L;

        for (int slot = 0; slot < HakiSlots.TOTAL_KEYS; slot++) {
            KeyMapping key = ClientKeys.keyFor(slot);

            // Always drain queued presses so a press made inside a menu is not fired later.
            while (key.consumeClick()) {
                if (canSend && !ClientInputState.isSent(slot)) {
                    send(minecraft, slot, true);
                    ClientInputState.markPressed(slot, now);
                }
            }
            if (ClientInputState.isSent(slot) && (!canSend || !key.isDown())) {
                send(minecraft, slot, false);
                ClientInputState.markReleased(slot);
            }
        }

        while (ClientKeys.SKIP_CUTSCENE.consumeClick()) {
            CutscenePlayer.skip();
        }
    }

    private static void send(Minecraft minecraft, int slot, boolean pressed) {
        if (minecraft.getConnection() != null) {
            PacketDistributor.sendToServer(new AbilityInputPayload(slot, pressed));
        }
    }

    /** Looping visuals for abilities that are on (toggled or held), for every visible entity. */
    private static void tickActiveVisuals(Minecraft minecraft) {
        if (minecraft.level == null) {
            return;
        }
        Map<Integer, List<ResourceLocation>> all = ClientActiveVisuals.all();
        if (all.isEmpty()) {
            return;
        }
        for (Map.Entry<Integer, List<ResourceLocation>> entry : all.entrySet()) {
            Entity entity = minecraft.level.getEntity(entry.getKey());
            if (!(entity instanceof LivingEntity living) || !living.isAlive()) {
                ClientActiveVisuals.remove(entry.getKey());
                continue;
            }
            for (ResourceLocation id : entry.getValue()) {
                Optional<Ability> ability = GLAbilities.REGISTRY.getOptional(id);
                if (ability.isPresent()) {
                    ability.get().clientTick(minecraft.level, living);
                }
            }
        }
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        AbilityViewCache.clear();
        ObservationCache.clear();
        ClientActiveVisuals.clear();
        ClientInputState.reset();
        CameraEffects.clear();
        CutscenePlayer.reset();
    }

    // ---- cutscene lockdown: no movement, no attacking, no vanilla HUD, no hand ----

    @SubscribeEvent
    public static void onMovementInput(MovementInputUpdateEvent event) {
        if (!CutscenePlayer.isPlaying()) {
            return;
        }
        Input input = event.getInput();
        input.up = false;
        input.down = false;
        input.left = false;
        input.right = false;
        input.jumping = false;
        input.shiftKeyDown = false;
        input.leftImpulse = 0.0f;
        input.forwardImpulse = 0.0f;
    }

    @SubscribeEvent
    public static void onInteraction(InputEvent.InteractionKeyMappingTriggered event) {
        if (CutscenePlayer.isPlaying()) {
            event.setCanceled(true);
            event.setSwingHand(false);
        }
    }

    @SubscribeEvent
    public static void onRenderHand(RenderHandEvent event) {
        if (CutscenePlayer.isPlaying()) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onRenderGuiLayer(RenderGuiLayerEvent.Pre event) {
        if (CutscenePlayer.isPlaying() && "minecraft".equals(event.getName().getNamespace())) {
            event.setCanceled(true);
        }
    }

    // ---- camera ----

    @SubscribeEvent
    public static void onCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        CameraEffects.onComputeCameraAngles(event);
    }

    @SubscribeEvent
    public static void onComputeFov(ViewportEvent.ComputeFov event) {
        CameraEffects.onComputeFov(event);
    }

    private ClientEvents() {
    }
}
