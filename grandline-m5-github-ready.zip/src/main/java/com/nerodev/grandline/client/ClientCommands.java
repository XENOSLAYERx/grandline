package com.nerodev.grandline.client;

import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.nerodev.grandline.GrandLineMod;
import com.nerodev.grandline.client.cutscene.CutsceneLoader;
import com.nerodev.grandline.client.cutscene.CutscenePlayer;
import com.nerodev.grandline.client.vfx.CameraEffects;
import com.nerodev.grandline.client.vfx.ClientVfx;
import com.nerodev.grandline.data.GLPlayerData;
import com.nerodev.grandline.data.PlayerData;
import com.nerodev.grandline.data.PlayerDataFormat;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.ResourceLocationArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterClientCommandsEvent;

/**
 * Client-side tools, no server or permission needed. For tuning visuals fast:
 *   /glclient data                    your client copy of the player data (compare with /onepiece debug data)
 *   /glclient cutscene play|stop|list play a cutscene from assets/grandline/cutscenes
 *   /glclient shake [intensity]       test the screen shake
 *   /glclient vfx demo                play every effect type in front of you
 */
@EventBusSubscriber(modid = GrandLineMod.MODID, value = Dist.CLIENT)
public final class ClientCommands {

    private static final SuggestionProvider<CommandSourceStack> SUGGEST_CUTSCENES =
            (context, builder) -> SharedSuggestionProvider.suggestResource(CutsceneLoader.ids(), builder);

    @SubscribeEvent
    public static void onRegisterClientCommands(RegisterClientCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("glclient")
                .then(Commands.literal("data").executes(ClientCommands::showData))
                .then(Commands.literal("cutscene")
                        .then(Commands.literal("play")
                                .then(Commands.argument("id", ResourceLocationArgument.id())
                                        .suggests(SUGGEST_CUTSCENES)
                                        .executes(context -> {
                                            CutscenePlayer.start(ResourceLocationArgument.getId(context, "id"));
                                            return 1;
                                        })))
                        .then(Commands.literal("stop").executes(context -> {
                            CutscenePlayer.stop();
                            return 1;
                        }))
                        .then(Commands.literal("list").executes(context -> {
                            say(context, "Cutscenes: " + CutsceneLoader.ids());
                            return 1;
                        })))
                .then(Commands.literal("shake")
                        .executes(context -> {
                            CameraEffects.shake(1.0f, 12);
                            return 1;
                        })
                        .then(Commands.argument("intensity", FloatArgumentType.floatArg(0.0f, 5.0f))
                                .executes(context -> {
                                    CameraEffects.shake(FloatArgumentType.getFloat(context, "intensity"), 12);
                                    return 1;
                                })))
                .then(Commands.literal("vfx")
                        .then(Commands.literal("demo").executes(ClientCommands::vfxDemo))));
    }

    private static int showData(CommandContext<CommandSourceStack> context) {
        LocalPlayer player = Minecraft.getInstance().player;
        if (player == null) {
            context.getSource().sendFailure(Component.literal("No local player."));
            return 0;
        }
        PlayerData data = GLPlayerData.get(player);
        say(context, "[GrandLine data] client copy");
        for (String line : PlayerDataFormat.describe(data)) {
            say(context, line);
        }
        say(context, "checksum: " + PlayerDataFormat.checksum(data));
        return 1;
    }

    private static int vfxDemo(CommandContext<CommandSourceStack> context) {
        Minecraft minecraft = Minecraft.getInstance();
        LocalPlayer player = minecraft.player;
        if (player == null || minecraft.level == null) {
            return 0;
        }
        Vec3 spot = player.position().add(player.getLookAngle().multiply(3.0, 0.0, 3.0));
        double x = spot.x;
        double y = spot.y;
        double z = spot.z;
        ClientVfx.shockwave(minecraft.level, x, y + 1.0, z, 0x9FD8FF, 0.5f, 5.5f, 9);
        ClientVfx.ring(minecraft.level, x, y + 0.15, z, 0.6f, 28, 0x9FD8FF, 0.45f, 0.30f, 14);
        ClientVfx.burst(minecraft.level, x, y + 1.0, z, 24, 0xFFC94D, 0.3f, 0.3f, 16);
        ClientVfx.sparks(minecraft.level, x, y + 1.0, z, 16, 0xFF7A3D, 0.4f);
        ClientVfx.slash(minecraft.level, x, y + 1.4, z, 0xFFFFFF, 1.2f, 8);
        CameraEffects.shake(0.6f, 10);
        return 1;
    }

    private static void say(CommandContext<CommandSourceStack> context, String text) {
        context.getSource().sendSuccess(() -> Component.literal(text), false);
    }

    private ClientCommands() {
    }
}
