package com.nerodev.grandline.client.cutscene;

import com.nerodev.grandline.GrandLineMod;
import com.nerodev.grandline.client.ClientKeys;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.LayeredDraw;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Letterbox bars, fade in/out and subtitles while a cutscene plays. */
public final class CutsceneOverlay implements LayeredDraw.Layer {

    public static final ResourceLocation ID = GrandLineMod.id("cutscene_overlay");

    @Override
    public void render(GuiGraphics graphics, DeltaTracker deltaTracker) {
        if (!CutscenePlayer.isPlaying()) {
            return;
        }
        Cutscene cutscene = CutscenePlayer.current();
        int tick = CutscenePlayer.tick();
        float t = tick + deltaTracker.getGameTimeDeltaPartialTick(false);
        int width = graphics.guiWidth();
        int height = graphics.guiHeight();
        Font font = Minecraft.getInstance().font;

        // letterbox slides in over the first 12 ticks and out over the last 12
        float slide = Mth.clamp(Math.min(t, cutscene.length() - t) / 12.0f, 0.0f, 1.0f);
        float eased = slide * slide * (3.0f - 2.0f * slide);
        int bar = (int) (height * 0.11f * eased);
        graphics.fill(0, 0, width, bar, 0xFF000000);
        graphics.fill(0, height - bar, width, height, 0xFF000000);

        // subtitles sit just above the bottom bar
        for (Cutscene.Subtitle subtitle : cutscene.subtitles()) {
            if (tick >= subtitle.from() && tick < subtitle.to()) {
                graphics.drawCenteredString(font, subtitle.text(), width / 2, height - bar - 26, 0xFFFFFFFF);
            }
        }

        if (cutscene.skippable()) {
            String hint = "Skip: " + ClientKeys.SKIP_CUTSCENE.getTranslatedKeyMessage().getString();
            graphics.drawString(font, hint, width - font.width(hint) - 8, height - bar - 14, 0xAAFFFFFF, true);
        }

        // fades to black at both ends
        float alpha = 0.0f;
        if (cutscene.fadeIn() > 0) {
            alpha = Math.max(alpha, 1.0f - t / cutscene.fadeIn());
        }
        if (cutscene.fadeOut() > 0) {
            alpha = Math.max(alpha, 1.0f - (cutscene.length() - t) / cutscene.fadeOut());
        }
        alpha = Mth.clamp(alpha, 0.0f, 1.0f);
        if (alpha > 0.004f) {
            graphics.fill(0, 0, width, height, ((int) (alpha * 255.0f)) << 24);
        }
    }
}
