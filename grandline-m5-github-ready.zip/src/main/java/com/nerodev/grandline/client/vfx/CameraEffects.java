package com.nerodev.grandline.client.vfx;

import com.nerodev.grandline.client.cutscene.CutscenePlayer;
import com.nerodev.grandline.config.GLClientConfig;
import net.minecraft.util.Mth;
import net.neoforged.neoforge.client.event.ViewportEvent;

/**
 * Screen shake and FOV punch, applied through the camera events (no mixins). Both decay on their
 * own and both respect the player's screenShake setting. Also applies the cutscene's FOV.
 */
public final class CameraEffects {

    private static float shakeIntensity = 0.0f;
    private static int shakeTicksLeft = 0;
    private static int shakeTicksTotal = 1;

    private static float fovPunchDegrees = 0.0f;
    private static int fovTicksLeft = 0;
    private static int fovTicksTotal = 1;

    public static void shake(float intensity, int ticks) {
        // a new shake replaces a weaker one in progress, never a stronger one
        float current = shakeTicksLeft > 0 ? shakeIntensity * shakeTicksLeft / shakeTicksTotal : 0.0f;
        if (intensity >= current) {
            shakeIntensity = intensity;
            shakeTicksLeft = Math.max(1, ticks);
            shakeTicksTotal = shakeTicksLeft;
        }
    }

    public static void fovPunch(float degrees, int ticks) {
        fovPunchDegrees = degrees;
        fovTicksLeft = Math.max(1, ticks);
        fovTicksTotal = fovTicksLeft;
    }

    public static void tick() {
        if (shakeTicksLeft > 0) {
            shakeTicksLeft--;
        }
        if (fovTicksLeft > 0) {
            fovTicksLeft--;
        }
    }

    public static void clear() {
        shakeTicksLeft = 0;
        fovTicksLeft = 0;
    }

    public static void onComputeCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        if (shakeTicksLeft <= 0) {
            return;
        }
        float decay = (shakeTicksLeft - (float) event.getPartialTick()) / shakeTicksTotal;
        float amplitude = shakeIntensity * Mth.clamp(decay, 0.0f, 1.0f) * GLClientConfig.screenShake();
        float time = (shakeTicksTotal - shakeTicksLeft + (float) event.getPartialTick());
        event.setRoll(event.getRoll() + Mth.sin(time * 2.3f) * amplitude * 1.2f);
        event.setPitch(event.getPitch() + Mth.sin(time * 3.1f + 1.0f) * amplitude * 0.7f);
        event.setYaw(event.getYaw() + Mth.cos(time * 2.7f) * amplitude * 0.7f);
    }

    public static void onComputeFov(ViewportEvent.ComputeFov event) {
        double fov = event.getFOV();
        if (CutscenePlayer.isPlaying()) {
            fov = CutscenePlayer.fov((float) event.getPartialTick());
        }
        if (fovTicksLeft > 0) {
            float decay = (fovTicksLeft - (float) event.getPartialTick()) / fovTicksTotal;
            fov += fovPunchDegrees * Mth.clamp(decay, 0.0f, 1.0f);
        }
        event.setFOV(fov);
    }

    private CameraEffects() {
    }
}
