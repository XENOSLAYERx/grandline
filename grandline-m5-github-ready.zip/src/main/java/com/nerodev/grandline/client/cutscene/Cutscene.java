package com.nerodev.grandline.client.cutscene;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;

/**
 * A camera path loaded from assets/grandline/cutscenes/NAME.json.
 *
 * Positions are relative to where the player stands when the cutscene starts, in the player's own
 * frame: x = to the player's right, y = up from their feet, z = in front of them.
 * yaw is relative to the way the player faces (0 = same direction, 180 = looking back at the
 * player); pitch is degrees, positive = looking down. The camera follows a smooth spline through
 * the keys, so a few keys make a clean move.
 */
public record Cutscene(
        int length,
        boolean skippable,
        int fadeIn,
        int fadeOut,
        List<CameraKey> keys,
        List<Subtitle> subtitles) {

    public record CameraKey(int tick, Vec3 pos, float yaw, float pitch, float fov) {
        public static final Codec<CameraKey> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                Codec.INT.fieldOf("tick").forGetter(CameraKey::tick),
                Vec3.CODEC.fieldOf("pos").forGetter(CameraKey::pos),
                Codec.FLOAT.optionalFieldOf("yaw", 0.0f).forGetter(CameraKey::yaw),
                Codec.FLOAT.optionalFieldOf("pitch", 0.0f).forGetter(CameraKey::pitch),
                Codec.FLOAT.optionalFieldOf("fov", 70.0f).forGetter(CameraKey::fov)
        ).apply(instance, CameraKey::new));
    }

    public record Subtitle(int from, int to, String text) {
        public static final Codec<Subtitle> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                Codec.INT.fieldOf("from").forGetter(Subtitle::from),
                Codec.INT.fieldOf("to").forGetter(Subtitle::to),
                Codec.STRING.fieldOf("text").forGetter(Subtitle::text)
        ).apply(instance, Subtitle::new));
    }

    public record Frame(Vec3 pos, float yaw, float pitch, float fov) {
    }

    public static final Codec<Cutscene> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.INT.fieldOf("length").forGetter(Cutscene::length),
            Codec.BOOL.optionalFieldOf("skippable", true).forGetter(Cutscene::skippable),
            Codec.INT.optionalFieldOf("fade_in", 0).forGetter(Cutscene::fadeIn),
            Codec.INT.optionalFieldOf("fade_out", 0).forGetter(Cutscene::fadeOut),
            CameraKey.CODEC.listOf().fieldOf("keys").forGetter(Cutscene::keys),
            Subtitle.CODEC.listOf().optionalFieldOf("subtitles", List.of()).forGetter(Cutscene::subtitles)
    ).apply(instance, Cutscene::new));

    public Cutscene {
        keys = keys.stream().sorted(Comparator.comparingInt(CameraKey::tick)).toList();
        subtitles = List.copyOf(subtitles);
    }

    /** The camera at a (possibly fractional) tick. */
    public Frame sample(float t) {
        int n = keys.size();
        if (n == 1 || t <= keys.get(0).tick()) {
            return frameOf(keys.get(0));
        }
        if (t >= keys.get(n - 1).tick()) {
            return frameOf(keys.get(n - 1));
        }

        int i = 0;
        while (i < n - 2 && t >= keys.get(i + 1).tick()) {
            i++;
        }
        CameraKey k0 = keys.get(Math.max(0, i - 1));
        CameraKey k1 = keys.get(i);
        CameraKey k2 = keys.get(i + 1);
        CameraKey k3 = keys.get(Math.min(n - 1, i + 2));

        float span = Math.max(1, k2.tick() - k1.tick());
        double u = Mth.clamp((t - k1.tick()) / span, 0.0f, 1.0f);

        Vec3 pos = new Vec3(
                catmull(k0.pos().x, k1.pos().x, k2.pos().x, k3.pos().x, u),
                catmull(k0.pos().y, k1.pos().y, k2.pos().y, k3.pos().y, u),
                catmull(k0.pos().z, k1.pos().z, k2.pos().z, k3.pos().z, u));

        // keep yaw continuous across the +-180 wrap so the camera never spins the long way round
        float y1 = k1.yaw();
        float y0 = y1 + Mth.wrapDegrees(k0.yaw() - y1);
        float y2 = y1 + Mth.wrapDegrees(k2.yaw() - y1);
        float y3 = y2 + Mth.wrapDegrees(k3.yaw() - y2);

        return new Frame(pos,
                (float) catmull(y0, y1, y2, y3, u),
                (float) catmull(k0.pitch(), k1.pitch(), k2.pitch(), k3.pitch(), u),
                (float) catmull(k0.fov(), k1.fov(), k2.fov(), k3.fov(), u));
    }

    private static Frame frameOf(CameraKey key) {
        return new Frame(key.pos(), key.yaw(), key.pitch(), key.fov());
    }

    /** Uniform Catmull-Rom spline between p1 and p2. */
    private static double catmull(double p0, double p1, double p2, double p3, double u) {
        double u2 = u * u;
        double u3 = u2 * u;
        return 0.5 * ((2.0 * p1)
                + (-p0 + p2) * u
                + (2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3) * u2
                + (-p0 + 3.0 * p1 - 3.0 * p2 + p3) * u3);
    }
}
