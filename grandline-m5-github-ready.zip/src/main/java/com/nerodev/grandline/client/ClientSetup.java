package com.nerodev.grandline.client;

import com.nerodev.grandline.GrandLineMod;
import com.nerodev.grandline.client.cutscene.CutsceneLoader;
import com.nerodev.grandline.client.cutscene.CutsceneOverlay;
import com.nerodev.grandline.client.cutscene.CutscenePlayer;
import com.nerodev.grandline.client.vfx.ClientVfx;
import com.nerodev.grandline.client.vfx.GlowParticle;
import com.nerodev.grandline.network.ClientHooks;
import com.nerodev.grandline.registry.GLParticles;
import net.minecraft.client.KeyMapping;
import net.minecraft.core.particles.SimpleParticleType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.RegisterClientReloadListenersEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent;

/** Client-only mod-bus registration. Never loaded on a dedicated server. */
@EventBusSubscriber(modid = GrandLineMod.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            ClientHooks.playCutscene = CutscenePlayer::start;
            ClientHooks.stopCutscene = CutscenePlayer::stop;
        });
    }

    @SubscribeEvent
    public static void onRegisterKeyMappings(RegisterKeyMappingsEvent event) {
        for (KeyMapping key : ClientKeys.ABILITY_KEYS) {
            event.register(key);
        }
        for (KeyMapping key : ClientKeys.HAKI_KEYS) {
            event.register(key);
        }
        event.register(ClientKeys.SKIP_CUTSCENE);
    }

    @SubscribeEvent
    public static void onRegisterGuiLayers(RegisterGuiLayersEvent event) {
        event.registerAboveAll(AbilityHud.ID, new AbilityHud());
        event.registerAboveAll(ObservationOverlay.ID, new ObservationOverlay());
        event.registerAboveAll(CutsceneOverlay.ID, new CutsceneOverlay());
    }

    @SubscribeEvent
    public static void onRegisterClientReloadListeners(RegisterClientReloadListenersEvent event) {
        event.registerReloadListener(new CutsceneLoader());
    }

    @SubscribeEvent
    public static void onRegisterParticleProviders(RegisterParticleProvidersEvent event) {
        registerSprite(event, GLParticles.GLOW.get(), "glow");
        registerSprite(event, GLParticles.RING.get(), "ring");
        registerSprite(event, GLParticles.SPARK.get(), "spark");
        registerSprite(event, GLParticles.SLASH.get(), "slash");
    }

    /**
     * Gives ClientVfx the sprite set for this particle so it can build tinted GlowParticles itself.
     * The provider below is only used if something spawns the plain particle type (for example /particle).
     */
    private static void registerSprite(RegisterParticleProvidersEvent event, SimpleParticleType type, String name) {
        event.registerSpriteSet(type, sprites -> {
            ClientVfx.registerSprites(name, sprites);
            return (options, level, x, y, z, xSpeed, ySpeed, zSpeed) ->
                    new GlowParticle(level, sprites, x, y, z, xSpeed, ySpeed, zSpeed,
                            0xFFFFFF, 0.3f, 0.4f, 20, 0.0f, 0.96f);
        });
    }

    private ClientSetup() {
    }
}
