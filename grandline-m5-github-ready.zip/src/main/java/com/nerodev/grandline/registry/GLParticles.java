package com.nerodev.grandline.registry;

import com.nerodev.grandline.GrandLineMod;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

/**
 * Particle types behind the Grand Line effects. The look comes from assets/grandline/particles/*.json
 * and assets/grandline/textures/particle/*.png; the behaviour from client/vfx/GlowParticle.
 */
public final class GLParticles {

    private static final DeferredRegister<ParticleType<?>> PARTICLE_TYPES =
            DeferredRegister.create(BuiltInRegistries.PARTICLE_TYPE, GrandLineMod.MODID);

    public static final Supplier<SimpleParticleType> GLOW = PARTICLE_TYPES.register("glow", () -> new SimpleParticleType(false));
    public static final Supplier<SimpleParticleType> RING = PARTICLE_TYPES.register("ring", () -> new SimpleParticleType(false));
    public static final Supplier<SimpleParticleType> SPARK = PARTICLE_TYPES.register("spark", () -> new SimpleParticleType(false));
    public static final Supplier<SimpleParticleType> SLASH = PARTICLE_TYPES.register("slash", () -> new SimpleParticleType(false));

    public static void register(IEventBus modEventBus) {
        PARTICLE_TYPES.register(modEventBus);
    }

    private GLParticles() {
    }
}
