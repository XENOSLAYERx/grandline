package com.nerodev.grandline.registry;

import com.nerodev.grandline.GrandLineMod;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.neoforged.neoforge.registries.NewRegistryEvent;
import net.neoforged.neoforge.registries.RegistryBuilder;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Framework for the mod's own registries (fruits, abilities, styles, weapons, races, ships,
 * bosses, islands, quests).
 *
 * Milestone 1 ships the framework only. Each content registry is created in the milestone that
 * defines its value type (abilities in M3, fruits in M4, ...). Pattern for those milestones:
 *
 *   public static final Registry<Ability> ABILITIES = GLRegistries.create("ability");
 *   public static final DeferredRegister<Ability> ABILITY_ENTRIES =
 *           DeferredRegister.create(ABILITIES, GrandLineMod.MODID);
 *   // in the mod constructor: touch the class that holds ABILITIES, then
 *   //   ABILITY_ENTRIES.register(modEventBus);
 *
 * create(...) must run before NewRegistryEvent fires, so call it from a static field
 * initializer of a class that the mod constructor loads.
 */
public final class GLRegistries {
    private static final List<Registry<?>> ALL = new ArrayList<>();

    /** Creates a registry with network sync enabled and queues it for NewRegistryEvent. */
    public static <T> Registry<T> create(String name) {
        ResourceKey<Registry<T>> key = ResourceKey.createRegistryKey(GrandLineMod.id(name));
        Registry<T> registry = new RegistryBuilder<>(key).sync(true).create();
        ALL.add(registry);
        return registry;
    }

    public static List<Registry<?>> all() {
        return Collections.unmodifiableList(ALL);
    }

    public static void onNewRegistry(NewRegistryEvent event) {
        for (Registry<?> registry : ALL) {
            event.register(registry);
        }
    }

    private GLRegistries() {
    }
}
