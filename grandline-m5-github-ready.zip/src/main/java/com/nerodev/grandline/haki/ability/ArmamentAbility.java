package com.nerodev.grandline.haki.ability;

import com.nerodev.grandline.ability.Ability;
import com.nerodev.grandline.ability.AbilityPhase;
import com.nerodev.grandline.ability.ActivationType;
import com.nerodev.grandline.ability.ResourceType;
import com.nerodev.grandline.client.vfx.ClientVfx;
import com.nerodev.grandline.data.GLPlayerData;
import com.nerodev.grandline.data.HakiBranch;
import com.nerodev.grandline.fruit.FormModifiers;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.List;

/**
 * TOGGLE: Armament Haki, a black coat of will. While on you can hit Logia bodies (LogiaRules).
 *   Level 1+:  weapon and fists hardened: +1 attack, +0.06 per level.
 *   Level 30+: full-body hardening: armour +0.08 per level and +0.3 knockback resistance.
 * Costs 8 Haki, drains 2 Haki per second, 1 s cooldown after switching off.
 * Counter: it drains Haki and ends when Haki runs out, and it does nothing against environmental damage.
 * Level 60+ unlocks the advanced strike (ArmamentAdvancedAbility), which needs this toggle on.
 */
public final class ArmamentAbility extends Ability {

    private static final String FORM = "haki_armament";
    private static final int BLACK = 0x1B1522;
    private static final int BLOOD = 0x8A1226;

    public ArmamentAbility() {
        super(new Properties()
                .activation(ActivationType.TOGGLE)
                .resource(ResourceType.HAKI)
                .staminaCost(8)
                .upkeepPerSecond(2.0)
                .cooldown(20)
                .requiresHaki(HakiBranch.ARMAMENT, 1)
                .awardsHaki(HakiBranch.ARMAMENT));
    }

    private static List<FormModifiers.Spec> specs(int level) {
        List<FormModifiers.Spec> list = new ArrayList<>();
        list.add(FormModifiers.spec(Attributes.ATTACK_DAMAGE, "attack", 1.0 + level * 0.06, AttributeModifier.Operation.ADD_VALUE));
        list.add(FormModifiers.spec(Attributes.ARMOR, "armor", level >= 30 ? level * 0.08 : 0.0, AttributeModifier.Operation.ADD_VALUE));
        list.add(FormModifiers.spec(Attributes.KNOCKBACK_RESISTANCE, "knockback", level >= 30 ? 0.3 : 0.0, AttributeModifier.Operation.ADD_VALUE));
        return list;
    }

    @Override
    public void onToggleOn(ServerPlayer player) {
        FormModifiers.apply(player, FORM, specs(GLPlayerData.get(player).haki().armament()));
    }

    @Override
    public void onToggleOff(ServerPlayer player) {
        FormModifiers.remove(player, FORM, specs(0));
    }

    @Override
    public void clientEffects(Level level, LivingEntity caster, AbilityPhase phase, float intensity) {
        double x = caster.getX();
        double y = caster.getY();
        double z = caster.getZ();
        if (phase == AbilityPhase.TOGGLE_ON) {
            ClientVfx.shockwave(level, x, y + 1.0, z, BLACK, 0.4f, 3.2f, 8);
            ClientVfx.burst(level, x, y + 1.0, z, 16, BLACK, 0.2f, 0.3f, 12);
            ClientVfx.sparks(level, x, y + 1.0, z, 6, BLOOD, 0.3f);
            ClientVfx.localShake(caster, 0.35f, 6);
        } else if (phase == AbilityPhase.TOGGLE_OFF) {
            ClientVfx.burst(level, x, y + 1.0, z, 8, BLACK, 0.12f, 0.25f, 10);
        }
    }

    @Override
    public void clientTick(Level level, LivingEntity caster) {
        if (caster.tickCount % 3 == 0) {
            ClientVfx.rise(level, caster, BLACK, 2);
        }
        if (caster.tickCount % 12 == 0) {
            ClientVfx.rise(level, caster, BLOOD, 1);
        }
    }
}
