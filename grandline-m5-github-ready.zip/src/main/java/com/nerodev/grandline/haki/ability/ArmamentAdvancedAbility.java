package com.nerodev.grandline.haki.ability;

import com.nerodev.grandline.ability.Ability;
import com.nerodev.grandline.ability.AbilityManager;
import com.nerodev.grandline.ability.AbilityPhase;
import com.nerodev.grandline.ability.ActivationType;
import com.nerodev.grandline.ability.ResourceType;
import com.nerodev.grandline.client.vfx.ClientVfx;
import com.nerodev.grandline.data.HakiBranch;
import com.nerodev.grandline.fruit.Combat;
import com.nerodev.grandline.haki.HakiIds;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * CHARGE: the advanced form of Armament Haki. Needs Armament level 60 and the Armament toggle on.
 * Hold up to 1 s, release for a strike that sends the force INSIDE the target: the damage ignores
 * armour, and the target keeps taking internal damage (wither) for 2 s and is weakened. Hits up to
 * 2 enemies in front. 6 to 18 damage by charge. Costs 30 Haki, cooldown 6 s.
 */
public final class ArmamentAdvancedAbility extends Ability {

    private static final int BLACK = 0x1B1522;
    private static final int BLOOD = 0x8A1226;

    public ArmamentAdvancedAbility() {
        super(new Properties()
                .activation(ActivationType.CHARGE)
                .resource(ResourceType.HAKI)
                .charge(6, 20)
                .staminaCost(30)
                .cooldown(120)
                .requiresHaki(HakiBranch.ARMAMENT, 60)
                .awardsHaki(HakiBranch.ARMAMENT));
    }

    @Override
    public boolean canActivate(ServerPlayer player) {
        if (!AbilityManager.isActive(player, HakiIds.ARMAMENT)) {
            player.displayClientMessage(Component.literal("Turn Armament hardening on first."), true);
            return false;
        }
        return true;
    }

    @Override
    public boolean executeCharged(ServerPlayer player, float fraction) {
        List<LivingEntity> hits = Combat.cone(player, 3.6, 40.0);
        int count = Math.min(2, hits.size());
        for (int i = 0; i < count; i++) {
            LivingEntity target = hits.get(i);
            float damage = 6.0f + 12.0f * fraction;
            // magic-type damage ignores armour: the force goes through the body, not into it
            target.hurt(player.damageSources().indirectMagic(player, player), damage);
            target.addEffect(new MobEffectInstance(MobEffects.WITHER, 40, 0));
            target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 0));
            Combat.hit(player, target, 0.0f, 1.2 + fraction, false);
        }
        return true;
    }

    @Override
    public void clientEffects(Level level, LivingEntity caster, AbilityPhase phase, float intensity) {
        Vec3 at = caster.getEyePosition().add(caster.getLookAngle().scale(2.4));
        if (phase == AbilityPhase.CHARGE_START) {
            ClientVfx.ring(level, caster.getX(), caster.getY() + 0.1, caster.getZ(), 0.4f, 14, BLACK, 0.1f, 0.22f, 10);
        } else if (phase == AbilityPhase.CHARGE_RELEASE) {
            ClientVfx.shockwave(level, at.x, at.y, at.z, BLACK, 0.5f, 3.0f + 2.0f * intensity, 8);
            ClientVfx.burst(level, at.x, at.y, at.z, (int) (10 + 16 * intensity), BLACK, 0.3f + 0.3f * intensity, 0.3f, 12);
            ClientVfx.sparks(level, at.x, at.y, at.z, 10, BLOOD, 0.4f);
            ClientVfx.localShake(caster, 0.6f + 1.0f * intensity, 9);
            ClientVfx.localFovPunch(caster, 7.0f * intensity, 8);
        }
    }
}
