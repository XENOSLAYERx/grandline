package com.nerodev.grandline.haki.ability;

import com.nerodev.grandline.ability.Ability;
import com.nerodev.grandline.ability.AbilityPhase;
import com.nerodev.grandline.ability.GLAbilityData;
import com.nerodev.grandline.ability.ResourceType;
import com.nerodev.grandline.client.vfx.ClientVfx;
import com.nerodev.grandline.data.GLPlayerData;
import com.nerodev.grandline.data.HakiBranch;
import com.nerodev.grandline.fruit.Combat;
import com.nerodev.grandline.haki.HakiIds;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.common.Tags;

import java.util.List;

/**
 * PRESS: Conqueror's Haki. A wave of will in a radius of 8 blocks + 0.12 per level.
 *   Weak mobs (max health <= 12 + 0.3 per level, never bosses) are knocked out: frozen for 10 s and
 *   they drop their target. Stronger mobs are intimidated: slowed and weakened for 5 s.
 *   Players are intimidated for 4 s unless their own Conqueror's level is as high as yours.
 *   Clash: if another player used Conqueror's within the last 3 s, the two wills collide: both of
 *   you are thrown back and nobody is affected.
 * Costs 40 Haki, cooldown 15 s. Counter: it is slow to recharge, bosses and equal wills ignore it,
 * and it does no damage.
 */
public final class ConquerorsAbility extends Ability {

    private static final int COOLDOWN = 300;

    public ConquerorsAbility() {
        super(new Properties()
                .resource(ResourceType.HAKI)
                .staminaCost(40)
                .cooldown(COOLDOWN)
                .requiresHaki(HakiBranch.CONQUERORS, 1)
                .awardsHaki(HakiBranch.CONQUERORS));
    }

    @Override
    public boolean execute(ServerPlayer player) {
        ServerLevel level = (ServerLevel) player.level();
        int power = GLPlayerData.get(player).haki().conquerors();
        double radius = 8.0 + 0.12 * power;
        long now = level.getGameTime();

        List<LivingEntity> around = level.getEntitiesOfClass(LivingEntity.class,
                player.getBoundingBox().inflate(radius),
                e -> Combat.canTarget(player, e) && e.distanceToSqr(player) <= radius * radius);

        for (LivingEntity entity : around) {
            if (entity instanceof ServerPlayer other) {
                affectPlayer(player, other, power, now);
            } else if (entity instanceof Mob mob) {
                boolean boss = mob.getType().is(Tags.EntityTypes.BOSSES);
                if (!boss && mob.getMaxHealth() <= 12.0 + 0.3 * power) {
                    mob.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 200, 9));
                    mob.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 200, 0));
                    mob.setTarget(null);
                } else if (!boss) {
                    mob.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 1));
                    mob.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 0));
                }
            }
        }
        return true;
    }

    private static void affectPlayer(ServerPlayer caster, ServerPlayer other, int power, long now) {
        long theirUntil = GLAbilityData.get(other).cooldownUntil().getOrDefault(HakiIds.CONQUERORS, 0L);
        boolean clash = theirUntil - now > COOLDOWN - 60;
        if (clash) {
            throwBack(caster, other);
            throwBack(other, caster);
            return;
        }
        if (GLPlayerData.get(other).haki().conquerors() >= power) {
            return; // an equal will cannot be pressured
        }
        other.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 2));
        other.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 80, 0));
    }

    private static void throwBack(ServerPlayer from, ServerPlayer entity) {
        Vec3 away = entity.position().subtract(from.position());
        double length = Math.max(1.0e-4, Math.hypot(away.x, away.z));
        entity.knockback(2.0, -away.x / length, -away.z / length);
        entity.hurtMarked = true;
    }

    @Override
    public void clientEffects(Level level, LivingEntity caster, AbilityPhase phase, float intensity) {
        if (phase != AbilityPhase.USE) {
            return;
        }
        double x = caster.getX();
        double y = caster.getY() + 1.0;
        double z = caster.getZ();
        ClientVfx.shockwave(level, x, y, z, 0x8A0A16, 0.5f, 7.0f, 10);
        ClientVfx.shockwave(level, x, y, z, 0x120A18, 0.3f, 5.0f, 8);
        for (int i = 0; i < 8; i++) {
            double angle = i * (Math.PI * 2.0 / 8) + caster.getRandom().nextDouble() * 0.4;
            Vec3 from = new Vec3(x, y, z);
            Vec3 to = from.add(Math.cos(angle) * 6.0, (caster.getRandom().nextDouble() - 0.5) * 3.0, Math.sin(angle) * 6.0);
            ClientVfx.lightning(level, from, to, 0xC01830, 7, 0.9, 0.2f);
        }
        ClientVfx.localShake(caster, 1.4f, 14);
        ClientVfx.localFovPunch(caster, 10.0f, 10);
    }
}
