package com.nerodev.grandline.haki;

import com.nerodev.grandline.data.AbilitySlots;
import net.minecraft.resources.ResourceLocation;

import java.util.List;

/**
 * Haki has its own fixed keys, separate from the five fruit/style slots, so a fruit that fills all
 * five slots never pushes Haki off the keyboard. Key index = AbilitySlots.COUNT + position here.
 */
public final class HakiSlots {

    public static final List<ResourceLocation> ABILITIES = List.of(
            HakiIds.OBSERVATION, HakiIds.ARMAMENT, HakiIds.ARMAMENT_ADVANCED, HakiIds.CONQUERORS);

    public static final int COUNT = ABILITIES.size();
    public static final int TOTAL_KEYS = AbilitySlots.COUNT + COUNT;

    public static ResourceLocation abilityFor(int keyIndex) {
        return ABILITIES.get(keyIndex - AbilitySlots.COUNT);
    }

    private HakiSlots() {
    }
}
