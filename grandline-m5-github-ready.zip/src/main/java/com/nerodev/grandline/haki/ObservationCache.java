package com.nerodev.grandline.haki;

import java.util.List;

/**
 * Client-side: the entity ids Observation Haki last reported. Plain data (safe to load on any
 * side). Markers are shown only while the data is fresh, so they disappear a moment after the
 * toggle ends.
 */
public final class ObservationCache {

    private static final long FRESH_MILLIS = 1200L;

    private static volatile List<Integer> ids = List.of();
    private static volatile long updatedAt = 0L;

    public static void set(List<Integer> newIds) {
        ids = List.copyOf(newIds);
        updatedAt = System.currentTimeMillis();
    }

    public static boolean isFresh() {
        return !ids.isEmpty() && System.currentTimeMillis() - updatedAt < FRESH_MILLIS;
    }

    public static List<Integer> ids() {
        return ids;
    }

    public static void clear() {
        ids = List.of();
    }

    private ObservationCache() {
    }
}
