package com.nerodev.grandline.haki;

import com.nerodev.grandline.ability.AbilityManager;
import com.nerodev.grandline.ability.AbilityPhase;
import com.nerodev.grandline.ability.AbilityState;
import com.nerodev.grandline.ability.GLAbilityData;
import com.nerodev.grandline.ability.ResourceType;
import com.nerodev.grandline.config.GLConfig;
import com.nerodev.grandline.data.GLPlayerData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/**
 * Future Sight (Observation Haki level 25+). While Observation is on, a hit from a living
 * attacker can be dodged: the damage is cancelled, the dodge flashes on screen, it costs 8 Haki and
 * the next dodge is possible 2 seconds later. Environmental damage is never dodged.
 */
public final class HakiEvents {

    public static final int FUTURE_SIGHT_MIN_LEVEL = 25;
    public static final int FUTURE_SIGHT_COST = 8;
    public static final int FUTURE_SIGHT_PAUSE_TICKS = 40;

    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer victim)) {
            return;
        }
        if (!(event.getSource().getEntity() instanceof LivingEntity attacker) || attacker == victim) {
            return;
        }
        if (!AbilityManager.isActive(victim, HakiIds.OBSERVATION)) {
            return;
        }
        int level = GLPlayerData.get(victim).haki().observation();
        if (level < FUTURE_SIGHT_MIN_LEVEL) {
            return;
        }

        long now = victim.level().getGameTime();
        AbilityState state = GLAbilityData.get(victim);
        if (state.cooldownUntil().getOrDefault(HakiIds.FUTURE_SIGHT_TIMER, 0L) > now) {
            return;
        }
        double chance = Math.min(0.65, 0.15 + level * 0.005);
        if (victim.getRandom().nextDouble() >= chance) {
            return;
        }
        double current = state.resourceNow(ResourceType.HAKI, now, GLConfig.hakiMax(), GLConfig.hakiRegenPerTick());
        if (!state.infiniteHaki() && current < FUTURE_SIGHT_COST) {
            return;
        }

        event.setCanceled(true);
        GLAbilityData.update(victim, s -> {
            AbilityState next = s.infiniteHaki() ? s : s.withResource(ResourceType.HAKI, current - FUTURE_SIGHT_COST, now);
            return next.withCooldown(HakiIds.FUTURE_SIGHT_TIMER, now + FUTURE_SIGHT_PAUSE_TICKS, now);
        });
        AbilityManager.playEffect(victim, HakiIds.OBSERVATION, AbilityPhase.USE, 1.0f);
    }

    private HakiEvents() {
    }
}
