package com.nerodev.grandline.haki;

import com.nerodev.grandline.GrandLineMod;
import net.minecraft.resources.ResourceLocation;

public final class HakiIds {

    public static final ResourceLocation OBSERVATION = GrandLineMod.id("haki_observation");
    public static final ResourceLocation ARMAMENT = GrandLineMod.id("haki_armament");
    public static final ResourceLocation ARMAMENT_ADVANCED = GrandLineMod.id("haki_armament_advanced");
    public static final ResourceLocation CONQUERORS = GrandLineMod.id("haki_conquerors");

    /** Cooldown key used by Future Sight dodges (not an ability, just a timer in the cooldown map). */
    public static final ResourceLocation FUTURE_SIGHT_TIMER = GrandLineMod.id("haki_future_sight");

    private HakiIds() {
    }
}
