package com.nerodev.grandline.haki.ability;

import com.nerodev.grandline.ability.Ability;
import com.nerodev.grandline.ability.AbilityPhase;
import com.nerodev.grandline.ability.ActivationType;
import com.nerodev.grandline.ability.ResourceType;
import com.nerodev.grandline.client.vfx.ClientVfx;
import com.nerodev.grandline.data.GLPlayerData;
import com.nerodev.grandline.data.HakiBranch;
import com.nerodev.grandline.network.ObservationPulsePayload;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.Comparator;
import java.util.List;

/**
 * TOGGLE: Observation Haki. You feel the presence of hostile creatures and other players through
 * walls: markers appear on your screen (on its edge when they are off-screen). Only YOU receive
 * the information, 2 times a second, never the other players.
 *   Range: 14 blocks + 0.2 per level (34 at level 100).
 *   Level 25+: Future Sight. See HakiEvents: a hit from a living attacker can be dodged
 *   automatically for 8 Haki, with a 2 s pause between dodges. The chance grows with level (max 65%).
 * Costs 6 Haki, drains 1.5 Haki per second.
 * Counter: it only senses what is in range, it does not stop environmental damage, and the dodge needs
 * Haki and is on a timer.
 */
public final class ObservationAbility extends Ability {

    private static final int WHITE = 0xDDEEFF;

    public ObservationAbility() {
        super(new Properties()
                .activation(ActivationType.TOGGLE)
                .resource(ResourceType.HAKI)
                .staminaCost(6)
                .upkeepPerSecond(1.5)
                .cooldown(20)
                .requiresHaki(HakiBranch.OBSERVATION, 1)
                .awardsHaki(HakiBranch.OBSERVATION));
    }

    @Override
    public void onToggleTick(ServerPlayer player) {
        if (player.tickCount % 10 != 0) {
            return;
        }
        double range = 14.0 + 0.2 * GLPlayerData.get(player).haki().observation();
        List<Integer> ids = player.level().getEntitiesOfClass(LivingEntity.class,
                        player.getBoundingBox().inflate(range),
                        e -> e != player && e.isAlive() && !e.isSpectator()
                                && e.distanceToSqr(player) <= range * range
                                && (e instanceof Enemy || e instanceof Player)
                                && !(e instanceof TamableAnimal))
                .stream()
                .sorted(Comparator.comparingDouble(e -> e.distanceToSqr(player)))
                .limit(24)
                .map(LivingEntity::getId)
                .toList();
        PacketDistributor.sendToPlayer(player, new ObservationPulsePayload(ids));
    }

    @Override
    public void clientEffects(Level level, LivingEntity caster, AbilityPhase phase, float intensity) {
        double x = caster.getX();
        double y = caster.getY();
        double z = caster.getZ();
        if (phase == AbilityPhase.TOGGLE_ON) {
            ClientVfx.ring(level, x, y + 1.6, z, 0.4f, 16, WHITE, 0.25f, 0.22f, 12);
            ClientVfx.localFovPunch(caster, 5.0f, 8);
        } else if (phase == AbilityPhase.USE) {
            // Future Sight: the dodge
            ClientVfx.burst(level, x, y + 1.0, z, 18, WHITE, 0.3f, 0.3f, 10);
            ClientVfx.ring(level, x, y + 1.0, z, 0.5f, 20, 0xFFFFFF, 0.4f, 0.25f, 10);
            ClientVfx.localFovPunch(caster, -8.0f, 8);
            ClientVfx.localShake(caster, 0.3f, 4);
        }
    }
}
