package com.nerodev.grandline.ability;

import com.nerodev.grandline.config.GLConfig;
import com.nerodev.grandline.data.GLPlayerData;
import com.nerodev.grandline.data.HakiBranch;
import com.nerodev.grandline.data.HakiLevels;
import com.nerodev.grandline.data.PlayerData;
import com.nerodev.grandline.fruit.FruitIds;
import com.nerodev.grandline.fruit.FruitManager;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;

import java.util.HashMap;
import java.util.Map;

/** Awards mastery points. Fractions are rounded randomly, so 0.5 points per use averages out correctly. */
public final class MasteryManager {

    public static void award(ServerPlayer player, ResourceLocation system, double basePoints) {
        double gain = basePoints * GLConfig.masteryGainMultiplier();
        int whole = (int) Math.floor(gain);
        final int add = player.getRandom().nextDouble() < gain - whole ? whole + 1 : whole;
        if (add <= 0) {
            return;
        }
        int before = GLPlayerData.get(player).mastery().getOrDefault(system, 0);
        if (before >= PlayerData.MAX_MASTERY) {
            return;
        }
        GLPlayerData.update(player, data -> {
            Map<ResourceLocation, Integer> mastery = new HashMap<>(data.mastery());
            mastery.put(system, Math.min(PlayerData.MAX_MASTERY, before + add));
            return data.withMastery(mastery);
        });
        if (system.equals(FruitIds.MASTERY)) {
            FruitManager.awakenIfEarned(player);
        }
    }

    /** Haki grows by being used. It can never start from 0: the first level must be unlocked (training later, Creator now). */
    public static void awardHaki(ServerPlayer player, HakiBranch branch, double basePoints) {
        int level = GLPlayerData.get(player).haki().get(branch);
        if (level <= 0 || level >= HakiLevels.MAX_LEVEL) {
            return;
        }
        double gain = basePoints * 0.5 * GLConfig.masteryGainMultiplier();
        int whole = (int) Math.floor(gain);
        final int add = player.getRandom().nextDouble() < gain - whole ? whole + 1 : whole;
        if (add > 0) {
            GLPlayerData.update(player, data -> data.withHaki(data.haki().with(branch, level + add)));
        }
    }

    private MasteryManager() {
    }
}
