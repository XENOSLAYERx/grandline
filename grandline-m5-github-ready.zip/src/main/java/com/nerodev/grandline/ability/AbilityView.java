package com.nerodev.grandline.ability;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.resources.ResourceLocation;

import java.util.Map;

/**
 * What the client needs to draw the HUD: a snapshot taken on the server at a known game time.
 * The client extends it with the regen rates, so no packet is needed while a bar refills or a
 * cooldown counts down.
 */
public record AbilityView(
        double stamina,
        double max,
        double regenPerTick,
        long gameTime,
        boolean infinite,
        Map<ResourceLocation, Long> cooldowns,
        double haki,
        double hakiMax,
        double hakiRegenPerTick,
        boolean infiniteHaki) {

    public static final Codec<AbilityView> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.DOUBLE.fieldOf("stamina").forGetter(AbilityView::stamina),
            Codec.DOUBLE.fieldOf("max").forGetter(AbilityView::max),
            Codec.DOUBLE.fieldOf("regen").forGetter(AbilityView::regenPerTick),
            Codec.LONG.fieldOf("time").forGetter(AbilityView::gameTime),
            Codec.BOOL.fieldOf("infinite").forGetter(AbilityView::infinite),
            Codec.unboundedMap(ResourceLocation.CODEC, Codec.LONG).fieldOf("cooldowns").forGetter(AbilityView::cooldowns),
            Codec.DOUBLE.fieldOf("haki").forGetter(AbilityView::haki),
            Codec.DOUBLE.fieldOf("haki_max").forGetter(AbilityView::hakiMax),
            Codec.DOUBLE.fieldOf("haki_regen").forGetter(AbilityView::hakiRegenPerTick),
            Codec.BOOL.fieldOf("infinite_haki").forGetter(AbilityView::infiniteHaki)
    ).apply(instance, AbilityView::new));

    public double staminaAt(long now) {
        if (infinite) {
            return max;
        }
        return Math.min(max, stamina + Math.max(0L, now - gameTime) * regenPerTick);
    }

    public double hakiAt(long now) {
        if (infiniteHaki) {
            return hakiMax;
        }
        return Math.min(hakiMax, haki + Math.max(0L, now - gameTime) * hakiRegenPerTick);
    }

    public long cooldownRemaining(ResourceLocation id, long now) {
        return Math.max(0L, cooldowns.getOrDefault(id, 0L) - now);
    }
}
