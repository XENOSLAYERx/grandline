package com.nerodev.grandline.ability;

import com.nerodev.grandline.GrandLineMod;
import com.nerodev.grandline.config.GLConfig;
import com.nerodev.grandline.data.AbilitySlots;
import com.nerodev.grandline.data.GLAttachments;
import com.nerodev.grandline.data.GLPlayerData;
import com.nerodev.grandline.data.PlayerData;
import com.nerodev.grandline.haki.HakiSlots;
import com.nerodev.grandline.network.AbilityEffectPayload;
import com.nerodev.grandline.network.ActiveVisualsPayload;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

/**
 * The only entry point for using an ability. The client only says "key N pressed / released";
 * every rule is checked here on the server, in this order: key, registry, unlock, mastery,
 * cooldown, resource, compatibility, ability condition. Costs are charged only once the ability
 * really started or fired.
 *
 * Keys 0..4 run the player's equipped abilities; keys 5..8 are the fixed Haki keys (HakiSlots).
 *
 * Event-driven: the only per-tick work is TICKING, the set of players who currently have a toggle
 * on or a hold held (normally empty). Upkeep is charged once per second, not every tick.
 */
public final class AbilityManager {

    public static final int TOTAL_KEYS = HakiSlots.TOTAL_KEYS;

    /** Players with something to tick. Cleaned on logout, death and lazily here. */
    private static final Set<UUID> TICKING = new HashSet<>();

    public static void handleInput(ServerPlayer player, int key, boolean pressed) {
        if (key < 0 || key >= TOTAL_KEYS) {
            return; // never trust the client
        }
        if (pressed) {
            press(player, key);
        } else {
            release(player, key);
        }
    }

    public static List<ResourceLocation> activeIds(ServerPlayer player) {
        return player.getData(GLAttachments.ACTIVE_ABILITIES).activeIds();
    }

    public static boolean isActive(ServerPlayer player, ResourceLocation id) {
        return player.getData(GLAttachments.ACTIVE_ABILITIES).activeIds().contains(id);
    }

    /** Plays an ability's client visuals for everyone who can see the player (and the player). */
    public static void playEffect(ServerPlayer player, ResourceLocation id, AbilityPhase phase, float intensity) {
        broadcastEffect(player, id, phase, intensity);
    }

    /**
     * Creator tool (/onepiece transform): flips a TOGGLE ability without a key, a cost or a cooldown.
     * Compatibility rules still apply. Returns false if it is not a toggle or something blocks it.
     */
    public static boolean forceToggle(ServerPlayer player, ResourceLocation id) {
        Optional<Ability> found = GLAbilities.REGISTRY.getOptional(id);
        if (found.isEmpty() || found.get().activation() != ActivationType.TOGGLE || !player.isAlive()) {
            return false;
        }
        Ability ability = found.get();
        ActiveAbilities active = player.getData(GLAttachments.ACTIVE_ABILITIES);
        long now = player.level().getGameTime();
        if (active.isToggled(id)) {
            deactivateToggle(player, active, ability, id, now);
            return true;
        }
        if (!checkCompatible(player, active, ability)) {
            return false;
        }
        startToggle(player, active, ability, id, 0, now);
        return true;
    }

    // ------------------------------------------------------------------ press

    private static void press(ServerPlayer player, int key) {
        if (!player.isAlive() || player.isSpectator()) {
            return;
        }
        ActiveAbilities active = player.getData(GLAttachments.ACTIVE_ABILITIES);
        if (active.holdsSlot(key)) {
            return; // a second press without a release in between
        }

        PlayerData data = GLPlayerData.get(player);
        Optional<ResourceLocation> slotted;
        if (key < AbilitySlots.COUNT) {
            slotted = data.abilitySlots().get(key);
            if (slotted.isEmpty()) {
                deny(player, Component.literal("Slot " + (key + 1) + " is empty. Use /onepiece ability equip."));
                return;
            }
        } else {
            slotted = Optional.of(HakiSlots.abilityFor(key));
        }

        ResourceLocation id = slotted.get();
        Optional<Ability> found = GLAbilities.REGISTRY.getOptional(id);
        if (found.isEmpty()) {
            deny(player, Component.literal("Unknown ability " + id + "."));
            return;
        }
        Ability ability = found.get();

        if (!ability.isUnlocked(data)) {
            Optional<Ability.HakiRequirement> haki = ability.hakiRequirement();
            if (haki.isPresent()) {
                int have = data.haki().get(haki.get().branch());
                deny(player, named(ability, " needs " + haki.get().branch().id() + " Haki level "
                        + haki.get().level() + " (you have " + have + ")."));
            } else {
                deny(player, named(ability, " is not unlocked."));
            }
            return;
        }

        Optional<Ability.MasteryRequirement> requirement = ability.masteryRequirement();
        if (requirement.isPresent()) {
            int have = data.mastery().getOrDefault(requirement.get().system(), 0);
            if (have < requirement.get().level()) {
                deny(player, named(ability, " needs " + requirement.get().system().getPath()
                        + " mastery " + requirement.get().level() + " (you have " + have + ")."));
                return;
            }
        }

        long now = player.level().getGameTime();

        // Switching a toggle OFF never needs resources.
        if (ability.activation() == ActivationType.TOGGLE && active.isToggled(id)) {
            deactivateToggle(player, active, ability, id, now);
            return;
        }

        int cost = scaledCost(ability);
        if (!checkReady(player, ability, id, cost, now)) {
            return;
        }
        boolean stateful = ability.activation() == ActivationType.TOGGLE || ability.activation() == ActivationType.HOLD;
        if (stateful && !checkCompatible(player, active, ability)) {
            return;
        }
        if (!ability.canActivate(player)) {
            return;
        }

        switch (ability.activation()) {
            case PRESS -> usePress(player, ability, id, cost, now);
            case TOGGLE -> startToggle(player, active, ability, id, cost, now);
            case HOLD -> startHold(player, active, key, ability, id, cost, now);
            case CHARGE -> startCharge(player, active, key, id, now);
        }
    }

    private static void usePress(ServerPlayer player, Ability ability, ResourceLocation id, int cost, long now) {
        if (!ability.execute(player)) {
            return;
        }
        commit(player, ability, id, cost, now);
        award(player, ability);
        broadcastEffect(player, id, AbilityPhase.USE, 1.0f);
    }

    private static void startToggle(ServerPlayer player, ActiveAbilities active, Ability ability,
                                    ResourceLocation id, int cost, long now) {
        ability.onToggleOn(player);
        active.setToggled(id, true);
        spend(player, ability.resource(), cost, now);
        award(player, ability);
        refreshTicking(player, active);
        broadcastEffect(player, id, AbilityPhase.TOGGLE_ON, 1.0f);
        broadcastActive(player, active);
    }

    private static void startHold(ServerPlayer player, ActiveAbilities active, int key, Ability ability,
                                  ResourceLocation id, int cost, long now) {
        ability.onHoldStart(player);
        active.putHold(key, new ActiveAbilities.Held(id, now, false));
        spend(player, ability.resource(), cost, now);
        award(player, ability);
        refreshTicking(player, active);
        broadcastEffect(player, id, AbilityPhase.HOLD_START, 1.0f);
        broadcastActive(player, active);
    }

    private static void startCharge(ServerPlayer player, ActiveAbilities active, int key, ResourceLocation id, long now) {
        active.putHold(key, new ActiveAbilities.Held(id, now, true));
        broadcastEffect(player, id, AbilityPhase.CHARGE_START, 0.0f);
    }

    // ---------------------------------------------------------------- release

    private static void release(ServerPlayer player, int key) {
        ActiveAbilities active = player.getData(GLAttachments.ACTIVE_ABILITIES);
        ActiveAbilities.Held held = active.removeHold(key);
        if (held == null) {
            return; // nothing was held (PRESS and TOGGLE abilities, or already ended)
        }
        Optional<Ability> found = GLAbilities.REGISTRY.getOptional(held.ability());
        if (found.isEmpty()) {
            refreshTicking(player, active);
            return;
        }
        Ability ability = found.get();
        long now = player.level().getGameTime();
        int heldTicks = (int) Math.max(0L, now - held.startTick());

        if (held.charge()) {
            finishCharge(player, ability, held.ability(), heldTicks, now);
        } else {
            endHold(player, active, ability, held.ability(), heldTicks, now);
        }
    }

    private static void finishCharge(ServerPlayer player, Ability ability, ResourceLocation id, int heldTicks, long now) {
        if (!player.isAlive()) {
            return;
        }
        if (heldTicks < ability.minChargeTicks()) {
            deny(player, named(ability, ": charge it longer."));
            return;
        }
        float fraction = Mth.clamp(heldTicks / (float) Math.max(1, ability.maxChargeTicks()), 0.0f, 1.0f);
        int cost = scaledCost(ability);
        if (!checkReady(player, ability, id, cost, now)) {
            return;
        }
        if (!ability.executeCharged(player, fraction)) {
            return;
        }
        commit(player, ability, id, cost, now);
        award(player, ability);
        broadcastEffect(player, id, AbilityPhase.CHARGE_RELEASE, fraction);
    }

    private static void endHold(ServerPlayer player, ActiveAbilities active, Ability ability,
                                ResourceLocation id, int heldTicks, long now) {
        ability.onHoldEnd(player, heldTicks);
        startCooldown(player, ability, id, now);
        refreshTicking(player, active);
        broadcastEffect(player, id, AbilityPhase.HOLD_END, 1.0f);
        broadcastActive(player, active);
    }

    private static void deactivateToggle(ServerPlayer player, ActiveAbilities active, Ability ability,
                                         ResourceLocation id, long now) {
        ability.onToggleOff(player);
        active.setToggled(id, false);
        startCooldown(player, ability, id, now);
        refreshTicking(player, active);
        broadcastEffect(player, id, AbilityPhase.TOGGLE_OFF, 1.0f);
        broadcastActive(player, active);
    }

    // ------------------------------------------------------------- cleanup

    /** Ends every toggle and hold, calling the undo hooks. Used on death, logout and after a hook crashes. */
    public static void endAll(ServerPlayer player) {
        endAll(player, true);
    }

    private static void endAll(ServerPlayer player, boolean broadcast) {
        ActiveAbilities active = player.getData(GLAttachments.ACTIVE_ABILITIES);
        long now = player.level().getGameTime();

        for (ResourceLocation id : active.toggledIds()) {
            GLAbilities.REGISTRY.getOptional(id).ifPresent(ability -> ability.onToggleOff(player));
        }
        for (ActiveAbilities.Held held : active.holdsCopy().values()) {
            if (!held.charge()) {
                GLAbilities.REGISTRY.getOptional(held.ability())
                        .ifPresent(ability -> ability.onHoldEnd(player, (int) Math.max(0L, now - held.startTick())));
            }
        }

        boolean hadVisuals = !active.activeIds().isEmpty();
        active.clear();
        TICKING.remove(player.getUUID());
        if (broadcast && hadVisuals) {
            broadcastActive(player, active);
        }
    }

    /** Drops the player from the tick set (logout). */
    public static void forget(ServerPlayer player) {
        TICKING.remove(player.getUUID());
    }

    // ---------------------------------------------------------------- tick

    public static void tickActive(MinecraftServer server) {
        if (TICKING.isEmpty()) {
            return;
        }
        for (UUID uuid : List.copyOf(TICKING)) {
            ServerPlayer player = server.getPlayerList().getPlayer(uuid);
            if (player == null) {
                TICKING.remove(uuid);
                continue;
            }
            try {
                tickPlayer(player);
            } catch (RuntimeException e) {
                GrandLineMod.LOGGER.error("[GrandLine] An ability hook failed for {}; ending their abilities.",
                        player.getGameProfile().getName(), e);
                endAll(player, true);
            }
        }
    }

    private static void tickPlayer(ServerPlayer player) {
        ActiveAbilities active = player.getData(GLAttachments.ACTIVE_ABILITIES);
        long now = player.level().getGameTime();

        for (ResourceLocation toggledId : active.toggledIds()) {
            Optional<Ability> toggled = GLAbilities.REGISTRY.getOptional(toggledId);
            if (toggled.isPresent()) {
                toggled.get().onToggleTick(player);
            }
        }
        for (ActiveAbilities.Held held : active.holdsCopy().values()) {
            if (held.charge()) {
                continue;
            }
            Optional<Ability> found = GLAbilities.REGISTRY.getOptional(held.ability());
            if (found.isPresent()) {
                found.get().onHoldTick(player, (int) Math.max(0L, now - held.startTick()));
            }
        }
        if (now % 20L == 0L) {
            chargeUpkeep(player, active, now);
        }
    }

    /** Once per second: drain every active toggle/hold's upkeep from its own resource; stop what cannot be paid. */
    private static void chargeUpkeep(ServerPlayer player, ActiveAbilities active, long now) {
        double[] total = new double[ResourceType.values().length];
        for (ResourceLocation id : active.toggledIds()) {
            GLAbilities.REGISTRY.getOptional(id)
                    .ifPresent(ability -> total[ability.resource().ordinal()] += upkeepOf(ability));
        }
        for (ActiveAbilities.Held held : active.holdsCopy().values()) {
            if (!held.charge()) {
                GLAbilities.REGISTRY.getOptional(held.ability())
                        .ifPresent(ability -> total[ability.resource().ordinal()] += upkeepOf(ability));
            }
        }

        AbilityState state = GLAbilityData.get(player);
        for (ResourceType type : ResourceType.values()) {
            double need = total[type.ordinal()];
            if (need <= 0.0 || state.infinite(type)) {
                total[type.ordinal()] = 0.0;
                continue;
            }
            if (currentOf(state, type, now) < need) {
                total[type.ordinal()] = 0.0;
                stopUpkeepAbilities(player, active, now, type);
                deny(player, Component.literal("Out of " + type.label() + "."));
            }
        }

        boolean any = false;
        for (double t : total) {
            any |= t > 0.0;
        }
        if (any) {
            GLAbilityData.update(player, s -> {
                AbilityState next = s;
                for (ResourceType type : ResourceType.values()) {
                    double need = total[type.ordinal()];
                    if (need > 0.0) {
                        next = next.withResource(type, currentOf(next, type, now) - need, now);
                    }
                }
                return next;
            });
        }
    }

    private static void stopUpkeepAbilities(ServerPlayer player, ActiveAbilities active, long now, ResourceType type) {
        for (ResourceLocation id : active.toggledIds()) {
            Optional<Ability> found = GLAbilities.REGISTRY.getOptional(id);
            if (found.isPresent() && found.get().resource() == type && found.get().upkeepPerSecond() > 0.0) {
                deactivateToggle(player, active, found.get(), id, now);
            }
        }
        for (Map.Entry<Integer, ActiveAbilities.Held> entry : active.holdsCopy().entrySet()) {
            ActiveAbilities.Held held = entry.getValue();
            if (held.charge()) {
                continue;
            }
            Optional<Ability> found = GLAbilities.REGISTRY.getOptional(held.ability());
            if (found.isPresent() && found.get().resource() == type && found.get().upkeepPerSecond() > 0.0) {
                active.removeHold(entry.getKey());
                endHold(player, active, found.get(), held.ability(), (int) Math.max(0L, now - held.startTick()), now);
            }
        }
    }

    private static double upkeepOf(Ability ability) {
        return ability.upkeepPerSecond() * GLConfig.abilityCostMultiplier();
    }

    private static void refreshTicking(ServerPlayer player, ActiveAbilities active) {
        if (active.needsTicking()) {
            TICKING.add(player.getUUID());
        } else {
            TICKING.remove(player.getUUID());
        }
    }

    // --------------------------------------------------------------- checks

    private static boolean checkReady(ServerPlayer player, Ability ability, ResourceLocation id, int cost, long now) {
        AbilityState state = GLAbilityData.get(player);

        long until = state.cooldownUntil().getOrDefault(id, 0L);
        if (until > now) {
            deny(player, named(ability, " is on cooldown (" + seconds(until - now) + " s)."));
            return false;
        }
        ResourceType type = ability.resource();
        double current = currentOf(state, type, now);
        if (!state.infinite(type) && current < cost) {
            deny(player, Component.literal("Not enough " + type.label() + " (" + (int) current + "/" + cost + ")."));
            return false;
        }
        return true;
    }

    private static boolean checkCompatible(ServerPlayer player, ActiveAbilities active, Ability ability) {
        for (ResourceLocation otherId : active.activeIds()) {
            Optional<Ability> other = GLAbilities.REGISTRY.getOptional(otherId);
            if (other.isPresent() && !(ability.canCoexistWith(other.get()) && other.get().canCoexistWith(ability))) {
                deny(player, Component.empty().append(ability.displayName())
                        .append(Component.literal(" cannot be used together with "))
                        .append(other.get().displayName()).append(Component.literal(".")));
                return false;
            }
        }
        return true;
    }

    // -------------------------------------------------------------- costs

    private static double maxOf(ResourceType type) {
        return type == ResourceType.HAKI ? GLConfig.hakiMax() : GLConfig.staminaMax();
    }

    private static double regenOf(ResourceType type) {
        return type == ResourceType.HAKI ? GLConfig.hakiRegenPerTick() : GLConfig.staminaRegenPerTick();
    }

    private static double currentOf(AbilityState state, ResourceType type, long now) {
        return state.resourceNow(type, now, maxOf(type), regenOf(type));
    }

    private static int scaledCost(Ability ability) {
        return (int) Math.round(ability.staminaCost() * GLConfig.abilityCostMultiplier());
    }

    private static long scaledCooldown(Ability ability) {
        return Math.round(ability.cooldownTicks() * GLConfig.cooldownMultiplier());
    }

    private static AbilityState spendFrom(AbilityState state, ResourceType type, int cost, long now) {
        if (cost <= 0 || state.infinite(type)) {
            return state;
        }
        return state.withResource(type, currentOf(state, type, now) - cost, now);
    }

    private static void spend(ServerPlayer player, ResourceType type, int cost, long now) {
        if (cost > 0) {
            GLAbilityData.update(player, state -> spendFrom(state, type, cost, now));
        }
    }

    private static void startCooldown(ServerPlayer player, Ability ability, ResourceLocation id, long now) {
        long cooldown = scaledCooldown(ability);
        if (cooldown > 0) {
            GLAbilityData.update(player, state -> state.withCooldown(id, now + cooldown, now));
        }
    }

    private static void commit(ServerPlayer player, Ability ability, ResourceLocation id, int cost, long now) {
        long cooldown = scaledCooldown(ability);
        ResourceType type = ability.resource();
        GLAbilityData.update(player, state -> {
            AbilityState next = spendFrom(state, type, cost, now);
            return cooldown > 0 ? next.withCooldown(id, now + cooldown, now) : next;
        });
    }

    private static void award(ServerPlayer player, Ability ability) {
        ability.masterySystem().ifPresent(system -> MasteryManager.award(player, system, 1.0));
        ability.hakiAward().ifPresent(branch -> MasteryManager.awardHaki(player, branch, 1.0));
    }

    // ------------------------------------------------------------- network

    private static void broadcastEffect(ServerPlayer player, ResourceLocation id, AbilityPhase phase, float intensity) {
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(player,
                new AbilityEffectPayload(player.getId(), id, phase.ordinal(), intensity));
    }

    private static void broadcastActive(ServerPlayer player, ActiveAbilities active) {
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(player,
                new ActiveVisualsPayload(player.getId(), active.activeIds()));
    }

    // ------------------------------------------------------------- helpers

    private static Component named(Ability ability, String suffix) {
        return Component.empty().append(ability.displayName()).append(Component.literal(suffix));
    }

    private static void deny(ServerPlayer player, Component message) {
        player.displayClientMessage(message, true);
    }

    public static String seconds(long ticks) {
        return String.format(Locale.ROOT, "%.1f", ticks / 20.0);
    }

    private AbilityManager() {
    }
}
