package com.nerodev.grandline.ability;

/** How a key press turns into an ability. */
public enum ActivationType {
    /** One press = one use. Override Ability.execute. */
    PRESS,
    /** Press to turn on, press again to turn off. Override onToggleOn / onToggleOff. */
    TOGGLE,
    /** Active while the key is held. Override onHoldStart / onHoldTick / onHoldEnd. */
    HOLD,
    /** Hold to charge, release to fire. Override executeCharged. The server measures the charge time. */
    CHARGE
}
