package com.nerodev.grandline.ability;

/** What an ability spends. Each has its own bar, regeneration and "infinite" test switch. */
public enum ResourceType {
    STAMINA("stamina"),
    HAKI("Haki");

    private final String label;

    ResourceType(String label) {
        this.label = label;
    }

    public String label() {
        return label;
    }
}
