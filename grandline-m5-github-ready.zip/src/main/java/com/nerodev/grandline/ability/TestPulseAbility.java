package com.nerodev.grandline.ability;

import com.nerodev.grandline.GrandLineMod;
import com.nerodev.grandline.client.vfx.ClientVfx;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

import java.util.List;

/**
 * PRESS test ability: knocks everything within 6 blocks away from you.
 * Cost 20 stamina, cooldown 5 s, needs Rokushiki mastery 10 (so the mastery check can be tested).
 * Counter: knockback resistance (try holding Guard), and it does no damage.
 */
public final class TestPulseAbility extends Ability {

    private static final double RADIUS = 6.0;
    private static final int COLOR = 0x9FD8FF;

    public TestPulseAbility() {
        super(new Properties()
                .cooldown(100)
                .staminaCost(20)
                .requiresMastery(GrandLineMod.id("rokushiki"), 10));
    }

    @Override
    public boolean execute(ServerPlayer player) {
        ServerLevel level = (ServerLevel) player.level();
        boolean pvp = level.getServer().isPvpAllowed();
        AABB area = player.getBoundingBox().inflate(RADIUS);

        List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class, area,
                entity -> entity != player
                        && entity.isAlive()
                        && entity.distanceToSqr(player) <= RADIUS * RADIUS
                        && (pvp || !(entity instanceof Player)));

        for (LivingEntity target : targets) {
            // knockback pushes away from the given direction, so pass the direction toward the caster
            target.knockback(1.5, player.getX() - target.getX(), player.getZ() - target.getZ());
            target.hurtMarked = true;
        }
        return true;
    }

    @Override
    public void clientEffects(Level level, LivingEntity caster, AbilityPhase phase, float intensity) {
        if (phase != AbilityPhase.USE) {
            return;
        }
        double x = caster.getX();
        double y = caster.getY();
        double z = caster.getZ();
        ClientVfx.ring(level, x, y + 0.15, z, 0.6f, 28, COLOR, 0.45f, 0.30f, 14);
        ClientVfx.ring(level, x, y + 0.15, z, 0.4f, 20, 0xFFFFFF, 0.28f, 0.22f, 12);
        ClientVfx.shockwave(level, x, y + 1.0, z, COLOR, 0.5f, 5.5f, 9);
        ClientVfx.sparks(level, x, y + 1.0, z, 14, COLOR, 0.35f);
        ClientVfx.localShake(caster, 0.9f, 10);
    }
}
