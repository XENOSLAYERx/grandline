package com.nerodev.grandline.ability;

import net.minecraft.resources.ResourceLocation;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Client-side: which abilities are currently on (toggled or held) for each visible entity, so
 * looping visuals can run. Plain data, safe to load on any side; touched on the client thread only.
 * Cleared on disconnect, and entries are dropped when their entity is gone.
 */
public final class ClientActiveVisuals {

    private static final Map<Integer, List<ResourceLocation>> ACTIVE = new HashMap<>();

    public static void set(int entityId, List<ResourceLocation> abilities) {
        if (abilities.isEmpty()) {
            ACTIVE.remove(entityId);
        } else {
            ACTIVE.put(entityId, List.copyOf(abilities));
        }
    }

    public static List<ResourceLocation> get(int entityId) {
        return ACTIVE.getOrDefault(entityId, List.of());
    }

    public static void remove(int entityId) {
        ACTIVE.remove(entityId);
    }

    /** A copy, so callers may remove entries while looping. */
    public static Map<Integer, List<ResourceLocation>> all() {
        return new HashMap<>(ACTIVE);
    }

    public static void clear() {
        ACTIVE.clear();
    }

    private ClientActiveVisuals() {
    }
}
