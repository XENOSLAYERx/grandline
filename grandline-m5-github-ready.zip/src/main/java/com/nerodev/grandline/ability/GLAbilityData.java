package com.nerodev.grandline.ability;

import com.nerodev.grandline.config.GLConfig;
import com.nerodev.grandline.data.CodecHolder;
import com.nerodev.grandline.data.GLAttachments;
import com.nerodev.grandline.network.SyncAbilityPayload;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.function.UnaryOperator;

/** Server-side access to AbilityState. update(...) saves and syncs once. Nothing here runs per tick. */
public final class GLAbilityData {

    public static AbilityState get(ServerPlayer player) {
        return player.getData(GLAttachments.ABILITY_STATE).get();
    }

    public static void update(ServerPlayer player, UnaryOperator<AbilityState> change) {
        CodecHolder<AbilityState> holder = player.getData(GLAttachments.ABILITY_STATE);
        holder.set(change.apply(holder.get()));
        sync(player);
    }

    public static AbilityView view(ServerPlayer player) {
        long now = player.level().getGameTime();
        AbilityState state = get(player);
        double max = GLConfig.staminaMax();
        double regen = GLConfig.staminaRegenPerTick();
        double hakiMax = GLConfig.hakiMax();
        double hakiRegen = GLConfig.hakiRegenPerTick();
        return new AbilityView(
                state.resourceNow(ResourceType.STAMINA, now, max, regen), max, regen, now,
                state.infiniteStamina(), state.cooldownUntil(),
                state.resourceNow(ResourceType.HAKI, now, hakiMax, hakiRegen), hakiMax, hakiRegen,
                state.infiniteHaki());
    }

    public static void sync(ServerPlayer player) {
        if (player.connection == null) {
            return; // fake players have no connection
        }
        PacketDistributor.sendToPlayer(player, new SyncAbilityPayload(view(player)));
    }

    private GLAbilityData() {
    }
}
