package com.nerodev.grandline.ability;

import com.nerodev.grandline.network.ActiveVisualsPayload;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.List;

/** Server events that keep ability state honest. Everything is cleaned up on death and logout. */
public final class AbilityEvents {

    public static void onServerTick(ServerTickEvent.Post event) {
        AbilityManager.tickActive(event.getServer());
    }

    public static void onLoggedOut(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            AbilityManager.endAll(player);
            AbilityManager.forget(player);
        }
    }

    public static void onDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            AbilityManager.endAll(player);
        }
    }

    /** Someone started seeing a player: tell them which abilities that player already has on. */
    public static void onStartTracking(PlayerEvent.StartTracking event) {
        if (event.getTarget() instanceof ServerPlayer target && event.getEntity() instanceof ServerPlayer watcher) {
            List<net.minecraft.resources.ResourceLocation> active = AbilityManager.activeIds(target);
            if (!active.isEmpty()) {
                PacketDistributor.sendToPlayer(watcher, new ActiveVisualsPayload(target.getId(), active));
            }
        }
    }

    private AbilityEvents() {
    }
}
