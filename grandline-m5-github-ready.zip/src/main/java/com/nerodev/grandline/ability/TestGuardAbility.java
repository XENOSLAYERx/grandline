package com.nerodev.grandline.ability;

import com.nerodev.grandline.GrandLineMod;
import com.nerodev.grandline.client.vfx.ClientVfx;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;

/**
 * HOLD test ability: while the key is held you cannot be knocked back. Costs 5 to start and drains
 * 6 stamina per second. Group "test_stance": cannot be used together with Aura.
 * Counter: it drains stamina and ends when it runs out; it does not stop damage.
 */
public final class TestGuardAbility extends Ability {

    private static final ResourceLocation KNOCKBACK_ID = GrandLineMod.id("test_guard_knockback");
    private static final int COLOR = 0x4DA6FF;

    public TestGuardAbility() {
        super(new Properties()
                .activation(ActivationType.HOLD)
                .staminaCost(5)
                .upkeepPerSecond(6.0)
                .cooldown(30)
                .group(GrandLineMod.id("test_stance")));
    }

    @Override
    public void onHoldStart(ServerPlayer player) {
        AttributeInstance resistance = player.getAttribute(Attributes.KNOCKBACK_RESISTANCE);
        if (resistance != null && !resistance.hasModifier(KNOCKBACK_ID)) {
            resistance.addTransientModifier(new AttributeModifier(KNOCKBACK_ID, 1.0, AttributeModifier.Operation.ADD_VALUE));
        }
    }

    @Override
    public void onHoldEnd(ServerPlayer player, int heldTicks) {
        AttributeInstance resistance = player.getAttribute(Attributes.KNOCKBACK_RESISTANCE);
        if (resistance != null) {
            resistance.removeModifier(KNOCKBACK_ID);
        }
    }

    @Override
    public void clientEffects(Level level, LivingEntity caster, AbilityPhase phase, float intensity) {
        double x = caster.getX();
        double y = caster.getY();
        double z = caster.getZ();
        if (phase == AbilityPhase.HOLD_START) {
            ClientVfx.ring(level, x, y + 0.1, z, 0.9f, 20, COLOR, 0.12f, 0.26f, 12);
        } else if (phase == AbilityPhase.HOLD_END) {
            ClientVfx.burst(level, x, y + 0.9, z, 8, COLOR, 0.1f, 0.22f, 10);
        }
    }

    @Override
    public void clientTick(Level level, LivingEntity caster) {
        if (caster.tickCount % 4 == 0) {
            ClientVfx.ring(level, caster.getX(), caster.getY() + 0.05, caster.getZ(), 0.9f, 8, COLOR, 0.0f, 0.22f, 8);
        }
    }
}
