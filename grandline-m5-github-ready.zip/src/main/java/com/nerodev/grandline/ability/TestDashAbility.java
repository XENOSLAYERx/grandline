package com.nerodev.grandline.ability;

import com.nerodev.grandline.client.vfx.ClientVfx;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * CHARGE test ability: hold to charge up to 1 second, release to dash where you look. A longer
 * charge dashes further. Releasing before 0.2 s does nothing. Cost 25, cooldown 3 s.
 * The server measures the charge time, so the client cannot fake a full charge.
 */
public final class TestDashAbility extends Ability {

    private static final int COLOR = 0xFF7A3D;

    public TestDashAbility() {
        super(new Properties()
                .activation(ActivationType.CHARGE)
                .charge(4, 20)
                .staminaCost(25)
                .cooldown(60));
    }

    @Override
    public boolean executeCharged(ServerPlayer player, float fraction) {
        Vec3 look = player.getLookAngle();
        double speed = 0.6 + 1.8 * fraction;
        player.setDeltaMovement(look.x * speed, Math.max(0.15, look.y * speed * 0.5), look.z * speed);
        player.hurtMarked = true; // makes the server send the new velocity to the player
        player.fallDistance = 0.0f;
        return true;
    }

    @Override
    public void clientEffects(Level level, LivingEntity caster, AbilityPhase phase, float intensity) {
        double x = caster.getX();
        double y = caster.getY();
        double z = caster.getZ();
        if (phase == AbilityPhase.CHARGE_START) {
            ClientVfx.ring(level, x, y + 0.1, z, 0.3f, 14, COLOR, 0.15f, 0.22f, 10);
        } else if (phase == AbilityPhase.CHARGE_RELEASE) {
            ClientVfx.burst(level, x, y + 0.8, z, (int) (10 + 20 * intensity), COLOR, 0.25f + 0.3f * intensity, 0.3f, 14);
            ClientVfx.sparks(level, x, y + 0.8, z, (int) (6 + 10 * intensity), 0xFFE2B0, 0.4f);
            ClientVfx.localShake(caster, 0.4f + 0.8f * intensity, 8);
            ClientVfx.localFovPunch(caster, 10.0f * intensity, 8);
        }
    }
}
