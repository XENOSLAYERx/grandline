package com.nerodev.grandline.ability;

import com.nerodev.grandline.GrandLineMod;
import com.nerodev.grandline.fruit.ability.GumBalloonAbility;
import com.nerodev.grandline.fruit.ability.GumBazookaAbility;
import com.nerodev.grandline.fruit.ability.GumGatlingAbility;
import com.nerodev.grandline.fruit.ability.GumPistolAbility;
import com.nerodev.grandline.fruit.ability.GumRocketAbility;
import com.nerodev.grandline.fruit.ability.LeopardBeastAbility;
import com.nerodev.grandline.fruit.ability.LeopardClawAbility;
import com.nerodev.grandline.fruit.ability.LeopardHybridAbility;
import com.nerodev.grandline.fruit.ability.LeopardPounceAbility;
import com.nerodev.grandline.fruit.ability.MeraDashAbility;
import com.nerodev.grandline.fruit.ability.MeraFlameBodyAbility;
import com.nerodev.grandline.fruit.ability.MeraHikenAbility;
import com.nerodev.grandline.fruit.ability.MeraJetAbility;
import com.nerodev.grandline.haki.ability.ArmamentAbility;
import com.nerodev.grandline.haki.ability.ArmamentAdvancedAbility;
import com.nerodev.grandline.haki.ability.ConquerorsAbility;
import com.nerodev.grandline.haki.ability.ObservationAbility;
import com.nerodev.grandline.registry.GLRegistries;
import net.minecraft.core.Registry;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

/** The ability registry (built on GLRegistries) and every ability in it. */
public final class GLAbilities {

    public static final Registry<Ability> REGISTRY = GLRegistries.create("ability");

    private static final DeferredRegister<Ability> ABILITIES = DeferredRegister.create(REGISTRY, GrandLineMod.MODID);

    // Framework tests, one per activation type (/onepiece test).
    public static final Supplier<Ability> TEST_PULSE = ABILITIES.register("test_pulse", () -> new TestPulseAbility());
    public static final Supplier<Ability> TEST_AURA = ABILITIES.register("test_aura", () -> new TestAuraAbility());
    public static final Supplier<Ability> TEST_GUARD = ABILITIES.register("test_guard", () -> new TestGuardAbility());
    public static final Supplier<Ability> TEST_DASH = ABILITIES.register("test_dash", () -> new TestDashAbility());

    // Gum-Gum Fruit (Paramecia)
    public static final Supplier<Ability> GUM_PISTOL = ABILITIES.register("gum_pistol", () -> new GumPistolAbility());
    public static final Supplier<Ability> GUM_ROCKET = ABILITIES.register("gum_rocket", () -> new GumRocketAbility());
    public static final Supplier<Ability> GUM_BALLOON = ABILITIES.register("gum_balloon", () -> new GumBalloonAbility());
    public static final Supplier<Ability> GUM_BAZOOKA = ABILITIES.register("gum_bazooka", () -> new GumBazookaAbility());
    public static final Supplier<Ability> GUM_GATLING = ABILITIES.register("gum_gatling", () -> new GumGatlingAbility());

    // Flame-Flame Fruit (Logia)
    public static final Supplier<Ability> MERA_FLAME_BODY = ABILITIES.register("mera_flame_body", () -> new MeraFlameBodyAbility());
    public static final Supplier<Ability> MERA_HIKEN = ABILITIES.register("mera_hiken", () -> new MeraHikenAbility());
    public static final Supplier<Ability> MERA_DASH = ABILITIES.register("mera_dash", () -> new MeraDashAbility());
    public static final Supplier<Ability> MERA_JET = ABILITIES.register("mera_jet", () -> new MeraJetAbility());

    // Cat-Cat Fruit, Model: Leopard (Zoan)
    public static final Supplier<Ability> LEOPARD_HYBRID = ABILITIES.register("leopard_hybrid", () -> new LeopardHybridAbility());
    public static final Supplier<Ability> LEOPARD_BEAST = ABILITIES.register("leopard_beast", () -> new LeopardBeastAbility());
    public static final Supplier<Ability> LEOPARD_CLAW = ABILITIES.register("leopard_claw", () -> new LeopardClawAbility());
    public static final Supplier<Ability> LEOPARD_POUNCE = ABILITIES.register("leopard_pounce", () -> new LeopardPounceAbility());

    // Haki (fixed keys, see HakiSlots)
    public static final Supplier<Ability> HAKI_OBSERVATION = ABILITIES.register("haki_observation", () -> new ObservationAbility());
    public static final Supplier<Ability> HAKI_ARMAMENT = ABILITIES.register("haki_armament", () -> new ArmamentAbility());
    public static final Supplier<Ability> HAKI_ARMAMENT_ADVANCED = ABILITIES.register("haki_armament_advanced", () -> new ArmamentAdvancedAbility());
    public static final Supplier<Ability> HAKI_CONQUERORS = ABILITIES.register("haki_conquerors", () -> new ConquerorsAbility());

    public static void register(IEventBus modEventBus) {
        ABILITIES.register(modEventBus);
    }

    private GLAbilities() {
    }
}
