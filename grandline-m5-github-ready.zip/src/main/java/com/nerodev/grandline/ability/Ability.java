package com.nerodev.grandline.ability;

import com.nerodev.grandline.data.HakiBranch;
import com.nerodev.grandline.data.PlayerData;
import net.minecraft.Util;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;

import java.util.Optional;

/**
 * Base class for everything a key can run: fruits, Haki, styles, Rokushiki.
 *
 * The server decides everything. AbilityManager checks unlock, slot, mastery, cooldown, stamina and
 * compatibility BEFORE any hook below is called, so hooks only contain the effect itself.
 *
 * Which hooks to override depends on the activation type (see ActivationType). Visual hooks
 * (clientEffects, clientTick) run on clients only and must stay cheap.
 */
public abstract class Ability {

    public record MasteryRequirement(ResourceLocation system, int level) {
    }

    public record HakiRequirement(HakiBranch branch, int level) {
    }

    public static final class Properties {
        private int cooldownTicks = 0;
        private int staminaCost = 0;
        private MasteryRequirement mastery = null;
        private ActivationType activation = ActivationType.PRESS;
        private double upkeepPerSecond = 0.0;
        private int minChargeTicks = 0;
        private int maxChargeTicks = 20;
        private ResourceLocation group = null;
        private ResourceLocation masterySystem = null;
        private ResourceType resource = ResourceType.STAMINA;
        private HakiRequirement hakiRequirement = null;
        private HakiBranch hakiAward = null;

        public Properties cooldown(int ticks) {
            this.cooldownTicks = Math.max(0, ticks);
            return this;
        }

        public Properties staminaCost(int cost) {
            this.staminaCost = Math.max(0, cost);
            return this;
        }

        public Properties requiresMastery(ResourceLocation system, int level) {
            this.mastery = new MasteryRequirement(system, level);
            return this;
        }

        public Properties activation(ActivationType type) {
            this.activation = type;
            return this;
        }

        /** Stamina drained per second while a TOGGLE is on or a HOLD is held. */
        public Properties upkeepPerSecond(double perSecond) {
            this.upkeepPerSecond = Math.max(0.0, perSecond);
            return this;
        }

        /** CHARGE only: releasing before minTicks does nothing; maxTicks is a full charge. */
        public Properties charge(int minTicks, int maxTicks) {
            this.minChargeTicks = Math.max(0, minTicks);
            this.maxChargeTicks = Math.max(1, maxTicks);
            return this;
        }

        /** Using this ability earns mastery in the given system (scaled by the masteryGainMultiplier config). */
        public Properties awardsMastery(ResourceLocation system) {
            this.masterySystem = system;
            return this;
        }

        /** What this ability spends (cost and upkeep). Default stamina. */
        public Properties resource(ResourceType type) {
            this.resource = type;
            return this;
        }

        /** Usable only with at least this level in the Haki branch. Such abilities need no unlock entry. */
        public Properties requiresHaki(HakiBranch branch, int level) {
            this.hakiRequirement = new HakiRequirement(branch, level);
            return this;
        }

        /** Using this ability raises the Haki branch level (scaled by masteryGainMultiplier). */
        public Properties awardsHaki(HakiBranch branch) {
            this.hakiAward = branch;
            return this;
        }

        /** Abilities with the same group cannot be active together (for example two body transformations). */
        public Properties group(ResourceLocation groupId) {
            this.group = groupId;
            return this;
        }
    }

    private final int cooldownTicks;
    private final int staminaCost;
    private final Optional<MasteryRequirement> mastery;
    private final ActivationType activation;
    private final double upkeepPerSecond;
    private final int minChargeTicks;
    private final int maxChargeTicks;
    private final Optional<ResourceLocation> group;
    private final Optional<ResourceLocation> masterySystem;
    private final ResourceType resource;
    private final Optional<HakiRequirement> hakiRequirement;
    private final Optional<HakiBranch> hakiAward;

    protected Ability(Properties properties) {
        this.cooldownTicks = properties.cooldownTicks;
        this.staminaCost = properties.staminaCost;
        this.mastery = Optional.ofNullable(properties.mastery);
        this.activation = properties.activation;
        this.upkeepPerSecond = properties.upkeepPerSecond;
        this.minChargeTicks = properties.minChargeTicks;
        this.maxChargeTicks = properties.maxChargeTicks;
        this.group = Optional.ofNullable(properties.group);
        this.masterySystem = Optional.ofNullable(properties.masterySystem);
        this.resource = properties.resource;
        this.hakiRequirement = Optional.ofNullable(properties.hakiRequirement);
        this.hakiAward = Optional.ofNullable(properties.hakiAward);
    }

    public int cooldownTicks() {
        return cooldownTicks;
    }

    public int staminaCost() {
        return staminaCost;
    }

    public Optional<MasteryRequirement> masteryRequirement() {
        return mastery;
    }

    public ActivationType activation() {
        return activation;
    }

    public double upkeepPerSecond() {
        return upkeepPerSecond;
    }

    public int minChargeTicks() {
        return minChargeTicks;
    }

    public int maxChargeTicks() {
        return maxChargeTicks;
    }

    public Optional<ResourceLocation> group() {
        return group;
    }

    public Optional<ResourceLocation> masterySystem() {
        return masterySystem;
    }

    public ResourceType resource() {
        return resource;
    }

    public Optional<HakiRequirement> hakiRequirement() {
        return hakiRequirement;
    }

    public Optional<HakiBranch> hakiAward() {
        return hakiAward;
    }

    /** Haki abilities are unlocked by their Haki level; everything else by an entry in the player's unlocks. */
    public boolean isUnlocked(PlayerData data) {
        if (hakiRequirement.isPresent()) {
            return data.haki().get(hakiRequirement.get().branch()) >= hakiRequirement.get().level();
        }
        return data.unlocks().abilities().contains(id());
    }

    public ResourceLocation id() {
        return GLAbilities.REGISTRY.getKey(this);
    }

    public String descriptionId() {
        return Util.makeDescriptionId("ability", id());
    }

    public Component displayName() {
        return Component.translatable(descriptionId());
    }

    /** Central compatibility rule: two active abilities in the same group do not coexist. Override for special cases. */
    public boolean canCoexistWith(Ability other) {
        if (group.isEmpty() || other.group.isEmpty()) {
            return true;
        }
        return !group.get().equals(other.group.get());
    }

    /** Extra server-side condition (for example "needs a target"). Explain a refusal to the player yourself. */
    public boolean canActivate(ServerPlayer player) {
        return true;
    }

    // ---- PRESS ----

    /** Server only. Return false if nothing happened; then no cost is charged and no cooldown starts. */
    public boolean execute(ServerPlayer player) {
        return false;
    }

    // ---- TOGGLE ----

    public void onToggleOn(ServerPlayer player) {
    }

    /** Also called when the ability is forced off (out of stamina, death, logout). Undo everything onToggleOn did. */
    public void onToggleOff(ServerPlayer player) {
    }

    /** Every server tick while this toggle is on. Keep it cheap; use player.tickCount % N for slower effects. */
    public void onToggleTick(ServerPlayer player) {
    }

    // ---- HOLD ----

    public void onHoldStart(ServerPlayer player) {
    }

    /** Every server tick while held. Keep it cheap and never scan the world here. */
    public void onHoldTick(ServerPlayer player, int heldTicks) {
    }

    /** Also called when the hold is forced to end (out of stamina, death, logout). Undo everything onHoldStart did. */
    public void onHoldEnd(ServerPlayer player, int heldTicks) {
    }

    // ---- CHARGE ----

    /** fraction is 0..1, measured by the server. Return false to cancel without cost or cooldown. */
    public boolean executeCharged(ServerPlayer player, float fraction) {
        return false;
    }

    // ---- visuals (client only) ----

    /** One-shot visuals for a moment in the ability's life. Called on every client that can see the caster. */
    public void clientEffects(Level level, LivingEntity caster, AbilityPhase phase, float intensity) {
    }

    /** Looping visuals, called every client tick while a TOGGLE is on or a HOLD is held. */
    public void clientTick(Level level, LivingEntity caster) {
    }
}
