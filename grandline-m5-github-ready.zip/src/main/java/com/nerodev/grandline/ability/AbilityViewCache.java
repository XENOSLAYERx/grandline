package com.nerodev.grandline.ability;

/** Client-side copy of the last AbilityView the server sent. Plain data, safe to load on any side; cleared on disconnect. */
public final class AbilityViewCache {

    private static volatile AbilityView view = null;

    public static AbilityView get() {
        return view;
    }

    public static void set(AbilityView newView) {
        view = newView;
    }

    public static void clear() {
        view = null;
    }

    private AbilityViewCache() {
    }
}
