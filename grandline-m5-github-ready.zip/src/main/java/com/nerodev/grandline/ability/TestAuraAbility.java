package com.nerodev.grandline.ability;

import com.nerodev.grandline.GrandLineMod;
import com.nerodev.grandline.client.vfx.ClientVfx;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;

/**
 * TOGGLE test ability: +40% movement speed while on. Costs 10 to switch on, drains 4 stamina per
 * second, cooldown 2 s after switching off. Group "test_stance": cannot be on together with Guard.
 * Counter: the stamina drain; when stamina runs out it switches itself off.
 */
public final class TestAuraAbility extends Ability {

    private static final ResourceLocation SPEED_ID = GrandLineMod.id("test_aura_speed");
    private static final int COLOR = 0xFFC94D;

    public TestAuraAbility() {
        super(new Properties()
                .activation(ActivationType.TOGGLE)
                .staminaCost(10)
                .upkeepPerSecond(4.0)
                .cooldown(40)
                .group(GrandLineMod.id("test_stance")));
    }

    @Override
    public void onToggleOn(ServerPlayer player) {
        AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null && !speed.hasModifier(SPEED_ID)) {
            speed.addTransientModifier(new AttributeModifier(SPEED_ID, 0.4, AttributeModifier.Operation.ADD_MULTIPLIED_BASE));
        }
    }

    @Override
    public void onToggleOff(ServerPlayer player) {
        AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null) {
            speed.removeModifier(SPEED_ID);
        }
    }

    @Override
    public void clientEffects(Level level, LivingEntity caster, AbilityPhase phase, float intensity) {
        double x = caster.getX();
        double y = caster.getY();
        double z = caster.getZ();
        if (phase == AbilityPhase.TOGGLE_ON) {
            ClientVfx.ring(level, x, y + 0.1, z, 0.5f, 24, COLOR, 0.3f, 0.28f, 14);
            ClientVfx.sparks(level, x, y + 1.0, z, 16, COLOR, 0.25f);
            ClientVfx.localFovPunch(caster, 4.0f, 8);
        } else if (phase == AbilityPhase.TOGGLE_OFF) {
            ClientVfx.burst(level, x, y + 1.0, z, 10, COLOR, 0.12f, 0.25f, 14);
        }
    }

    @Override
    public void clientTick(Level level, LivingEntity caster) {
        if (caster.tickCount % 3 == 0) {
            ClientVfx.rise(level, caster, COLOR, 2);
        }
    }
}
