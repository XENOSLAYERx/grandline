package com.nerodev.grandline.ability;

/** Moments in an ability's life that play visuals on clients (Ability.clientEffects). */
public enum AbilityPhase {
    USE,
    TOGGLE_ON,
    TOGGLE_OFF,
    HOLD_START,
    HOLD_END,
    CHARGE_START,
    CHARGE_RELEASE;

    public static AbilityPhase fromOrdinal(int ordinal) {
        AbilityPhase[] all = values();
        return all[Math.max(0, Math.min(all.length - 1, ordinal))];
    }
}
