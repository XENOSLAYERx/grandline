package com.nerodev.grandline.ability;

import net.minecraft.resources.ResourceLocation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Runtime state of what a player has switched on or is holding. Server only.
 *
 * Deliberately an attachment WITHOUT a serializer: it is never saved and never copied on death, so
 * a toggle can never survive a relog or a death, and there is no static map to leak or clean up.
 */
public final class ActiveAbilities {

    /** charge = true for CHARGE abilities (no per-tick work), false for HOLD abilities. */
    public record Held(ResourceLocation ability, long startTick, boolean charge) {
    }

    private final Set<ResourceLocation> toggled = new LinkedHashSet<>();
    private final Map<Integer, Held> holds = new HashMap<>();

    public boolean isToggled(ResourceLocation id) {
        return toggled.contains(id);
    }

    public void setToggled(ResourceLocation id, boolean on) {
        if (on) {
            toggled.add(id);
        } else {
            toggled.remove(id);
        }
    }

    public List<ResourceLocation> toggledIds() {
        return List.copyOf(toggled);
    }

    public boolean holdsSlot(int slot) {
        return holds.containsKey(slot);
    }

    public void putHold(int slot, Held held) {
        holds.put(slot, held);
    }

    public Held removeHold(int slot) {
        return holds.remove(slot);
    }

    public Map<Integer, Held> holdsCopy() {
        return Map.copyOf(holds);
    }

    /** Ids that show looping visuals and take part in compatibility checks: toggles and HOLD abilities. */
    public List<ResourceLocation> activeIds() {
        List<ResourceLocation> ids = new ArrayList<>(toggled);
        for (Held held : holds.values()) {
            if (!held.charge() && !ids.contains(held.ability())) {
                ids.add(held.ability());
            }
        }
        return ids;
    }

    public boolean needsTicking() {
        if (!toggled.isEmpty()) {
            return true;
        }
        for (Held held : holds.values()) {
            if (!held.charge()) {
                return true;
            }
        }
        return false;
    }

    public void clear() {
        toggled.clear();
        holds.clear();
    }
}
