package com.nerodev.grandline.ability;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.resources.ResourceLocation;

import java.util.HashMap;
import java.util.Map;

/**
 * Server-side runtime state per player: stamina, Haki energy and cooldowns. Saved with the player.
 *
 * Nothing here ticks. A resource is stored as (value, time) and computed on demand; a cooldown is
 * stored as the game time it ends. So there is no per-tick work and no state to clean up.
 */
public record AbilityState(
        double stamina,
        long staminaTime,
        double haki,
        long hakiTime,
        Map<ResourceLocation, Long> cooldownUntil,
        boolean infiniteStamina,
        boolean infiniteHaki) {

    /** A stored value below 0 means "full". */
    public static final double FULL = -1.0;

    public static final AbilityState DEFAULT = new AbilityState(FULL, 0L, FULL, 0L, Map.of(), false, false);

    public static final Codec<AbilityState> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.DOUBLE.optionalFieldOf("stamina", FULL).forGetter(AbilityState::stamina),
            Codec.LONG.optionalFieldOf("stamina_time", 0L).forGetter(AbilityState::staminaTime),
            Codec.DOUBLE.optionalFieldOf("haki", FULL).forGetter(AbilityState::haki),
            Codec.LONG.optionalFieldOf("haki_time", 0L).forGetter(AbilityState::hakiTime),
            Codec.unboundedMap(ResourceLocation.CODEC, Codec.LONG).optionalFieldOf("cooldowns", Map.of()).forGetter(AbilityState::cooldownUntil),
            Codec.BOOL.optionalFieldOf("infinite_stamina", false).forGetter(AbilityState::infiniteStamina),
            Codec.BOOL.optionalFieldOf("infinite_haki", false).forGetter(AbilityState::infiniteHaki)
    ).apply(instance, AbilityState::new));

    public AbilityState {
        cooldownUntil = Map.copyOf(cooldownUntil);
    }

    // ---- generic, by resource ----

    public double resourceNow(ResourceType type, long now, double max, double regenPerTick) {
        double stored = type == ResourceType.HAKI ? haki : stamina;
        long since = type == ResourceType.HAKI ? hakiTime : staminaTime;
        if (stored < 0) {
            return max;
        }
        return Math.min(max, stored + Math.max(0L, now - since) * regenPerTick);
    }

    public boolean infinite(ResourceType type) {
        return type == ResourceType.HAKI ? infiniteHaki : infiniteStamina;
    }

    public AbilityState withResource(ResourceType type, double value, long now) {
        double clamped = Math.max(0.0, value);
        return type == ResourceType.HAKI
                ? new AbilityState(stamina, staminaTime, clamped, now, cooldownUntil, infiniteStamina, infiniteHaki)
                : new AbilityState(clamped, now, haki, hakiTime, cooldownUntil, infiniteStamina, infiniteHaki);
    }

    public AbilityState withFull(ResourceType type) {
        return type == ResourceType.HAKI
                ? new AbilityState(stamina, staminaTime, FULL, 0L, cooldownUntil, infiniteStamina, infiniteHaki)
                : new AbilityState(FULL, 0L, haki, hakiTime, cooldownUntil, infiniteStamina, infiniteHaki);
    }

    public AbilityState withInfinite(ResourceType type, boolean value) {
        return type == ResourceType.HAKI
                ? new AbilityState(stamina, staminaTime, haki, hakiTime, cooldownUntil, infiniteStamina, value)
                : new AbilityState(stamina, staminaTime, haki, hakiTime, cooldownUntil, value, infiniteHaki);
    }

    // ---- stamina shortcuts (kept for older callers) ----

    public double staminaNow(long now, double max, double regenPerTick) {
        return resourceNow(ResourceType.STAMINA, now, max, regenPerTick);
    }

    public AbilityState withStamina(double value, long now) {
        return withResource(ResourceType.STAMINA, value, now);
    }

    public AbilityState withFullStamina() {
        return withFull(ResourceType.STAMINA);
    }

    public AbilityState withInfiniteStamina(boolean infinite) {
        return withInfinite(ResourceType.STAMINA, infinite);
    }

    // ---- cooldowns ----

    /** Adds a cooldown and drops cooldowns that already ended, so the map stays small. */
    public AbilityState withCooldown(ResourceLocation id, long until, long now) {
        Map<ResourceLocation, Long> updated = new HashMap<>();
        cooldownUntil.forEach((key, end) -> {
            if (end > now) {
                updated.put(key, end);
            }
        });
        updated.put(id, until);
        return new AbilityState(stamina, staminaTime, haki, hakiTime, updated, infiniteStamina, infiniteHaki);
    }

    public AbilityState clearCooldowns() {
        return new AbilityState(stamina, staminaTime, haki, hakiTime, Map.of(), infiniteStamina, infiniteHaki);
    }
}
