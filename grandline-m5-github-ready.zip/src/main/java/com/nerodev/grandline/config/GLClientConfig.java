package com.nerodev.grandline.config;

import net.neoforged.neoforge.common.ModConfigSpec;

/**
 * config/grandline-client.toml. Player-side comfort and performance settings; the server cannot
 * change them. Read on the client only.
 */
public final class GLClientConfig {
    public static final ModConfigSpec SPEC;

    public static final ModConfigSpec.DoubleValue VFX_DENSITY;
    public static final ModConfigSpec.DoubleValue SCREEN_SHAKE;

    static {
        ModConfigSpec.Builder b = new ModConfigSpec.Builder();
        b.comment("Presentation settings").push("presentation");

        VFX_DENSITY = b
                .comment("How many ability particles are spawned. 1 = full, 0.5 = half, 0 = none. Lower this if your FPS drops in big fights.")
                .defineInRange("vfxDensity", 1.0, 0.0, 1.0);
        SCREEN_SHAKE = b
                .comment("Strength of screen shake. 1 = full, 0 = off.")
                .defineInRange("screenShake", 1.0, 0.0, 1.0);

        b.pop();
        SPEC = b.build();
    }

    public static float vfxDensity() {
        try {
            return VFX_DENSITY.get().floatValue();
        } catch (IllegalStateException e) {
            return 1.0f;
        }
    }

    public static float screenShake() {
        try {
            return SCREEN_SHAKE.get().floatValue();
        } catch (IllegalStateException e) {
            return 1.0f;
        }
    }

    private GLClientConfig() {
    }
}
