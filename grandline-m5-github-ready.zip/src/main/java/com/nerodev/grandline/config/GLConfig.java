package com.nerodev.grandline.config;

import com.nerodev.grandline.GrandLineMod;
import net.neoforged.neoforge.common.ModConfigSpec;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * config/grandline-common.toml
 *
 * Only options that already do something live here. Further gameplay options (mastery gain, PvP
 * toggle, ...) are added in the milestone that makes them work.
 */
public final class GLConfig {
    public static final ModConfigSpec SPEC;

    public static final ModConfigSpec.ConfigValue<String> CREATOR_UUIDS;
    public static final ModConfigSpec.BooleanValue SINGLEPLAYER_OWNER_IS_CREATOR;
    public static final ModConfigSpec.BooleanValue OP_FALLBACK;
    public static final ModConfigSpec.IntValue MODERATOR_OP_LEVEL;
    public static final ModConfigSpec.IntValue ADMIN_OP_LEVEL;
    public static final ModConfigSpec.IntValue CREATOR_OP_LEVEL;

    public static final ModConfigSpec.IntValue STAMINA_MAX;
    public static final ModConfigSpec.DoubleValue STAMINA_REGEN_PER_SECOND;
    public static final ModConfigSpec.IntValue HAKI_MAX;
    public static final ModConfigSpec.DoubleValue HAKI_REGEN_PER_SECOND;
    public static final ModConfigSpec.DoubleValue COOLDOWN_MULTIPLIER;
    public static final ModConfigSpec.DoubleValue ABILITY_COST_MULTIPLIER;
    public static final ModConfigSpec.DoubleValue MASTERY_GAIN_MULTIPLIER;

    public static final ModConfigSpec.BooleanValue VERBOSE_LOGGING;

    static {
        ModConfigSpec.Builder b = new ModConfigSpec.Builder();

        b.comment("Who may use Moderator / Admin / Creator tools.").push("permissions");

        CREATOR_UUIDS = b
                .comment("Players that always get the CREATOR tier, as a comma-separated list of UUIDs.",
                        "Example: \"069a79f4-44e9-4726-a5be-fca90e38aaf5, 61699b2e-d327-4a01-9f1e-0ea8c3f06bc6\"",
                        "Run /onepiece debug permissions in game to see your own UUID.")
                .define("creatorUuids", "");

        SINGLEPLAYER_OWNER_IS_CREATOR = b
                .comment("The owner of a singleplayer world is CREATOR even with cheats off.")
                .define("singleplayerOwnerIsCreator", true);

        OP_FALLBACK = b
                .comment("Players who are not in creatorUuids get a tier from their vanilla op level (below).")
                .define("opFallback", true);

        MODERATOR_OP_LEVEL = b
                .comment("Vanilla op level that gives MODERATOR.")
                .defineInRange("moderatorOpLevel", 2, 1, 4);
        ADMIN_OP_LEVEL = b
                .comment("Vanilla op level that gives ADMIN.")
                .defineInRange("adminOpLevel", 3, 1, 4);
        CREATOR_OP_LEVEL = b
                .comment("Vanilla op level that gives CREATOR.")
                .defineInRange("creatorOpLevel", 4, 1, 4);

        b.pop();

        b.comment("Ability resources and balance. These apply on the server.").push("abilities");

        STAMINA_MAX = b
                .comment("Maximum stamina.")
                .defineInRange("staminaMax", 100, 1, 10000);
        STAMINA_REGEN_PER_SECOND = b
                .comment("Stamina regained per second.")
                .defineInRange("staminaRegenPerSecond", 8.0, 0.0, 1000.0);
        HAKI_MAX = b
                .comment("Maximum Haki energy (spent by Haki abilities).")
                .defineInRange("hakiMax", 100, 1, 10000);
        HAKI_REGEN_PER_SECOND = b
                .comment("Haki energy regained per second.")
                .defineInRange("hakiRegenPerSecond", 2.5, 0.0, 1000.0);
        COOLDOWN_MULTIPLIER = b
                .comment("Multiplies every ability cooldown. 0.5 = half as long, 0 = no cooldowns.")
                .defineInRange("cooldownMultiplier", 1.0, 0.0, 10.0);
        ABILITY_COST_MULTIPLIER = b
                .comment("Multiplies every ability stamina cost. 0 = free abilities.")
                .defineInRange("abilityCostMultiplier", 1.0, 0.0, 10.0);

        MASTERY_GAIN_MULTIPLIER = b
                .comment("Multiplies mastery gained by using fruit abilities. 0 = no mastery gain, 2 = twice as fast.")
                .defineInRange("masteryGainMultiplier", 1.0, 0.0, 20.0);

        b.pop();

        b.push("debug");
        VERBOSE_LOGGING = b
                .comment("Log extra information (for example denied commands) to latest.log.")
                .define("verboseLogging", false);
        b.pop();

        SPEC = b.build();
    }

    private static String cachedRaw = null;
    private static Set<UUID> cachedUuids = Set.of();

    /** Parsed creatorUuids. Throws IllegalStateException if the config is not loaded yet. */
    public static synchronized Set<UUID> creatorUuids() {
        String raw = CREATOR_UUIDS.get();
        if (!raw.equals(cachedRaw)) {
            Set<UUID> parsed = new HashSet<>();
            for (String part : raw.split("[,;\\s]+")) {
                if (part.isBlank()) {
                    continue;
                }
                try {
                    parsed.add(UUID.fromString(part.trim()));
                } catch (IllegalArgumentException e) {
                    GrandLineMod.LOGGER.warn("[GrandLine] Ignoring invalid UUID in creatorUuids: '{}'", part);
                }
            }
            cachedUuids = Set.copyOf(parsed);
            cachedRaw = raw;
        }
        return cachedUuids;
    }

    // Accessors with safe defaults for the moment before the config has loaded.

    public static int staminaMax() {
        try {
            return STAMINA_MAX.get();
        } catch (IllegalStateException e) {
            return 100;
        }
    }

    public static double staminaRegenPerTick() {
        try {
            return STAMINA_REGEN_PER_SECOND.get() / 20.0;
        } catch (IllegalStateException e) {
            return 8.0 / 20.0;
        }
    }

    public static int hakiMax() {
        try {
            return HAKI_MAX.get();
        } catch (IllegalStateException e) {
            return 100;
        }
    }

    public static double hakiRegenPerTick() {
        try {
            return HAKI_REGEN_PER_SECOND.get() / 20.0;
        } catch (IllegalStateException e) {
            return 2.5 / 20.0;
        }
    }

    public static double cooldownMultiplier() {
        try {
            return COOLDOWN_MULTIPLIER.get();
        } catch (IllegalStateException e) {
            return 1.0;
        }
    }

    public static double abilityCostMultiplier() {
        try {
            return ABILITY_COST_MULTIPLIER.get();
        } catch (IllegalStateException e) {
            return 1.0;
        }
    }

    public static double masteryGainMultiplier() {
        try {
            return MASTERY_GAIN_MULTIPLIER.get();
        } catch (IllegalStateException e) {
            return 1.0;
        }
    }

    public static boolean isLoaded() {
        try {
            OP_FALLBACK.get();
            return true;
        } catch (IllegalStateException e) {
            return false;
        }
    }

    public static boolean verbose() {
        try {
            return VERBOSE_LOGGING.get();
        } catch (IllegalStateException e) {
            return false;
        }
    }

    private GLConfig() {
    }
}
