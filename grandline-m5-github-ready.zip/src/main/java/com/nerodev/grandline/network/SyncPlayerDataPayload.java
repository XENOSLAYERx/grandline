package com.nerodev.grandline.network;

import com.nerodev.grandline.GrandLineMod;
import com.nerodev.grandline.data.PlayerData;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Server to owning client: the player's full data. Reuses PlayerData.CODEC so save and sync can never drift apart. */
public record SyncPlayerDataPayload(PlayerData data) implements CustomPacketPayload {

    public static final Type<SyncPlayerDataPayload> TYPE = new Type<>(GrandLineMod.id("sync_player_data"));

    public static final StreamCodec<ByteBuf, SyncPlayerDataPayload> STREAM_CODEC =
            ByteBufCodecs.fromCodec(PlayerData.CODEC)
                    .map(SyncPlayerDataPayload::new, SyncPlayerDataPayload::data);

    @Override
    public Type<SyncPlayerDataPayload> type() {
        return TYPE;
    }
}
