package com.nerodev.grandline.network;

import com.nerodev.grandline.GrandLineMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

import java.util.List;

/** Server to clients that can see an entity: the abilities it currently has on, for looping visuals. Sent on change only. */
public record ActiveVisualsPayload(int entityId, List<ResourceLocation> active) implements CustomPacketPayload {

    public static final Type<ActiveVisualsPayload> TYPE = new Type<>(GrandLineMod.id("active_visuals"));

    public static final StreamCodec<ByteBuf, ActiveVisualsPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, ActiveVisualsPayload::entityId,
            ResourceLocation.STREAM_CODEC.apply(ByteBufCodecs.list()), ActiveVisualsPayload::active,
            ActiveVisualsPayload::new);

    @Override
    public Type<ActiveVisualsPayload> type() {
        return TYPE;
    }
}
