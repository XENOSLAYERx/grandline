package com.nerodev.grandline.network;

import com.nerodev.grandline.ability.AbilityManager;
import com.nerodev.grandline.ability.AbilityPhase;
import com.nerodev.grandline.ability.AbilityViewCache;
import com.nerodev.grandline.ability.ClientActiveVisuals;
import com.nerodev.grandline.ability.GLAbilities;
import com.nerodev.grandline.data.GLAttachments;
import com.nerodev.grandline.haki.ObservationCache;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/**
 * Payload registration. Bump PROTOCOL when a payload's format changes.
 * The client never sends data values, only "key N pressed / released"; the server validates everything.
 * Handlers use only common classes, so they are safe on a dedicated server.
 */
public final class GLNetwork {

    public static final String PROTOCOL = "4";

    public static void onRegisterPayloads(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar(PROTOCOL);

        registrar.playToClient(
                SyncPlayerDataPayload.TYPE, SyncPlayerDataPayload.STREAM_CODEC, GLNetwork::handleSyncPlayerData);
        registrar.playToClient(
                SyncAbilityPayload.TYPE, SyncAbilityPayload.STREAM_CODEC, GLNetwork::handleSyncAbility);
        registrar.playToClient(
                AbilityEffectPayload.TYPE, AbilityEffectPayload.STREAM_CODEC, GLNetwork::handleAbilityEffect);
        registrar.playToClient(
                ActiveVisualsPayload.TYPE, ActiveVisualsPayload.STREAM_CODEC, GLNetwork::handleActiveVisuals);
        registrar.playToClient(
                PlayCutscenePayload.TYPE, PlayCutscenePayload.STREAM_CODEC, GLNetwork::handlePlayCutscene);

        registrar.playToClient(
                ObservationPulsePayload.TYPE, ObservationPulsePayload.STREAM_CODEC, GLNetwork::handleObservationPulse);

        registrar.playToServer(
                AbilityInputPayload.TYPE, AbilityInputPayload.STREAM_CODEC, GLNetwork::handleAbilityInput);
    }

    private static void handleSyncPlayerData(SyncPlayerDataPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> context.player().getData(GLAttachments.PLAYER_DATA).set(payload.data()));
    }

    private static void handleSyncAbility(SyncAbilityPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> AbilityViewCache.set(payload.view()));
    }

    private static void handleAbilityEffect(AbilityEffectPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            Level level = context.player().level();
            Entity entity = level.getEntity(payload.entityId());
            if (entity instanceof LivingEntity living) {
                AbilityPhase phase = AbilityPhase.fromOrdinal(payload.phase());
                GLAbilities.REGISTRY.getOptional(payload.ability())
                        .ifPresent(ability -> ability.clientEffects(level, living, phase, payload.intensity()));
            }
        });
    }

    private static void handleActiveVisuals(ActiveVisualsPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> ClientActiveVisuals.set(payload.entityId(), payload.active()));
    }

    private static void handlePlayCutscene(PlayCutscenePayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            if (payload.stop()) {
                ClientHooks.stopCutscene.run();
            } else {
                ClientHooks.playCutscene.accept(payload.id());
            }
        });
    }

    private static void handleObservationPulse(ObservationPulsePayload payload, IPayloadContext context) {
        context.enqueueWork(() -> ObservationCache.set(payload.entityIds()));
    }

    private static void handleAbilityInput(AbilityInputPayload payload, IPayloadContext context) {
        if (context.player() instanceof ServerPlayer player) {
            context.enqueueWork(() -> AbilityManager.handleInput(player, payload.slot(), payload.pressed()));
        }
    }

    private GLNetwork() {
    }
}
