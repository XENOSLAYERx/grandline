package com.nerodev.grandline.network;

import com.nerodev.grandline.GrandLineMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

import java.util.List;

/** Server to ONE client (the Observation user): the ids of nearby presences to mark. Twice a second while it is on. */
public record ObservationPulsePayload(List<Integer> entityIds) implements CustomPacketPayload {

    public static final Type<ObservationPulsePayload> TYPE = new Type<>(GrandLineMod.id("observation_pulse"));

    public static final StreamCodec<ByteBuf, ObservationPulsePayload> STREAM_CODEC =
            ByteBufCodecs.VAR_INT.apply(ByteBufCodecs.list())
                    .map(ObservationPulsePayload::new, ObservationPulsePayload::entityIds);

    @Override
    public Type<ObservationPulsePayload> type() {
        return TYPE;
    }
}
