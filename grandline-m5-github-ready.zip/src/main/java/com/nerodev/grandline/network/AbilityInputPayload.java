package com.nerodev.grandline.network;

import com.nerodev.grandline.GrandLineMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Client to server: "ability key N was pressed / released". Carries nothing else; the server decides what happens. */
public record AbilityInputPayload(int slot, boolean pressed) implements CustomPacketPayload {

    public static final Type<AbilityInputPayload> TYPE = new Type<>(GrandLineMod.id("ability_input"));

    public static final StreamCodec<ByteBuf, AbilityInputPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, AbilityInputPayload::slot,
            ByteBufCodecs.BOOL, AbilityInputPayload::pressed,
            AbilityInputPayload::new);

    @Override
    public Type<AbilityInputPayload> type() {
        return TYPE;
    }
}
