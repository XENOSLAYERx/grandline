package com.nerodev.grandline.network;

import net.minecraft.resources.ResourceLocation;

import java.util.function.Consumer;

/**
 * Lets common network handlers call client-only code without referencing client classes. The
 * client sets these during client setup; on a dedicated server they stay as harmless no-ops.
 */
public final class ClientHooks {

    public static volatile Consumer<ResourceLocation> playCutscene = id -> {
    };
    public static volatile Runnable stopCutscene = () -> {
    };

    private ClientHooks() {
    }
}
