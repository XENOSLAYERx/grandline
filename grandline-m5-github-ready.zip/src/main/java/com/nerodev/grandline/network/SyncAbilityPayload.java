package com.nerodev.grandline.network;

import com.nerodev.grandline.GrandLineMod;
import com.nerodev.grandline.ability.AbilityView;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Server to owning client: stamina and cooldown snapshot for the HUD. Sent when it changes, never per tick. */
public record SyncAbilityPayload(AbilityView view) implements CustomPacketPayload {

    public static final Type<SyncAbilityPayload> TYPE = new Type<>(GrandLineMod.id("sync_ability"));

    public static final StreamCodec<ByteBuf, SyncAbilityPayload> STREAM_CODEC =
            ByteBufCodecs.fromCodec(AbilityView.CODEC)
                    .map(SyncAbilityPayload::new, SyncAbilityPayload::view);

    @Override
    public Type<SyncAbilityPayload> type() {
        return TYPE;
    }
}
