package com.nerodev.grandline.network;

import com.nerodev.grandline.GrandLineMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Server to one client: start the cutscene with this id, or stop the current one. */
public record PlayCutscenePayload(ResourceLocation id, boolean stop) implements CustomPacketPayload {

    public static final Type<PlayCutscenePayload> TYPE = new Type<>(GrandLineMod.id("play_cutscene"));

    public static final StreamCodec<ByteBuf, PlayCutscenePayload> STREAM_CODEC = StreamCodec.composite(
            ResourceLocation.STREAM_CODEC, PlayCutscenePayload::id,
            ByteBufCodecs.BOOL, PlayCutscenePayload::stop,
            PlayCutscenePayload::new);

    @Override
    public Type<PlayCutscenePayload> type() {
        return TYPE;
    }
}
