package com.nerodev.grandline.network;

import com.nerodev.grandline.GrandLineMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * Server to clients that can see the caster: "play this ability's visuals for this phase on that
 * entity". Visuals only. phase is an AbilityPhase ordinal; intensity is e.g. the charge fraction.
 */
public record AbilityEffectPayload(int entityId, ResourceLocation ability, int phase, float intensity)
        implements CustomPacketPayload {

    public static final Type<AbilityEffectPayload> TYPE = new Type<>(GrandLineMod.id("ability_effect"));

    public static final StreamCodec<ByteBuf, AbilityEffectPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, AbilityEffectPayload::entityId,
            ResourceLocation.STREAM_CODEC, AbilityEffectPayload::ability,
            ByteBufCodecs.VAR_INT, AbilityEffectPayload::phase,
            ByteBufCodecs.FLOAT, AbilityEffectPayload::intensity,
            AbilityEffectPayload::new);

    @Override
    public Type<AbilityEffectPayload> type() {
        return TYPE;
    }
}
