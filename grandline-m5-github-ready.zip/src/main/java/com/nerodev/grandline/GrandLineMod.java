package com.nerodev.grandline;

import com.mojang.logging.LogUtils;
import com.nerodev.grandline.ability.AbilityEvents;
import com.nerodev.grandline.ability.GLAbilities;
import com.nerodev.grandline.command.GLCommands;
import com.nerodev.grandline.config.GLClientConfig;
import com.nerodev.grandline.config.GLConfig;
import com.nerodev.grandline.data.GLAttachments;
import com.nerodev.grandline.data.PlayerDataEvents;
import com.nerodev.grandline.fruit.FruitEvents;
import com.nerodev.grandline.fruit.GLFruits;
import com.nerodev.grandline.fruit.item.GLItems;
import com.nerodev.grandline.haki.HakiEvents;
import com.nerodev.grandline.network.GLNetwork;
import com.nerodev.grandline.registry.GLParticles;
import com.nerodev.grandline.registry.GLRegistries;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.NeoForge;
import org.slf4j.Logger;

@Mod(GrandLineMod.MODID)
public class GrandLineMod {
    public static final String MODID = "grandline";
    public static final Logger LOGGER = LogUtils.getLogger();

    public GrandLineMod(IEventBus modEventBus, ModContainer modContainer) {
        // config/grandline-common.toml
        modContainer.registerConfig(ModConfig.Type.COMMON, GLConfig.SPEC);
        // config/grandline-client.toml (vfxDensity, screenShake); only read on the client
        modContainer.registerConfig(ModConfig.Type.CLIENT, GLClientConfig.SPEC);

        // Mod bus. GLAbilities.register() loads the class that creates the ability registry,
        // which must happen before NewRegistryEvent fires (it does: that is after construction).
        modEventBus.addListener(GLRegistries::onNewRegistry);
        GLAbilities.register(modEventBus);
        GLFruits.register(modEventBus);
        GLItems.register(modEventBus);
        GLAttachments.register(modEventBus);
        GLParticles.register(modEventBus);
        modEventBus.addListener(GLNetwork::onRegisterPayloads);

        // Game bus
        NeoForge.EVENT_BUS.addListener(GLCommands::onRegisterCommands);
        NeoForge.EVENT_BUS.addListener(PlayerDataEvents::onLogin);
        NeoForge.EVENT_BUS.addListener(PlayerDataEvents::onRespawn);
        NeoForge.EVENT_BUS.addListener(PlayerDataEvents::onChangedDimension);
        NeoForge.EVENT_BUS.addListener(AbilityEvents::onServerTick);
        NeoForge.EVENT_BUS.addListener(AbilityEvents::onLoggedOut);
        NeoForge.EVENT_BUS.addListener(AbilityEvents::onDeath);
        NeoForge.EVENT_BUS.addListener(AbilityEvents::onStartTracking);
        NeoForge.EVENT_BUS.addListener(FruitEvents::onLogin);
        NeoForge.EVENT_BUS.addListener(FruitEvents::onRespawn);
        NeoForge.EVENT_BUS.addListener(FruitEvents::onIncomingDamage);
        NeoForge.EVENT_BUS.addListener(HakiEvents::onIncomingDamage);

        LOGGER.info("[GrandLine] Core framework, player data, ability framework, presentation and Devil Fruits and Haki loaded (Milestone 5)");
    }

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MODID, path);
    }
}
