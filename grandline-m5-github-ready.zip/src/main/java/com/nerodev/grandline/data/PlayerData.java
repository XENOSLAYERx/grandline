package com.nerodev.grandline.data;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.UUIDUtil;
import net.minecraft.resources.ResourceLocation;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * Everything the mod stores per player (the build and progression). Immutable: change it with
 * GLPlayerData.update(...), which saves and syncs in one step.
 *
 * Every field is optional when loading and falls back to a default, so adding a field in a later
 * milestone never breaks an existing save. Bump CURRENT_VERSION if a field ever changes meaning.
 * Runtime state (stamina, cooldowns) lives in AbilityState, not here.
 */
public record PlayerData(
        int version,
        ResourceLocation race,
        Optional<ResourceLocation> faction,
        long bounty,
        Unlocks unlocks,
        Optional<ResourceLocation> equippedFruit,
        Optional<ResourceLocation> equippedStyle,
        Map<ResourceLocation, Integer> mastery,
        HakiLevels haki,
        Map<String, Loadout> loadouts,
        Map<ResourceLocation, Integer> quests,
        Optional<UUID> crew,
        AbilitySlots abilitySlots,
        boolean fruitAwakened) {

    public static final int CURRENT_VERSION = 1;
    public static final long MAX_BOUNTY = 100_000_000_000L;
    public static final int MAX_MASTERY = 100;

    public static final PlayerData DEFAULT = new PlayerData(
            CURRENT_VERSION,
            GLCodecs.DEFAULT_RACE,
            Optional.empty(),
            0L,
            Unlocks.EMPTY,
            Optional.empty(),
            Optional.empty(),
            Map.of(),
            HakiLevels.NONE,
            Map.of(),
            Map.of(),
            Optional.empty(),
            AbilitySlots.EMPTY,
            false);

    public static final Codec<PlayerData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.INT.optionalFieldOf("version", CURRENT_VERSION).forGetter(PlayerData::version),
            ResourceLocation.CODEC.optionalFieldOf("race", GLCodecs.DEFAULT_RACE).forGetter(PlayerData::race),
            ResourceLocation.CODEC.optionalFieldOf("faction").forGetter(PlayerData::faction),
            Codec.LONG.optionalFieldOf("bounty", 0L).forGetter(PlayerData::bounty),
            Unlocks.CODEC.optionalFieldOf("unlocks", Unlocks.EMPTY).forGetter(PlayerData::unlocks),
            ResourceLocation.CODEC.optionalFieldOf("equipped_fruit").forGetter(PlayerData::equippedFruit),
            ResourceLocation.CODEC.optionalFieldOf("equipped_style").forGetter(PlayerData::equippedStyle),
            Codec.unboundedMap(ResourceLocation.CODEC, Codec.INT).optionalFieldOf("mastery", Map.of()).forGetter(PlayerData::mastery),
            HakiLevels.CODEC.optionalFieldOf("haki", HakiLevels.NONE).forGetter(PlayerData::haki),
            Codec.unboundedMap(Codec.STRING, Loadout.CODEC).optionalFieldOf("loadouts", Map.of()).forGetter(PlayerData::loadouts),
            Codec.unboundedMap(ResourceLocation.CODEC, Codec.INT).optionalFieldOf("quests", Map.of()).forGetter(PlayerData::quests),
            UUIDUtil.CODEC.optionalFieldOf("crew").forGetter(PlayerData::crew),
            AbilitySlots.CODEC.optionalFieldOf("ability_slots", AbilitySlots.EMPTY).forGetter(PlayerData::abilitySlots),
            Codec.BOOL.optionalFieldOf("fruit_awakened", false).forGetter(PlayerData::fruitAwakened)
    ).apply(instance, PlayerData::new));

    /** Lenient on purpose: bad values are clamped or copied, never rejected. */
    public PlayerData {
        bounty = Math.max(0L, Math.min(MAX_BOUNTY, bounty));
        mastery = clampedCopy(mastery);
        loadouts = Map.copyOf(loadouts);
        quests = Map.copyOf(quests);
    }

    public PlayerData withBounty(long newBounty) {
        return new PlayerData(version, race, faction, newBounty, unlocks, equippedFruit, equippedStyle,
                mastery, haki, loadouts, quests, crew, abilitySlots, fruitAwakened);
    }

    public PlayerData withHaki(HakiLevels newHaki) {
        return new PlayerData(version, race, faction, bounty, unlocks, equippedFruit, equippedStyle,
                mastery, newHaki, loadouts, quests, crew, abilitySlots, fruitAwakened);
    }

    public PlayerData withMastery(Map<ResourceLocation, Integer> newMastery) {
        return new PlayerData(version, race, faction, bounty, unlocks, equippedFruit, equippedStyle,
                newMastery, haki, loadouts, quests, crew, abilitySlots, fruitAwakened);
    }

    public PlayerData withUnlocks(Unlocks newUnlocks) {
        return new PlayerData(version, race, faction, bounty, newUnlocks, equippedFruit, equippedStyle,
                mastery, haki, loadouts, quests, crew, abilitySlots, fruitAwakened);
    }

    public PlayerData withAbilitySlots(AbilitySlots newSlots) {
        return new PlayerData(version, race, faction, bounty, unlocks, equippedFruit, equippedStyle,
                mastery, haki, loadouts, quests, crew, newSlots, fruitAwakened);
    }

    public PlayerData withEquippedFruit(Optional<ResourceLocation> fruit) {
        return new PlayerData(version, race, faction, bounty, unlocks, fruit, equippedStyle,
                mastery, haki, loadouts, quests, crew, abilitySlots, fruitAwakened);
    }

    public PlayerData withFruitAwakened(boolean awakened) {
        return new PlayerData(version, race, faction, bounty, unlocks, equippedFruit, equippedStyle,
                mastery, haki, loadouts, quests, crew, abilitySlots, awakened);
    }

    private static Map<ResourceLocation, Integer> clampedCopy(Map<ResourceLocation, Integer> input) {
        Map<ResourceLocation, Integer> out = new HashMap<>();
        input.forEach((id, value) -> out.put(id, Math.max(0, Math.min(MAX_MASTERY, value))));
        return Map.copyOf(out);
    }
}
