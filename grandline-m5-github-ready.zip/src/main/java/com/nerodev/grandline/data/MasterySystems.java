package com.nerodev.grandline.data;

import com.nerodev.grandline.GrandLineMod;
import net.minecraft.resources.ResourceLocation;

import java.util.List;
import java.util.Optional;

/** Systems that have a 0-100 mastery value. Haki has its own levels in PlayerData. */
public final class MasterySystems {

    private static final List<String> NAMES = List.of("fruit", "style", "rokushiki");

    public static List<String> names() {
        return NAMES;
    }

    public static List<ResourceLocation> all() {
        return NAMES.stream().map(GrandLineMod::id).toList();
    }

    public static Optional<ResourceLocation> resolve(String name) {
        return NAMES.contains(name) ? Optional.of(GrandLineMod.id(name)) : Optional.empty();
    }

    private MasterySystems() {
    }
}
