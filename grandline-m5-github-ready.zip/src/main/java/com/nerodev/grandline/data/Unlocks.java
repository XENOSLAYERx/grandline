package com.nerodev.grandline.data;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.resources.ResourceLocation;

import java.util.HashSet;
import java.util.Set;

/** Everything a player has unlocked, as registry ids. */
public record Unlocks(
        Set<ResourceLocation> fruits,
        Set<ResourceLocation> abilities,
        Set<ResourceLocation> styles,
        Set<ResourceLocation> weapons,
        Set<ResourceLocation> titles) {

    public static final Unlocks EMPTY = new Unlocks(Set.of(), Set.of(), Set.of(), Set.of(), Set.of());

    public static final Codec<Unlocks> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            GLCodecs.ID_SET.optionalFieldOf("fruits", Set.of()).forGetter(Unlocks::fruits),
            GLCodecs.ID_SET.optionalFieldOf("abilities", Set.of()).forGetter(Unlocks::abilities),
            GLCodecs.ID_SET.optionalFieldOf("styles", Set.of()).forGetter(Unlocks::styles),
            GLCodecs.ID_SET.optionalFieldOf("weapons", Set.of()).forGetter(Unlocks::weapons),
            GLCodecs.ID_SET.optionalFieldOf("titles", Set.of()).forGetter(Unlocks::titles)
    ).apply(instance, Unlocks::new));

    public Unlocks {
        fruits = Set.copyOf(fruits);
        abilities = Set.copyOf(abilities);
        styles = Set.copyOf(styles);
        weapons = Set.copyOf(weapons);
        titles = Set.copyOf(titles);
    }

    public Unlocks withFruit(ResourceLocation id) {
        Set<ResourceLocation> updated = new HashSet<>(fruits);
        updated.add(id);
        return new Unlocks(updated, abilities, styles, weapons, titles);
    }

    public Unlocks withAbility(ResourceLocation id) {
        Set<ResourceLocation> updated = new HashSet<>(abilities);
        updated.add(id);
        return new Unlocks(fruits, updated, styles, weapons, titles);
    }
}
