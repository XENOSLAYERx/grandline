package com.nerodev.grandline.data;

import net.minecraft.resources.ResourceLocation;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

/** Readable, deterministic text for PlayerData. Used by the server and client debug commands. */
public final class PlayerDataFormat {

    public static List<String> describe(PlayerData data) {
        List<String> lines = new ArrayList<>();
        lines.add("version: " + data.version());
        lines.add("race: " + data.race());
        lines.add("faction: " + opt(data.faction()));
        lines.add("bounty: " + String.format(Locale.ROOT, "%,d", data.bounty()) + " berries");
        lines.add("haki: observation " + data.haki().observation()
                + ", armament " + data.haki().armament()
                + ", conqueror's " + data.haki().conquerors());
        lines.add("equipped fruit: " + opt(data.equippedFruit()));
        lines.add("fruit awakened: " + data.fruitAwakened());
        lines.add("equipped style: " + opt(data.equippedStyle()));
        lines.add("ability slots: " + slots(data.abilitySlots()));
        lines.add("unlocked fruits: " + ids(data.unlocks().fruits()));
        lines.add("unlocked abilities: " + ids(data.unlocks().abilities()));
        lines.add("unlocked styles: " + ids(data.unlocks().styles()));
        lines.add("unlocked weapons: " + ids(data.unlocks().weapons()));
        lines.add("unlocked titles: " + ids(data.unlocks().titles()));
        lines.add("mastery: " + intMap(data.mastery()));
        lines.add("quests: " + intMap(data.quests()));
        lines.add("loadouts: " + loadouts(data.loadouts()));
        lines.add("crew: " + opt(data.crew()));
        return lines;
    }

    /** Same data on server and client gives the same checksum. */
    public static String checksum(PlayerData data) {
        return String.format(Locale.ROOT, "%08x", String.join("\n", describe(data)).hashCode());
    }

    private static String opt(Optional<?> value) {
        return value.map(Object::toString).orElse("none");
    }

    private static String slots(AbilitySlots slots) {
        List<String> parts = new ArrayList<>();
        for (int i = 0; i < AbilitySlots.COUNT; i++) {
            parts.add((i + 1) + "=" + opt(slots.get(i)));
        }
        return String.join(", ", parts);
    }

    private static String ids(Set<ResourceLocation> set) {
        if (set.isEmpty()) {
            return "none";
        }
        return set.stream().map(ResourceLocation::toString).sorted().collect(Collectors.joining(", "));
    }

    private static String intMap(Map<ResourceLocation, Integer> map) {
        if (map.isEmpty()) {
            return "none";
        }
        Map<String, Integer> sorted = new TreeMap<>();
        map.forEach((id, value) -> sorted.put(id.toString(), value));
        return sorted.entrySet().stream()
                .map(entry -> entry.getKey() + "=" + entry.getValue())
                .collect(Collectors.joining(", "));
    }

    private static String loadouts(Map<String, Loadout> map) {
        if (map.isEmpty()) {
            return "none";
        }
        Map<String, Loadout> sorted = new TreeMap<>(map);
        return sorted.entrySet().stream()
                .map(entry -> {
                    Loadout l = entry.getValue();
                    return entry.getKey() + "[fruit=" + opt(l.fruit()) + ", style=" + opt(l.style())
                            + ", weapon=" + opt(l.weapon()) + ", race=" + l.race()
                            + ", haki=" + l.haki().observation() + "/" + l.haki().armament() + "/" + l.haki().conquerors() + "]";
                })
                .collect(Collectors.joining("; "));
    }

    private PlayerDataFormat() {
    }
}
