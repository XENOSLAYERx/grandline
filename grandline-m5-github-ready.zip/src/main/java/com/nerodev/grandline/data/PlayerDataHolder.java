package com.nerodev.grandline.data;

import com.mojang.serialization.DataResult;
import com.nerodev.grandline.GrandLineMod;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtOps;
import net.neoforged.neoforge.common.util.INBTSerializable;

import java.util.Optional;

/**
 * The object stored in the attachment. It wraps the immutable PlayerData and saves it as NBT using
 * PlayerData.CODEC (this INBTSerializable route avoids the Codec/MapCodec difference between
 * NeoForge versions).
 *
 * If a save cannot be read, the raw tag is kept and written back unchanged, so a bug can never
 * silently wipe a player's data. It is dropped only when the data is changed on purpose.
 */
public final class PlayerDataHolder implements INBTSerializable<CompoundTag> {

    private PlayerData data = PlayerData.DEFAULT;
    private CompoundTag unreadable = null;

    public PlayerData get() {
        return data;
    }

    public void set(PlayerData newData) {
        this.data = newData;
        this.unreadable = null;
    }

    @Override
    public CompoundTag serializeNBT(HolderLookup.Provider provider) {
        if (unreadable != null) {
            return unreadable.copy();
        }
        return PlayerData.CODEC.encodeStart(NbtOps.INSTANCE, data)
                .resultOrPartial(message -> GrandLineMod.LOGGER.error("[GrandLine] Could not save player data: {}", message))
                .map(tag -> tag instanceof CompoundTag compound ? compound : new CompoundTag())
                .orElseGet(CompoundTag::new);
    }

    @Override
    public void deserializeNBT(HolderLookup.Provider provider, CompoundTag tag) {
        DataResult<PlayerData> result = PlayerData.CODEC.parse(NbtOps.INSTANCE, tag);
        Optional<PlayerData> parsed = result.result();
        if (parsed.isPresent()) {
            this.data = parsed.get();
            this.unreadable = null;
        } else {
            this.data = PlayerData.DEFAULT;
            this.unreadable = tag.copy();
            // Logs the reason. The return value is not needed.
            result.resultOrPartial(message -> GrandLineMod.LOGGER.error(
                    "[GrandLine] Player data could not be read, keeping the raw save untouched: {}", message));
        }
    }
}
