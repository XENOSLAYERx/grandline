package com.nerodev.grandline.data;

import com.mojang.serialization.Codec;
import com.nerodev.grandline.GrandLineMod;
import net.minecraft.resources.ResourceLocation;

import java.util.Set;

/** Shared codecs and defaults. Depends on no data record, so it can never create a class-init cycle. */
public final class GLCodecs {

    public static final ResourceLocation DEFAULT_RACE = GrandLineMod.id("human");

    /** A set of ids, stored as a sorted list so saves are stable. */
    public static final Codec<Set<ResourceLocation>> ID_SET = ResourceLocation.CODEC.listOf()
            .<Set<ResourceLocation>>xmap(
                    list -> Set.copyOf(list),
                    set -> set.stream().sorted().toList());

    private GLCodecs() {
    }
}
