package com.nerodev.grandline.data;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

public record HakiLevels(int observation, int armament, int conquerors) {

    public static final int MAX_LEVEL = 100;
    public static final HakiLevels NONE = new HakiLevels(0, 0, 0);

    public static final Codec<HakiLevels> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.INT.optionalFieldOf("observation", 0).forGetter(HakiLevels::observation),
            Codec.INT.optionalFieldOf("armament", 0).forGetter(HakiLevels::armament),
            Codec.INT.optionalFieldOf("conquerors", 0).forGetter(HakiLevels::conquerors)
    ).apply(instance, HakiLevels::new));

    /** Lenient on purpose: out-of-range values are clamped instead of rejecting the whole save. */
    public HakiLevels {
        observation = clamp(observation);
        armament = clamp(armament);
        conquerors = clamp(conquerors);
    }

    public int get(HakiBranch branch) {
        return switch (branch) {
            case OBSERVATION -> observation;
            case ARMAMENT -> armament;
            case CONQUERORS -> conquerors;
        };
    }

    public HakiLevels with(HakiBranch branch, int level) {
        return switch (branch) {
            case OBSERVATION -> new HakiLevels(level, armament, conquerors);
            case ARMAMENT -> new HakiLevels(observation, level, conquerors);
            case CONQUERORS -> new HakiLevels(observation, armament, level);
        };
    }

    private static int clamp(int value) {
        return Math.max(0, Math.min(MAX_LEVEL, value));
    }
}
