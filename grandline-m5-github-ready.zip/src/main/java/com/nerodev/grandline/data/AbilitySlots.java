package com.nerodev.grandline.data;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.resources.ResourceLocation;

import java.util.Optional;

/** Which ability each key slot runs. Slot index 0 is the first key (default Z). */
public record AbilitySlots(
        Optional<ResourceLocation> slot1,
        Optional<ResourceLocation> slot2,
        Optional<ResourceLocation> slot3,
        Optional<ResourceLocation> slot4,
        Optional<ResourceLocation> slot5) {

    public static final int COUNT = 5;

    public static final AbilitySlots EMPTY = new AbilitySlots(
            Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty());

    public static final Codec<AbilitySlots> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            ResourceLocation.CODEC.optionalFieldOf("1").forGetter(AbilitySlots::slot1),
            ResourceLocation.CODEC.optionalFieldOf("2").forGetter(AbilitySlots::slot2),
            ResourceLocation.CODEC.optionalFieldOf("3").forGetter(AbilitySlots::slot3),
            ResourceLocation.CODEC.optionalFieldOf("4").forGetter(AbilitySlots::slot4),
            ResourceLocation.CODEC.optionalFieldOf("5").forGetter(AbilitySlots::slot5)
    ).apply(instance, AbilitySlots::new));

    public Optional<ResourceLocation> get(int index) {
        return switch (index) {
            case 0 -> slot1;
            case 1 -> slot2;
            case 2 -> slot3;
            case 3 -> slot4;
            case 4 -> slot5;
            default -> Optional.empty();
        };
    }

    private AbilitySlots set(int index, Optional<ResourceLocation> id) {
        return switch (index) {
            case 0 -> new AbilitySlots(id, slot2, slot3, slot4, slot5);
            case 1 -> new AbilitySlots(slot1, id, slot3, slot4, slot5);
            case 2 -> new AbilitySlots(slot1, slot2, id, slot4, slot5);
            case 3 -> new AbilitySlots(slot1, slot2, slot3, id, slot5);
            case 4 -> new AbilitySlots(slot1, slot2, slot3, slot4, id);
            default -> this;
        };
    }

    /** Puts the ability in a slot. If it was in another slot it moves, so one ability never sits in two slots. */
    public AbilitySlots equip(int index, ResourceLocation id) {
        AbilitySlots result = this;
        for (int i = 0; i < COUNT; i++) {
            if (i != index && result.get(i).filter(id::equals).isPresent()) {
                result = result.set(i, Optional.empty());
            }
        }
        return result.set(index, Optional.of(id));
    }

    public AbilitySlots unequip(int index) {
        return set(index, Optional.empty());
    }
}
