package com.nerodev.grandline.data;

public enum HakiBranch {
    OBSERVATION("observation"),
    ARMAMENT("armament"),
    CONQUERORS("conquerors");

    private final String id;

    HakiBranch(String id) {
        this.id = id;
    }

    public String id() {
        return id;
    }
}
