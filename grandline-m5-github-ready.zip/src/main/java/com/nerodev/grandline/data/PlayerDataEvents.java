package com.nerodev.grandline.data;

import com.nerodev.grandline.ability.GLAbilityData;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;

/**
 * The client's player object is new after login, respawn and a dimension change, so it has no
 * data until the server sends it again. Data itself is copied on death by copyOnDeath().
 *
 * No per-player state is kept in static fields, so there is nothing to clean up on logout.
 */
public final class PlayerDataEvents {

    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            syncAll(player);
        }
    }

    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            syncAll(player);
        }
    }

    public static void onChangedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            syncAll(player);
        }
    }

    private static void syncAll(ServerPlayer player) {
        GLPlayerData.sync(player);
        GLAbilityData.sync(player);
    }

    private PlayerDataEvents() {
    }
}
