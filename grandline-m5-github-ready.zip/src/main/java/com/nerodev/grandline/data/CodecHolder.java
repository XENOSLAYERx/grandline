package com.nerodev.grandline.data;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.nerodev.grandline.GrandLineMod;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtOps;
import net.neoforged.neoforge.common.util.INBTSerializable;

import java.util.Optional;

/**
 * Attachment holder for any immutable value that has a record Codec. Same safety rule as
 * PlayerDataHolder: a save that cannot be read is kept and written back unchanged.
 * Reuse this for every new attachment.
 */
public final class CodecHolder<T> implements INBTSerializable<CompoundTag> {

    private final String label;
    private final Codec<T> codec;
    private final T defaultValue;
    private T value;
    private CompoundTag unreadable = null;

    public CodecHolder(String label, Codec<T> codec, T defaultValue) {
        this.label = label;
        this.codec = codec;
        this.defaultValue = defaultValue;
        this.value = defaultValue;
    }

    public T get() {
        return value;
    }

    public void set(T newValue) {
        this.value = newValue;
        this.unreadable = null;
    }

    @Override
    public CompoundTag serializeNBT(HolderLookup.Provider provider) {
        if (unreadable != null) {
            return unreadable.copy();
        }
        return codec.encodeStart(NbtOps.INSTANCE, value)
                .resultOrPartial(message -> GrandLineMod.LOGGER.error("[GrandLine] Could not save {}: {}", label, message))
                .map(tag -> tag instanceof CompoundTag compound ? compound : new CompoundTag())
                .orElseGet(CompoundTag::new);
    }

    @Override
    public void deserializeNBT(HolderLookup.Provider provider, CompoundTag tag) {
        DataResult<T> result = codec.parse(NbtOps.INSTANCE, tag);
        Optional<T> parsed = result.result();
        if (parsed.isPresent()) {
            this.value = parsed.get();
            this.unreadable = null;
        } else {
            this.value = defaultValue;
            this.unreadable = tag.copy();
            result.resultOrPartial(message -> GrandLineMod.LOGGER.error(
                    "[GrandLine] {} could not be read, keeping the raw save untouched: {}", label, message));
        }
    }
}
