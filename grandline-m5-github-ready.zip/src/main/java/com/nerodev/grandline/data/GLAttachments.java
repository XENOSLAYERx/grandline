package com.nerodev.grandline.data;

import com.nerodev.grandline.GrandLineMod;
import com.nerodev.grandline.ability.AbilityState;
import com.nerodev.grandline.ability.ActiveAbilities;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

import java.util.function.Supplier;

public final class GLAttachments {

    private static final DeferredRegister<AttachmentType<?>> ATTACHMENT_TYPES =
            DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, GrandLineMod.MODID);

    /** Build and progression. Saved with the player, copied on death and on returning from the End. */
    public static final Supplier<AttachmentType<PlayerDataHolder>> PLAYER_DATA = ATTACHMENT_TYPES.register(
            "player_data",
            () -> AttachmentType.serializable(() -> new PlayerDataHolder()).copyOnDeath().build());

    /** Stamina and cooldowns. Saved with the player, copied on death. */
    public static final Supplier<AttachmentType<CodecHolder<AbilityState>>> ABILITY_STATE = ATTACHMENT_TYPES.register(
            "ability_state",
            () -> AttachmentType.serializable(
                    () -> new CodecHolder<AbilityState>("ability state", AbilityState.CODEC, AbilityState.DEFAULT))
                    .copyOnDeath().build());

    /** Toggles and holds that are on right now. NOT saved and NOT copied on death, on purpose. */
    public static final Supplier<AttachmentType<ActiveAbilities>> ACTIVE_ABILITIES = ATTACHMENT_TYPES.register(
            "active_abilities",
            () -> AttachmentType.builder(() -> new ActiveAbilities()).build());

    public static void register(IEventBus modEventBus) {
        ATTACHMENT_TYPES.register(modEventBus);
    }

    private GLAttachments() {
    }
}
