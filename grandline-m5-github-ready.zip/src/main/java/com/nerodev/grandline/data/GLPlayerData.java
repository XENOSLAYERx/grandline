package com.nerodev.grandline.data;

import com.nerodev.grandline.network.SyncPlayerDataPayload;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.function.UnaryOperator;

/**
 * The only way the rest of the mod should read or change player data.
 *
 * Server code changes data ONLY through update(...): it saves, and it syncs to the owning client
 * once, and only if something actually changed. Nothing here runs per tick.
 */
public final class GLPlayerData {

    /** Works on both sides. On the client this is the last copy the server sent. */
    public static PlayerData get(Player player) {
        return player.getData(GLAttachments.PLAYER_DATA).get();
    }

    /** Server only. Returns true if the data changed. */
    public static boolean update(ServerPlayer player, UnaryOperator<PlayerData> change) {
        PlayerDataHolder holder = player.getData(GLAttachments.PLAYER_DATA);
        PlayerData before = holder.get();
        PlayerData after = change.apply(before);
        if (after.equals(before)) {
            return false;
        }
        holder.set(after);
        sync(player);
        return true;
    }

    /** Sends the full data to the owner. Used on login, respawn and dimension change. */
    public static void sync(ServerPlayer player) {
        if (player.connection == null) {
            return; // fake players have no connection
        }
        PacketDistributor.sendToPlayer(player, new SyncPlayerDataPayload(get(player)));
    }

    private GLPlayerData() {
    }
}
