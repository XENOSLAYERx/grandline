package com.nerodev.grandline.data;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.resources.ResourceLocation;

import java.util.Optional;

/** A saved build. Save/load commands arrive with the Creator tools (Milestone 9). */
public record Loadout(
        Optional<ResourceLocation> fruit,
        Optional<ResourceLocation> style,
        Optional<ResourceLocation> weapon,
        ResourceLocation race,
        HakiLevels haki) {

    public static final Codec<Loadout> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            ResourceLocation.CODEC.optionalFieldOf("fruit").forGetter(Loadout::fruit),
            ResourceLocation.CODEC.optionalFieldOf("style").forGetter(Loadout::style),
            ResourceLocation.CODEC.optionalFieldOf("weapon").forGetter(Loadout::weapon),
            ResourceLocation.CODEC.optionalFieldOf("race", GLCodecs.DEFAULT_RACE).forGetter(Loadout::race),
            HakiLevels.CODEC.optionalFieldOf("haki", HakiLevels.NONE).forGetter(Loadout::haki)
    ).apply(instance, Loadout::new));
}
