package com.nerodev.grandline.permission;

import com.nerodev.grandline.GrandLineMod;
import com.nerodev.grandline.config.GLConfig;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;

import java.util.Set;
import java.util.UUID;
import java.util.function.Predicate;

/**
 * Single place that decides a command source's tier. Everything is checked on the server.
 *
 * Order (highest match wins):
 *   1. UUID listed in creatorUuids            -> CREATOR
 *   2. owner of a singleplayer world (config) -> CREATOR
 *   3. vanilla op level mapped by config      -> CREATOR / ADMIN / MODERATOR
 *   4. otherwise                              -> PLAYER
 */
public final class GLPermissions {

    public record Resolution(PermissionTier tier, String reason) {
    }

    public static Resolution resolve(CommandSourceStack source) {
        // Defaults are used only if the config has not finished loading.
        boolean opFallback = true;
        boolean singleplayerOwner = true;
        int moderatorLevel = 2;
        int adminLevel = 3;
        int creatorLevel = 4;
        Set<UUID> creators = Set.of();
        try {
            opFallback = GLConfig.OP_FALLBACK.get();
            singleplayerOwner = GLConfig.SINGLEPLAYER_OWNER_IS_CREATOR.get();
            moderatorLevel = GLConfig.MODERATOR_OP_LEVEL.get();
            adminLevel = GLConfig.ADMIN_OP_LEVEL.get();
            creatorLevel = GLConfig.CREATOR_OP_LEVEL.get();
            creators = GLConfig.creatorUuids();
        } catch (IllegalStateException ignored) {
            // config not loaded yet, defaults above apply
        }

        Entity entity = source.getEntity();
        if (entity instanceof ServerPlayer player) {
            if (creators.contains(player.getUUID())) {
                return new Resolution(PermissionTier.CREATOR, "your UUID is listed in creatorUuids");
            }
            if (singleplayerOwner && source.getServer().isSingleplayerOwner(player.getGameProfile())) {
                return new Resolution(PermissionTier.CREATOR, "you own this singleplayer world");
            }
        }

        if (opFallback) {
            if (source.hasPermission(creatorLevel)) {
                return new Resolution(PermissionTier.CREATOR, "vanilla op level " + creatorLevel + "+");
            }
            if (source.hasPermission(adminLevel)) {
                return new Resolution(PermissionTier.ADMIN, "vanilla op level " + adminLevel + "+");
            }
            if (source.hasPermission(moderatorLevel)) {
                return new Resolution(PermissionTier.MODERATOR, "vanilla op level " + moderatorLevel + "+");
            }
        }

        return new Resolution(PermissionTier.PLAYER, "not in creatorUuids, not a world owner, no matching op level");
    }

    /** For Brigadier .requires(...). Hides the command from tab-complete and blocks it. */
    public static Predicate<CommandSourceStack> requires(PermissionTier tier) {
        return source -> resolve(source).tier().atLeast(tier);
    }

    /** Second check inside executes(...). Sends the failure message itself. */
    public static boolean guard(CommandSourceStack source, PermissionTier needed) {
        Resolution r = resolve(source);
        if (r.tier().atLeast(needed)) {
            return true;
        }
        source.sendFailure(Component.literal("You need the " + needed + " tier for that (you are " + r.tier() + ")."));
        if (GLConfig.verbose()) {
            GrandLineMod.LOGGER.info("[GrandLine] Denied command for {}: needed {}, has {}",
                    source.getTextName(), needed, r.tier());
        }
        return false;
    }

    private GLPermissions() {
    }
}
