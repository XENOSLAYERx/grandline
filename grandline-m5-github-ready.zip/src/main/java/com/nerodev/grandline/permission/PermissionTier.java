package com.nerodev.grandline.permission;

public enum PermissionTier {
    PLAYER,
    MODERATOR,
    ADMIN,
    CREATOR;

    public boolean atLeast(PermissionTier other) {
        return this.ordinal() >= other.ordinal();
    }
}
