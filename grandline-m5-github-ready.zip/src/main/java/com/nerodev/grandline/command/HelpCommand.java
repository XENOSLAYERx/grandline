package com.nerodev.grandline.command;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.nerodev.grandline.permission.GLPermissions;
import com.nerodev.grandline.permission.PermissionTier;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;

import java.util.List;
import java.util.Optional;

public final class HelpCommand {

    private static final SuggestionProvider<CommandSourceStack> SUGGEST_COMMANDS = (context, builder) -> {
        PermissionTier tier = GLPermissions.resolve(context.getSource()).tier();
        return SharedSuggestionProvider.suggest(
                CommandHelp.visibleTo(tier).stream().map(CommandHelp.Entry::name), builder);
    };

    public static void registerHelp() {
        CommandHelp.register(new CommandHelp.Entry(
                "help", "help [command]",
                "Lists the commands you can use, or explains one.",
                PermissionTier.PLAYER));
    }

    public static LiteralArgumentBuilder<CommandSourceStack> build() {
        return Commands.literal("help")
                .executes(context -> list(context.getSource()))
                .then(Commands.argument("command", StringArgumentType.word())
                        .suggests(SUGGEST_COMMANDS)
                        .executes(context -> detail(context.getSource(),
                                StringArgumentType.getString(context, "command"))));
    }

    public static int list(CommandSourceStack source) {
        GLPermissions.Resolution me = GLPermissions.resolve(source);
        List<CommandHelp.Entry> visible = CommandHelp.visibleTo(me.tier());

        source.sendSuccess(() -> Component.literal("=== One Piece: Grand Line ===")
                .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), false);
        for (CommandHelp.Entry entry : visible) {
            source.sendSuccess(() -> Component.literal("/onepiece " + entry.usage())
                    .withStyle(ChatFormatting.YELLOW)
                    .append(Component.literal(" - " + entry.description()).withStyle(ChatFormatting.GRAY)), false);
        }
        source.sendSuccess(() -> Component.literal("Your tier: " + me.tier() + " (" + me.reason() + ")")
                .withStyle(ChatFormatting.AQUA), false);
        return visible.size();
    }

    private static int detail(CommandSourceStack source, String name) {
        PermissionTier tier = GLPermissions.resolve(source).tier();
        Optional<CommandHelp.Entry> found = CommandHelp.get(name).filter(entry -> tier.atLeast(entry.tier()));
        if (found.isEmpty()) {
            source.sendFailure(Component.literal(
                    "No command named '" + name + "' that you can use. Try /onepiece help."));
            return 0;
        }
        CommandHelp.Entry entry = found.get();
        source.sendSuccess(() -> Component.literal("/onepiece " + entry.usage()).withStyle(ChatFormatting.YELLOW), false);
        source.sendSuccess(() -> Component.literal(entry.description()).withStyle(ChatFormatting.GRAY), false);
        source.sendSuccess(() -> Component.literal("Needs tier: " + entry.tier()).withStyle(ChatFormatting.AQUA), false);
        return 1;
    }

    private HelpCommand() {
    }
}
