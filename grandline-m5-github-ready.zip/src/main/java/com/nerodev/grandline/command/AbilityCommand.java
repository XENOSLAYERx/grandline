package com.nerodev.grandline.command;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.nerodev.grandline.ability.AbilityView;
import com.nerodev.grandline.ability.GLAbilities;
import com.nerodev.grandline.ability.GLAbilityData;
import com.nerodev.grandline.ability.AbilityManager;
import com.nerodev.grandline.data.AbilitySlots;
import com.nerodev.grandline.data.GLPlayerData;
import com.nerodev.grandline.data.PlayerData;
import com.nerodev.grandline.permission.GLPermissions;
import com.nerodev.grandline.permission.PermissionTier;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.ResourceLocationArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;

import java.util.List;
import java.util.Map;

public final class AbilityCommand {

    private static final PermissionTier GIVE_TIER = PermissionTier.CREATOR;

    private static final SuggestionProvider<CommandSourceStack> SUGGEST_ABILITIES =
            (context, builder) -> SharedSuggestionProvider.suggestResource(GLAbilities.REGISTRY.keySet(), builder);

    public static void registerHelp() {
        CommandHelp.register(new CommandHelp.Entry(
                "ability", "ability <list | status | equip <slot 1-" + AbilitySlots.COUNT + "> <ability> | unequip <slot> | give <ability>>",
                "Put unlocked abilities on your keys and check stamina and cooldowns. give is Creator only.",
                PermissionTier.PLAYER));
    }

    public static LiteralArgumentBuilder<CommandSourceStack> build() {
        return Commands.literal("ability")
                .then(Commands.literal("list").executes(context -> list(context.getSource())))
                .then(Commands.literal("status").executes(context -> status(context.getSource())))
                .then(Commands.literal("equip")
                        .then(Commands.argument("slot", IntegerArgumentType.integer(1, AbilitySlots.COUNT))
                                .then(Commands.argument("ability", ResourceLocationArgument.id())
                                        .suggests(SUGGEST_ABILITIES)
                                        .executes(context -> equip(context.getSource(),
                                                IntegerArgumentType.getInteger(context, "slot"),
                                                ResourceLocationArgument.getId(context, "ability"))))))
                .then(Commands.literal("unequip")
                        .then(Commands.argument("slot", IntegerArgumentType.integer(1, AbilitySlots.COUNT))
                                .executes(context -> unequip(context.getSource(),
                                        IntegerArgumentType.getInteger(context, "slot")))))
                .then(Commands.literal("give")
                        .requires(GLPermissions.requires(GIVE_TIER))
                        .then(Commands.argument("ability", ResourceLocationArgument.id())
                                .suggests(SUGGEST_ABILITIES)
                                .executes(context -> give(context.getSource(),
                                        ResourceLocationArgument.getId(context, "ability")))));
    }

    private static int list(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        PlayerData data = GLPlayerData.get(player);
        List<ResourceLocation> ids = GLAbilities.REGISTRY.keySet().stream().sorted().toList();
        if (ids.isEmpty()) {
            line(source, "No abilities are registered.");
            return 0;
        }
        for (ResourceLocation id : ids) {
            boolean unlocked = data.unlocks().abilities().contains(id);
            int slot = slotOf(data.abilitySlots(), id);
            line(source, id + " (" + (unlocked ? "unlocked" : "locked") + (slot >= 0 ? ", slot " + (slot + 1) : "") + ")");
        }
        return ids.size();
    }

    private static int status(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        AbilityView view = GLAbilityData.view(player);
        long now = player.level().getGameTime();
        PlayerData data = GLPlayerData.get(player);

        line(source, "Stamina: " + (view.infinite()
                ? "infinite"
                : (int) view.staminaAt(now) + "/" + (int) view.max()));
        line(source, "Haki: " + (view.infiniteHaki()
                ? "infinite"
                : (int) view.hakiAt(now) + "/" + (int) view.hakiMax()));
        boolean anyCooldown = false;
        for (Map.Entry<ResourceLocation, Long> entry : view.cooldowns().entrySet()) {
            long remaining = view.cooldownRemaining(entry.getKey(), now);
            if (remaining > 0) {
                line(source, "Cooldown " + entry.getKey() + ": " + AbilityManager.seconds(remaining) + " s");
                anyCooldown = true;
            }
        }
        if (!anyCooldown) {
            line(source, "No ability is on cooldown.");
        }
        for (int i = 0; i < AbilitySlots.COUNT; i++) {
            line(source, "Slot " + (i + 1) + ": " + data.abilitySlots().get(i).map(ResourceLocation::toString).orElse("empty"));
        }
        return 1;
    }

    private static int equip(CommandSourceStack source, int slotNumber, ResourceLocation id) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        if (!GLAbilities.REGISTRY.containsKey(id)) {
            source.sendFailure(Component.literal("Unknown ability " + id + "."));
            return 0;
        }
        if (!GLPlayerData.get(player).unlocks().abilities().contains(id)) {
            source.sendFailure(Component.literal("You have not unlocked " + id + "."));
            return 0;
        }
        int index = slotNumber - 1;
        GLPlayerData.update(player, data -> data.withAbilitySlots(data.abilitySlots().equip(index, id)));
        line(source, id + " is now on slot " + slotNumber + ".");
        return 1;
    }

    private static int unequip(CommandSourceStack source, int slotNumber) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        int index = slotNumber - 1;
        GLPlayerData.update(player, data -> data.withAbilitySlots(data.abilitySlots().unequip(index)));
        line(source, "Slot " + slotNumber + " is now empty.");
        return 1;
    }

    private static int give(CommandSourceStack source, ResourceLocation id) throws CommandSyntaxException {
        if (!GLPermissions.guard(source, GIVE_TIER)) {
            return 0;
        }
        if (!GLAbilities.REGISTRY.containsKey(id)) {
            source.sendFailure(Component.literal("Unknown ability " + id + "."));
            return 0;
        }
        ServerPlayer player = source.getPlayerOrException();
        GLPlayerData.update(player, data -> data.withUnlocks(data.unlocks().withAbility(id)));
        line(source, "Unlocked " + id + ". Equip it with /onepiece ability equip <slot> " + id);
        return 1;
    }

    private static int slotOf(AbilitySlots slots, ResourceLocation id) {
        for (int i = 0; i < AbilitySlots.COUNT; i++) {
            if (slots.get(i).filter(id::equals).isPresent()) {
                return i;
            }
        }
        return -1;
    }

    private static void line(CommandSourceStack source, String text) {
        source.sendSuccess(() -> Component.literal(text), false);
    }

    private AbilityCommand() {
    }
}
