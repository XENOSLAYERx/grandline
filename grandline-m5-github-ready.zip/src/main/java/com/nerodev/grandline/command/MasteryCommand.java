package com.nerodev.grandline.command;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.nerodev.grandline.data.GLPlayerData;
import com.nerodev.grandline.data.MasterySystems;
import com.nerodev.grandline.data.PlayerData;
import com.nerodev.grandline.permission.GLPermissions;
import com.nerodev.grandline.permission.PermissionTier;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public final class MasteryCommand {

    private static final PermissionTier REQUIRED = PermissionTier.CREATOR;

    private static final SuggestionProvider<CommandSourceStack> SUGGEST_SYSTEMS =
            (context, builder) -> SharedSuggestionProvider.suggest(MasterySystems.names(), builder);

    public static void registerHelp() {
        CommandHelp.register(new CommandHelp.Entry(
                "mastery", "mastery <max | set <system> <level 0-" + PlayerData.MAX_MASTERY + ">>",
                "Sets your mastery for one system (" + String.join(", ", MasterySystems.names()) + ") or all of them.",
                REQUIRED));
    }

    public static LiteralArgumentBuilder<CommandSourceStack> build() {
        return Commands.literal("mastery")
                .requires(GLPermissions.requires(REQUIRED))
                .then(Commands.literal("max").executes(context -> max(context.getSource())))
                .then(Commands.literal("set")
                        .then(Commands.argument("system", StringArgumentType.word())
                                .suggests(SUGGEST_SYSTEMS)
                                .then(Commands.argument("level", IntegerArgumentType.integer(0, PlayerData.MAX_MASTERY))
                                        .executes(context -> set(context.getSource(),
                                                StringArgumentType.getString(context, "system"),
                                                IntegerArgumentType.getInteger(context, "level"))))));
    }

    private static int set(CommandSourceStack source, String systemName, int level) throws CommandSyntaxException {
        if (!GLPermissions.guard(source, REQUIRED)) {
            return 0;
        }
        Optional<ResourceLocation> system = MasterySystems.resolve(systemName);
        if (system.isEmpty()) {
            source.sendFailure(Component.literal("Unknown mastery system '" + systemName
                    + "'. Choose one of: " + String.join(", ", MasterySystems.names())));
            return 0;
        }
        ServerPlayer player = source.getPlayerOrException();
        GLPlayerData.update(player, data -> {
            Map<ResourceLocation, Integer> mastery = new HashMap<>(data.mastery());
            mastery.put(system.get(), level);
            return data.withMastery(mastery);
        });
        int now = GLPlayerData.get(player).mastery().getOrDefault(system.get(), 0);
        source.sendSuccess(() -> Component.literal("Mastery (" + systemName + ") is now " + now + "."), false);
        return 1;
    }

    private static int max(CommandSourceStack source) throws CommandSyntaxException {
        if (!GLPermissions.guard(source, REQUIRED)) {
            return 0;
        }
        ServerPlayer player = source.getPlayerOrException();
        GLPlayerData.update(player, data -> {
            Map<ResourceLocation, Integer> mastery = new HashMap<>(data.mastery());
            for (ResourceLocation system : MasterySystems.all()) {
                mastery.put(system, PlayerData.MAX_MASTERY);
            }
            return data.withMastery(mastery);
        });
        source.sendSuccess(() -> Component.literal("All mastery systems set to " + PlayerData.MAX_MASTERY + "."), false);
        return 1;
    }

    private MasteryCommand() {
    }
}
