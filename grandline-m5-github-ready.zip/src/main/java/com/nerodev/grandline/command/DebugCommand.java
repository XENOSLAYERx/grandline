package com.nerodev.grandline.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.nerodev.grandline.GrandLineMod;
import com.nerodev.grandline.config.GLConfig;
import com.nerodev.grandline.data.AbilitySlots;
import com.nerodev.grandline.data.GLPlayerData;
import com.nerodev.grandline.data.HakiLevels;
import com.nerodev.grandline.data.Loadout;
import com.nerodev.grandline.data.PlayerData;
import com.nerodev.grandline.data.PlayerDataFormat;
import com.nerodev.grandline.data.Unlocks;
import com.nerodev.grandline.permission.GLPermissions;
import com.nerodev.grandline.permission.PermissionTier;
import com.nerodev.grandline.registry.GLRegistries;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.core.Registry;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.fml.ModList;

import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

public final class DebugCommand {

    private static final PermissionTier REQUIRED = PermissionTier.MODERATOR;
    private static final PermissionTier EDIT = PermissionTier.CREATOR;

    public static void registerHelp() {
        CommandHelp.register(new CommandHelp.Entry(
                "debug", "debug [permissions|config|registries|data]",
                "Diagnostics: versions, your tier, config values, registries, player data.",
                REQUIRED));
    }

    public static LiteralArgumentBuilder<CommandSourceStack> build() {
        return Commands.literal("debug")
                .requires(GLPermissions.requires(REQUIRED))
                .executes(context -> summary(context.getSource()))
                .then(Commands.literal("permissions").executes(context -> permissions(context.getSource())))
                .then(Commands.literal("config").executes(context -> config(context.getSource())))
                .then(Commands.literal("registries").executes(context -> registries(context.getSource())))
                .then(Commands.literal("data")
                        .executes(context -> showData(context.getSource(), context.getSource().getPlayerOrException()))
                        .then(Commands.literal("fill")
                                .requires(GLPermissions.requires(EDIT))
                                .executes(context -> fill(context.getSource())))
                        .then(Commands.literal("reset")
                                .requires(GLPermissions.requires(EDIT))
                                .then(Commands.literal("confirm")
                                        .executes(context -> reset(context.getSource()))))
                        .then(Commands.argument("player", EntityArgument.player())
                                .executes(context -> showData(context.getSource(),
                                        EntityArgument.getPlayer(context, "player")))));
    }

    private static int summary(CommandSourceStack source) {
        if (!GLPermissions.guard(source, REQUIRED)) {
            return 0;
        }
        GLPermissions.Resolution me = GLPermissions.resolve(source);
        line(source, "[GrandLine debug] mod " + versionOf(GrandLineMod.MODID)
                + " | Minecraft " + versionOf("minecraft")
                + " | NeoForge " + versionOf("neoforge"));
        line(source, "Side: " + (source.getServer().isDedicatedServer()
                ? "dedicated server" : "integrated server (singleplayer / LAN)"));
        line(source, "You: tier " + me.tier() + " - " + me.reason());
        line(source, "Config: " + (GLConfig.isLoaded() ? "loaded" : "NOT loaded yet (defaults in use)"));
        line(source, "Custom registries: " + GLRegistries.all().size() + " | help entries: " + CommandHelp.count());
        line(source, "More: /onepiece debug permissions | config | registries | data");
        return 1;
    }

    private static int permissions(CommandSourceStack source) {
        if (!GLPermissions.guard(source, REQUIRED)) {
            return 0;
        }
        GLPermissions.Resolution me = GLPermissions.resolve(source);
        int opLevel = 0;
        for (int level = 4; level >= 1; level--) {
            if (source.hasPermission(level)) {
                opLevel = level;
                break;
            }
        }
        line(source, "Resolved tier: " + me.tier() + " (" + me.reason() + ")");
        line(source, "Vanilla permission level: " + opLevel);
        if (source.getEntity() instanceof ServerPlayer player) {
            line(source, "Player: " + player.getGameProfile().getName() + " | UUID: " + player.getUUID());
        } else {
            line(source, "Source is not a player (console, command block or function).");
        }
        return 1;
    }

    private static int config(CommandSourceStack source) {
        if (!GLPermissions.guard(source, REQUIRED)) {
            return 0;
        }
        if (!GLConfig.isLoaded()) {
            line(source, "Config is not loaded yet.");
            return 0;
        }
        line(source, "permissions.creatorUuids: " + GLConfig.creatorUuids().size() + " valid UUID(s)");
        line(source, "permissions.singleplayerOwnerIsCreator: " + GLConfig.SINGLEPLAYER_OWNER_IS_CREATOR.get());
        line(source, "permissions.opFallback: " + GLConfig.OP_FALLBACK.get());
        line(source, "permissions op levels: moderator " + GLConfig.MODERATOR_OP_LEVEL.get()
                + ", admin " + GLConfig.ADMIN_OP_LEVEL.get()
                + ", creator " + GLConfig.CREATOR_OP_LEVEL.get());
        line(source, "abilities: staminaMax " + GLConfig.STAMINA_MAX.get()
                + ", staminaRegenPerSecond " + GLConfig.STAMINA_REGEN_PER_SECOND.get()
                + ", cooldownMultiplier " + GLConfig.COOLDOWN_MULTIPLIER.get()
                + ", abilityCostMultiplier " + GLConfig.ABILITY_COST_MULTIPLIER.get());
        line(source, "abilities: hakiMax " + GLConfig.HAKI_MAX.get() + ", hakiRegenPerSecond " + GLConfig.HAKI_REGEN_PER_SECOND.get());
        line(source, "abilities.masteryGainMultiplier: " + GLConfig.MASTERY_GAIN_MULTIPLIER.get());
        line(source, "debug.verboseLogging: " + GLConfig.VERBOSE_LOGGING.get());
        return 1;
    }

    private static int registries(CommandSourceStack source) {
        if (!GLPermissions.guard(source, REQUIRED)) {
            return 0;
        }
        if (GLRegistries.all().isEmpty()) {
            line(source, "No Grand Line registries yet. Expected so far; content registries arrive with M3+.");
            return 1;
        }
        for (Registry<?> registry : GLRegistries.all()) {
            line(source, registry.key().location() + ": " + registry.size() + " entries");
        }
        return GLRegistries.all().size();
    }

    // ---- player data (Milestone 2) ----

    private static int showData(CommandSourceStack source, ServerPlayer target) {
        if (!GLPermissions.guard(source, REQUIRED)) {
            return 0;
        }
        PlayerData data = GLPlayerData.get(target);
        line(source, "[GrandLine data] " + target.getGameProfile().getName() + " (server copy)");
        for (String text : PlayerDataFormat.describe(data)) {
            line(source, text);
        }
        line(source, "checksum: " + PlayerDataFormat.checksum(data));
        return 1;
    }

    /** Writes a value into every field so persistence and sync of each type can be tested. */
    private static int fill(CommandSourceStack source) throws CommandSyntaxException {
        if (!GLPermissions.guard(source, EDIT)) {
            return 0;
        }
        ServerPlayer player = source.getPlayerOrException();
        GLPlayerData.update(player, data -> sampleData());
        line(source, "Filled every data field with test values. Compare with /glclient data, then die, relog and restart.");
        return 1;
    }

    private static int reset(CommandSourceStack source) throws CommandSyntaxException {
        if (!GLPermissions.guard(source, EDIT)) {
            return 0;
        }
        ServerPlayer player = source.getPlayerOrException();
        GLPlayerData.update(player, data -> PlayerData.DEFAULT);
        line(source, "Player data reset to defaults.");
        return 1;
    }

    private static PlayerData sampleData() {
        HakiLevels haki = new HakiLevels(10, 20, 30);
        return new PlayerData(
                PlayerData.CURRENT_VERSION,
                id("human"),
                Optional.of(id("test_faction")),
                123_456_789L,
                new Unlocks(
                        Set.of(id("test_fruit")),
                        Set.of(id("test_ability")),
                        Set.of(id("test_style")),
                        Set.of(id("test_weapon")),
                        Set.of(id("test_title"))),
                Optional.of(id("test_fruit")),
                Optional.of(id("test_style")),
                Map.of(id("fruit"), 42, id("style"), 17, id("rokushiki"), 5),
                haki,
                Map.of("test", new Loadout(
                        Optional.of(id("test_fruit")),
                        Optional.of(id("test_style")),
                        Optional.of(id("test_weapon")),
                        id("human"),
                        haki)),
                Map.of(id("test_quest"), 3),
                Optional.of(UUID.nameUUIDFromBytes("grandline-test-crew".getBytes(StandardCharsets.UTF_8))),
                AbilitySlots.EMPTY.equip(0, id("test_pulse")),
                true);
    }

    private static ResourceLocation id(String path) {
        return GrandLineMod.id(path);
    }

    private static String versionOf(String modId) {
        return ModList.get().getModContainerById(modId)
                .map(container -> container.getModInfo().getVersion().toString())
                .orElse("unknown");
    }

    private static void line(CommandSourceStack source, String text) {
        source.sendSuccess(() -> Component.literal(text), false);
    }

    private DebugCommand() {
    }
}
