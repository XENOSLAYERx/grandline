package com.nerodev.grandline.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.nerodev.grandline.GrandLineMod;
import com.nerodev.grandline.ability.Ability;
import com.nerodev.grandline.ability.AbilityManager;
import com.nerodev.grandline.ability.ActivationType;
import com.nerodev.grandline.ability.GLAbilities;
import com.nerodev.grandline.data.GLPlayerData;
import com.nerodev.grandline.data.Unlocks;
import com.nerodev.grandline.fruit.DevilFruit;
import com.nerodev.grandline.fruit.FruitManager;
import com.nerodev.grandline.fruit.GLFruits;
import com.nerodev.grandline.permission.GLPermissions;
import com.nerodev.grandline.permission.PermissionTier;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.ResourceLocationArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;

import java.util.List;
import java.util.Optional;

/** Creator tools for fruits: fruit give|remove|awaken|list, transform <form>, unlock fruits. They write player data and never hand out items. */
public final class FruitCommand {

    private static final PermissionTier REQUIRED = PermissionTier.CREATOR;

    private static final SuggestionProvider<CommandSourceStack> SUGGEST_FRUITS =
            (context, builder) -> SharedSuggestionProvider.suggestResource(GLFruits.REGISTRY.keySet(), builder);

    private static final SuggestionProvider<CommandSourceStack> SUGGEST_FORMS = (context, builder) -> {
        List<ResourceLocation> toggles = GLAbilities.REGISTRY.keySet().stream()
                .filter(id -> GLAbilities.REGISTRY.getOptional(id)
                        .map(ability -> ability.activation() == ActivationType.TOGGLE).orElse(false))
                .sorted().toList();
        return SharedSuggestionProvider.suggestResource(toggles, builder);
    };

    public static void registerHelp() {
        CommandHelp.register(new CommandHelp.Entry(
                "fruit", "fruit <give <fruit> | remove | awaken | list>",
                "Gives you a Devil Fruit's power directly (no item), removes it, awakens it, or lists the fruits.",
                REQUIRED));
        CommandHelp.register(new CommandHelp.Entry(
                "transform", "transform <form>",
                "Turns a body form (a toggle ability such as grandline:leopard_hybrid) on or off with no cost.",
                REQUIRED));
        CommandHelp.register(new CommandHelp.Entry(
                "unlock", "unlock fruits",
                "Unlocks every fruit in your data without equipping one. (Other unlock categories arrive with their systems.)",
                REQUIRED));
    }

    public static LiteralArgumentBuilder<CommandSourceStack> buildFruit() {
        return Commands.literal("fruit")
                .requires(GLPermissions.requires(REQUIRED))
                .then(Commands.literal("give")
                        .then(Commands.argument("fruit", ResourceLocationArgument.id())
                                .suggests(SUGGEST_FRUITS)
                                .executes(context -> give(context.getSource(),
                                        ResourceLocationArgument.getId(context, "fruit")))))
                .then(Commands.literal("remove").executes(context -> remove(context.getSource())))
                .then(Commands.literal("awaken").executes(context -> awaken(context.getSource())))
                .then(Commands.literal("list").executes(context -> list(context.getSource())));
    }

    public static LiteralArgumentBuilder<CommandSourceStack> buildTransform() {
        return Commands.literal("transform")
                .requires(GLPermissions.requires(REQUIRED))
                .then(Commands.argument("form", ResourceLocationArgument.id())
                        .suggests(SUGGEST_FORMS)
                        .executes(context -> transform(context.getSource(),
                                ResourceLocationArgument.getId(context, "form"))));
    }

    public static LiteralArgumentBuilder<CommandSourceStack> buildUnlock() {
        return Commands.literal("unlock")
                .requires(GLPermissions.requires(REQUIRED))
                .then(Commands.literal("fruits").executes(context -> unlockFruits(context.getSource())));
    }

    /** Accepts "leopard" as well as "grandline:leopard". */
    private static ResourceLocation normalize(ResourceLocation id, java.util.function.Predicate<ResourceLocation> exists) {
        if (exists.test(id)) {
            return id;
        }
        ResourceLocation ours = GrandLineMod.id(id.getPath());
        return exists.test(ours) ? ours : id;
    }

    private static int give(CommandSourceStack source, ResourceLocation requested) throws CommandSyntaxException {
        if (!GLPermissions.guard(source, REQUIRED)) {
            return 0;
        }
        ResourceLocation id = normalize(requested, GLFruits.REGISTRY::containsKey);
        ServerPlayer player = source.getPlayerOrException();
        if (!FruitManager.equip(player, id, true)) {
            source.sendFailure(Component.literal("Unknown fruit " + requested + ". Try /onepiece fruit list."));
            return 0;
        }
        Optional<DevilFruit> fruit = GLFruits.REGISTRY.getOptional(id);
        source.sendSuccess(() -> Component.empty().append(fruit.get().displayName())
                .append(Component.literal(" gained. Its abilities are on keys 1-" + fruit.get().abilities().size() + ".")), false);
        return 1;
    }

    private static int remove(CommandSourceStack source) throws CommandSyntaxException {
        if (!GLPermissions.guard(source, REQUIRED)) {
            return 0;
        }
        ServerPlayer player = source.getPlayerOrException();
        if (FruitManager.current(player).isEmpty()) {
            source.sendFailure(Component.literal("You have no Devil Fruit."));
            return 0;
        }
        FruitManager.remove(player);
        source.sendSuccess(() -> Component.literal("Devil Fruit removed."), false);
        return 1;
    }

    private static int awaken(CommandSourceStack source) throws CommandSyntaxException {
        if (!GLPermissions.guard(source, REQUIRED)) {
            return 0;
        }
        return FruitManager.awaken(source.getPlayerOrException(), true) ? 1 : 0;
    }

    private static int list(CommandSourceStack source) {
        for (ResourceLocation id : GLFruits.REGISTRY.keySet().stream().sorted().toList()) {
            DevilFruit fruit = GLFruits.REGISTRY.get(id);
            if (fruit != null) {
                source.sendSuccess(() -> Component.literal(id + " - " + fruit.type().label()
                        + ", " + fruit.abilities().size() + " abilities"), false);
            }
        }
        return GLFruits.REGISTRY.size();
    }

    private static int transform(CommandSourceStack source, ResourceLocation requested) throws CommandSyntaxException {
        if (!GLPermissions.guard(source, REQUIRED)) {
            return 0;
        }
        ResourceLocation id = normalize(requested, GLAbilities.REGISTRY::containsKey);
        ServerPlayer player = source.getPlayerOrException();
        Optional<Ability> ability = GLAbilities.REGISTRY.getOptional(id);
        if (ability.isEmpty() || ability.get().activation() != ActivationType.TOGGLE) {
            source.sendFailure(Component.literal(requested + " is not a toggle form."));
            return 0;
        }
        if (!AbilityManager.forceToggle(player, id)) {
            source.sendFailure(Component.literal("Could not switch " + id + " (another body form may be on)."));
            return 0;
        }
        boolean on = AbilityManager.isActive(player, id);
        source.sendSuccess(() -> Component.literal(id + " is now " + (on ? "ON" : "OFF") + "."), false);
        return 1;
    }

    private static int unlockFruits(CommandSourceStack source) throws CommandSyntaxException {
        if (!GLPermissions.guard(source, REQUIRED)) {
            return 0;
        }
        ServerPlayer player = source.getPlayerOrException();
        GLPlayerData.update(player, data -> {
            Unlocks unlocks = data.unlocks();
            for (ResourceLocation id : GLFruits.REGISTRY.keySet()) {
                unlocks = unlocks.withFruit(id);
            }
            return data.withUnlocks(unlocks);
        });
        source.sendSuccess(() -> Component.literal("All fruits unlocked."), false);
        return 1;
    }

    private FruitCommand() {
    }
}
