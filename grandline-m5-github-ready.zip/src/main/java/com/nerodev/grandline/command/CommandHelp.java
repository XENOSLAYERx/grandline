package com.nerodev.grandline.command;

import com.nerodev.grandline.permission.PermissionTier;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;

/**
 * Help entries for /onepiece. Every command module registers its own entry, so /onepiece help
 * only ever lists commands that really exist and that the caller may use.
 */
public final class CommandHelp {

    public record Entry(String name, String usage, String description, PermissionTier tier) {
    }

    private static final Map<String, Entry> ENTRIES = new TreeMap<>();

    public static void clear() {
        ENTRIES.clear();
    }

    public static void register(Entry entry) {
        ENTRIES.put(entry.name(), entry);
    }

    public static int count() {
        return ENTRIES.size();
    }

    public static Optional<Entry> get(String name) {
        return Optional.ofNullable(ENTRIES.get(name));
    }

    public static List<Entry> visibleTo(PermissionTier tier) {
        List<Entry> out = new ArrayList<>();
        for (Entry entry : ENTRIES.values()) {
            if (tier.atLeast(entry.tier())) {
                out.add(entry);
            }
        }
        return out;
    }

    private CommandHelp() {
    }
}
