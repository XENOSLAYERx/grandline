package com.nerodev.grandline.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.nerodev.grandline.network.PlayCutscenePayload;
import com.nerodev.grandline.permission.GLPermissions;
import com.nerodev.grandline.permission.PermissionTier;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.ResourceLocationArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Starts or stops a cutscene on your own client. Cutscene files live in assets/grandline/cutscenes/
 * on the client, so the server cannot tab-complete their names; the client reports unknown ids.
 * (/glclient cutscene play <id> does the same without a server and does tab-complete.)
 */
public final class CutsceneCommand {

    private static final PermissionTier REQUIRED = PermissionTier.CREATOR;

    public static void registerHelp() {
        CommandHelp.register(new CommandHelp.Entry(
                "cutscene", "cutscene <play <id> | stop>",
                "Plays or stops a cutscene on your screen. Try: cutscene play grandline:test_intro",
                REQUIRED));
    }

    public static LiteralArgumentBuilder<CommandSourceStack> build() {
        return Commands.literal("cutscene")
                .requires(GLPermissions.requires(REQUIRED))
                .then(Commands.literal("play")
                        .then(Commands.argument("id", ResourceLocationArgument.id())
                                .executes(context -> play(context.getSource(),
                                        ResourceLocationArgument.getId(context, "id")))))
                .then(Commands.literal("stop")
                        .executes(context -> stop(context.getSource())));
    }

    private static int play(CommandSourceStack source, ResourceLocation id) throws CommandSyntaxException {
        if (!GLPermissions.guard(source, REQUIRED)) {
            return 0;
        }
        ServerPlayer player = source.getPlayerOrException();
        PacketDistributor.sendToPlayer(player, new PlayCutscenePayload(id, false));
        source.sendSuccess(() -> Component.literal("Playing cutscene " + id + "."), false);
        return 1;
    }

    private static int stop(CommandSourceStack source) throws CommandSyntaxException {
        if (!GLPermissions.guard(source, REQUIRED)) {
            return 0;
        }
        ServerPlayer player = source.getPlayerOrException();
        PacketDistributor.sendToPlayer(player, new PlayCutscenePayload(ResourceLocation.withDefaultNamespace("none"), true));
        return 1;
    }

    private CutsceneCommand() {
    }
}
