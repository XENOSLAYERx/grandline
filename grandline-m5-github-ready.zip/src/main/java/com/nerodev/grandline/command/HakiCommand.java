package com.nerodev.grandline.command;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.nerodev.grandline.ability.GLAbilityData;
import com.nerodev.grandline.ability.ResourceType;
import com.nerodev.grandline.data.GLPlayerData;
import com.nerodev.grandline.data.HakiBranch;
import com.nerodev.grandline.data.HakiLevels;
import com.nerodev.grandline.permission.GLPermissions;
import com.nerodev.grandline.permission.PermissionTier;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

public final class HakiCommand {

    private static final PermissionTier REQUIRED = PermissionTier.CREATOR;

    public static void registerHelp() {
        CommandHelp.register(new CommandHelp.Entry(
                "haki", "haki <set <observation|armament|conquerors> <level 0-" + HakiLevels.MAX_LEVEL + "> | unlock all | infinite>",
                "Sets a Haki level (a level of 1+ unlocks that Haki), maxes all three, or toggles infinite Haki energy.",
                REQUIRED));
    }

    public static LiteralArgumentBuilder<CommandSourceStack> build() {
        LiteralArgumentBuilder<CommandSourceStack> set = Commands.literal("set");
        for (HakiBranch branch : HakiBranch.values()) {
            set.then(Commands.literal(branch.id())
                    .then(Commands.argument("level", IntegerArgumentType.integer(0, HakiLevels.MAX_LEVEL))
                            .executes(context -> setLevel(context.getSource(), branch,
                                    IntegerArgumentType.getInteger(context, "level")))));
        }
        return Commands.literal("haki")
                .requires(GLPermissions.requires(REQUIRED))
                .then(set)
                .then(Commands.literal("unlock").then(Commands.literal("all")
                        .executes(context -> unlockAll(context.getSource()))))
                .then(Commands.literal("infinite").executes(context -> toggleInfinite(context.getSource())));
    }

    private static int setLevel(CommandSourceStack source, HakiBranch branch, int level) throws CommandSyntaxException {
        if (!GLPermissions.guard(source, REQUIRED)) {
            return 0;
        }
        ServerPlayer player = source.getPlayerOrException();
        GLPlayerData.update(player, data -> data.withHaki(data.haki().with(branch, level)));
        int now = GLPlayerData.get(player).haki().get(branch);
        source.sendSuccess(() -> Component.literal("Haki (" + branch.id() + ") is now level " + now + "."), false);
        return 1;
    }

    private static int unlockAll(CommandSourceStack source) throws CommandSyntaxException {
        if (!GLPermissions.guard(source, REQUIRED)) {
            return 0;
        }
        ServerPlayer player = source.getPlayerOrException();
        int max = HakiLevels.MAX_LEVEL;
        GLPlayerData.update(player, data -> data.withHaki(new HakiLevels(max, max, max)));
        source.sendSuccess(() -> Component.literal("All Haki unlocked at level " + max
                + ". Keys: N Observation, B Armament, J Advanced Armament, M Conqueror's."), false);
        return 1;
    }

    private static int toggleInfinite(CommandSourceStack source) throws CommandSyntaxException {
        if (!GLPermissions.guard(source, REQUIRED)) {
            return 0;
        }
        ServerPlayer player = source.getPlayerOrException();
        boolean enable = !GLAbilityData.get(player).infiniteHaki();
        GLAbilityData.update(player, state -> state.withInfinite(ResourceType.HAKI, enable));
        source.sendSuccess(() -> Component.literal("Infinite Haki energy is now " + (enable ? "ON" : "OFF") + "."), false);
        return 1;
    }

    private HakiCommand() {
    }
}
