package com.nerodev.grandline.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.nerodev.grandline.GrandLineMod;
import com.nerodev.grandline.ability.AbilityState;
import com.nerodev.grandline.ability.GLAbilityData;
import com.nerodev.grandline.data.AbilitySlots;
import com.nerodev.grandline.data.GLPlayerData;
import com.nerodev.grandline.data.Unlocks;
import com.nerodev.grandline.permission.GLPermissions;
import com.nerodev.grandline.permission.PermissionTier;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Creator testing tools from the command list: test, cooldown reset, stamina infinite. */
public final class TestingCommands {

    private static final PermissionTier REQUIRED = PermissionTier.CREATOR;

    public static void registerHelp() {
        CommandHelp.register(new CommandHelp.Entry(
                "test", "test",
                "Gives you the ability test kit: unlocks the 4 test abilities, puts them on slots 1-4, sets Rokushiki mastery to at least 10, refills stamina.",
                REQUIRED));
        CommandHelp.register(new CommandHelp.Entry(
                "cooldown", "cooldown reset",
                "Clears all of your ability cooldowns.",
                REQUIRED));
        CommandHelp.register(new CommandHelp.Entry(
                "stamina", "stamina infinite",
                "Toggles infinite stamina for you.",
                REQUIRED));
    }

    public static LiteralArgumentBuilder<CommandSourceStack> buildTest() {
        return Commands.literal("test")
                .requires(GLPermissions.requires(REQUIRED))
                .executes(context -> kit(context.getSource()));
    }

    public static LiteralArgumentBuilder<CommandSourceStack> buildCooldown() {
        return Commands.literal("cooldown")
                .requires(GLPermissions.requires(REQUIRED))
                .then(Commands.literal("reset").executes(context -> resetCooldowns(context.getSource())));
    }

    public static LiteralArgumentBuilder<CommandSourceStack> buildStamina() {
        return Commands.literal("stamina")
                .requires(GLPermissions.requires(REQUIRED))
                .then(Commands.literal("infinite").executes(context -> toggleInfinite(context.getSource())));
    }

    private static int kit(CommandSourceStack source) throws CommandSyntaxException {
        if (!GLPermissions.guard(source, REQUIRED)) {
            return 0;
        }
        ServerPlayer player = source.getPlayerOrException();
        ResourceLocation rokushiki = GrandLineMod.id("rokushiki");
        List<ResourceLocation> kit = List.of(
                GrandLineMod.id("test_pulse"),
                GrandLineMod.id("test_aura"),
                GrandLineMod.id("test_guard"),
                GrandLineMod.id("test_dash"));

        GLPlayerData.update(player, data -> {
            Map<ResourceLocation, Integer> mastery = new HashMap<>(data.mastery());
            mastery.merge(rokushiki, 10, Integer::max);
            Unlocks unlocks = data.unlocks();
            AbilitySlots slots = data.abilitySlots();
            for (int i = 0; i < kit.size(); i++) {
                unlocks = unlocks.withAbility(kit.get(i));
                slots = slots.equip(i, kit.get(i));
            }
            return data.withUnlocks(unlocks).withMastery(mastery).withAbilitySlots(slots);
        });
        GLAbilityData.update(player, state -> state.clearCooldowns().withFullStamina());

        line(source, "Test kit ready. Z = Shockwave (press), X = Aura (toggle), C = Guard (hold), V = Dash (hold to charge, release).");
        return 1;
    }

    private static int resetCooldowns(CommandSourceStack source) throws CommandSyntaxException {
        if (!GLPermissions.guard(source, REQUIRED)) {
            return 0;
        }
        GLAbilityData.update(source.getPlayerOrException(), AbilityState::clearCooldowns);
        line(source, "All ability cooldowns cleared.");
        return 1;
    }

    private static int toggleInfinite(CommandSourceStack source) throws CommandSyntaxException {
        if (!GLPermissions.guard(source, REQUIRED)) {
            return 0;
        }
        ServerPlayer player = source.getPlayerOrException();
        boolean enable = !GLAbilityData.get(player).infiniteStamina();
        GLAbilityData.update(player, state -> state.withInfiniteStamina(enable));
        line(source, "Infinite stamina is now " + (enable ? "ON" : "OFF") + ".");
        return 1;
    }

    private static void line(CommandSourceStack source, String text) {
        source.sendSuccess(() -> Component.literal(text), false);
    }

    private TestingCommands() {
    }
}
