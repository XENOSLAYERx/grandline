package com.nerodev.grandline.command;

import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.nerodev.grandline.data.GLPlayerData;
import com.nerodev.grandline.data.PlayerData;
import com.nerodev.grandline.permission.GLPermissions;
import com.nerodev.grandline.permission.PermissionTier;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import java.util.Locale;

public final class BountyCommand {

    private static final PermissionTier REQUIRED = PermissionTier.CREATOR;

    public static void registerHelp() {
        CommandHelp.register(new CommandHelp.Entry(
                "bounty", "bounty <set <amount> | add <amount> | reset>",
                "Sets, changes or clears your own bounty (berries).",
                REQUIRED));
    }

    public static LiteralArgumentBuilder<CommandSourceStack> build() {
        return Commands.literal("bounty")
                .requires(GLPermissions.requires(REQUIRED))
                .then(Commands.literal("set")
                        .then(Commands.argument("amount", LongArgumentType.longArg(0, PlayerData.MAX_BOUNTY))
                                .executes(context -> set(context.getSource(),
                                        LongArgumentType.getLong(context, "amount")))))
                .then(Commands.literal("add")
                        .then(Commands.argument("amount",
                                        LongArgumentType.longArg(-PlayerData.MAX_BOUNTY, PlayerData.MAX_BOUNTY))
                                .executes(context -> add(context.getSource(),
                                        LongArgumentType.getLong(context, "amount")))))
                .then(Commands.literal("reset")
                        .executes(context -> set(context.getSource(), 0L)));
    }

    private static int set(CommandSourceStack source, long amount) throws CommandSyntaxException {
        if (!GLPermissions.guard(source, REQUIRED)) {
            return 0;
        }
        ServerPlayer player = source.getPlayerOrException();
        GLPlayerData.update(player, data -> data.withBounty(amount));
        report(source, player);
        return 1;
    }

    private static int add(CommandSourceStack source, long delta) throws CommandSyntaxException {
        if (!GLPermissions.guard(source, REQUIRED)) {
            return 0;
        }
        ServerPlayer player = source.getPlayerOrException();
        GLPlayerData.update(player, data -> data.withBounty(data.bounty() + delta));
        report(source, player);
        return 1;
    }

    private static void report(CommandSourceStack source, ServerPlayer player) {
        long bounty = GLPlayerData.get(player).bounty();
        source.sendSuccess(() -> Component.literal(
                "Bounty is now " + String.format(Locale.ROOT, "%,d", bounty) + " berries."), false);
    }

    private BountyCommand() {
    }
}
