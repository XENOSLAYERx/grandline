package com.nerodev.grandline.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/**
 * Builds the /onepiece tree. Each milestone adds its module here (one registerHelp() call and one
 * then(build()) call). No /op alias: it would collide with vanilla /op.
 */
public final class GLCommands {

    public static void onRegisterCommands(RegisterCommandsEvent event) {
        register(event.getDispatcher());
    }

    private static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        // RegisterCommandsEvent fires again on /reload and on every world load.
        CommandHelp.clear();
        HelpCommand.registerHelp();
        DebugCommand.registerHelp();
        BountyCommand.registerHelp();
        HakiCommand.registerHelp();
        MasteryCommand.registerHelp();
        AbilityCommand.registerHelp();
        TestingCommands.registerHelp();
        CutsceneCommand.registerHelp();
        FruitCommand.registerHelp();

        LiteralArgumentBuilder<CommandSourceStack> root = Commands.literal("onepiece")
                .executes(context -> HelpCommand.list(context.getSource()));
        root.then(HelpCommand.build());
        root.then(DebugCommand.build());
        root.then(BountyCommand.build());
        root.then(HakiCommand.build());
        root.then(MasteryCommand.build());
        root.then(AbilityCommand.build());
        root.then(TestingCommands.buildTest());
        root.then(TestingCommands.buildCooldown());
        root.then(TestingCommands.buildStamina());
        root.then(CutsceneCommand.build());
        root.then(FruitCommand.buildFruit());
        root.then(FruitCommand.buildTransform());
        root.then(FruitCommand.buildUnlock());

        dispatcher.register(root);
    }

    private GLCommands() {
    }
}
