package com.nerodev.grandline.fruit;

import com.nerodev.grandline.GrandLineMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

import java.util.List;

/**
 * Zoan (Leopard). Three bodies: human (base), Hybrid (bigger, stronger, tougher) and Beast
 * (smaller, much faster, climbs and leaps, fragile). Passive: a little faster than normal.
 * Weakness: both forms drain stamina, the Beast has less armour than the Hybrid, and forms cannot
 * be combined with other body forms.
 * Awakening: stronger forms and claws that hit harder.
 */
public final class LeopardFruit extends DevilFruit {

    private static final ResourceLocation SPEED_ID = GrandLineMod.id("leopard_predator_speed");

    public LeopardFruit() {
        super(FruitType.ZOAN, List.of(
                GrandLineMod.id("leopard_hybrid"),
                GrandLineMod.id("leopard_beast"),
                GrandLineMod.id("leopard_claw"),
                GrandLineMod.id("leopard_pounce")));
    }

    @Override
    public void applyPassives(ServerPlayer player) {
        AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null && !speed.hasModifier(SPEED_ID)) {
            speed.addTransientModifier(new AttributeModifier(SPEED_ID, 0.05, AttributeModifier.Operation.ADD_MULTIPLIED_BASE));
        }
    }

    @Override
    public void removePassives(ServerPlayer player) {
        AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null) {
            speed.removeModifier(SPEED_ID);
        }
    }
}
