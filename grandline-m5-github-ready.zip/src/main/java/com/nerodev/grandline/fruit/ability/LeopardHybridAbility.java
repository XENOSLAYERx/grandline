package com.nerodev.grandline.fruit.ability;

import com.nerodev.grandline.ability.Ability;
import com.nerodev.grandline.ability.AbilityPhase;
import com.nerodev.grandline.ability.ActivationType;
import com.nerodev.grandline.client.vfx.ClientVfx;
import com.nerodev.grandline.fruit.FormModifiers;
import com.nerodev.grandline.fruit.FruitIds;
import com.nerodev.grandline.fruit.FruitManager;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;

import java.util.List;

/**
 * TOGGLE (Zoan body form): the leopard-man hybrid. Bigger (+25%), faster (+25%), +4 attack,
 * +4 armour, higher jumps, steps up half a block more, harder to knock back. Awakened: +2 attack
 * and +2 armour more. Costs 20, drains 2 stamina per second. Replaces the Beast form (same group).
 * The 3D model is added when the leopard model is hooked up; until then the change shows as size.
 */
public final class LeopardHybridAbility extends Ability {

    private static final String FORM = "leopard_hybrid";

    public LeopardHybridAbility() {
        super(new Properties()
                .activation(ActivationType.TOGGLE)
                .staminaCost(20)
                .upkeepPerSecond(2.0)
                .cooldown(60)
                .group(FruitIds.BODY_FORM)
                .awardsMastery(FruitIds.MASTERY));
    }

    private static List<FormModifiers.Spec> specs(boolean awakened) {
        return List.of(
                FormModifiers.spec(Attributes.SCALE, "scale", 0.25, AttributeModifier.Operation.ADD_MULTIPLIED_BASE),
                FormModifiers.spec(Attributes.MOVEMENT_SPEED, "speed", 0.25, AttributeModifier.Operation.ADD_MULTIPLIED_BASE),
                FormModifiers.spec(Attributes.ATTACK_DAMAGE, "attack", awakened ? 6.0 : 4.0, AttributeModifier.Operation.ADD_VALUE),
                FormModifiers.spec(Attributes.ARMOR, "armor", awakened ? 6.0 : 4.0, AttributeModifier.Operation.ADD_VALUE),
                FormModifiers.spec(Attributes.JUMP_STRENGTH, "jump", 0.14, AttributeModifier.Operation.ADD_VALUE),
                FormModifiers.spec(Attributes.STEP_HEIGHT, "step", 0.4, AttributeModifier.Operation.ADD_VALUE),
                FormModifiers.spec(Attributes.KNOCKBACK_RESISTANCE, "knockback", 0.25, AttributeModifier.Operation.ADD_VALUE));
    }

    @Override
    public void onToggleOn(ServerPlayer player) {
        FormModifiers.apply(player, FORM, specs(FruitManager.isAwakened(player)));
    }

    @Override
    public void onToggleOff(ServerPlayer player) {
        FormModifiers.remove(player, FORM, specs(false));
    }

    @Override
    public void clientEffects(Level level, LivingEntity caster, AbilityPhase phase, float intensity) {
        double x = caster.getX();
        double y = caster.getY();
        double z = caster.getZ();
        if (phase == AbilityPhase.TOGGLE_ON) {
            ClientVfx.shockwave(level, x, y + 1.0, z, 0xE8B040, 0.5f, 3.5f, 9);
            ClientVfx.burst(level, x, y + 1.0, z, 20, 0xE8B040, 0.25f, 0.3f, 12);
            ClientVfx.sparks(level, x, y + 1.0, z, 10, 0xFFE6A0, 0.3f);
            ClientVfx.localShake(caster, 0.6f, 8);
            ClientVfx.localFovPunch(caster, 6.0f, 8);
        } else if (phase == AbilityPhase.TOGGLE_OFF) {
            ClientVfx.burst(level, x, y + 1.0, z, 10, 0xE8B040, 0.15f, 0.25f, 10);
        }
    }
}
