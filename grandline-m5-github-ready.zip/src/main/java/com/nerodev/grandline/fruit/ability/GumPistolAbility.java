package com.nerodev.grandline.fruit.ability;

import com.nerodev.grandline.ability.Ability;
import com.nerodev.grandline.ability.AbilityPhase;
import com.nerodev.grandline.client.vfx.ClientVfx;
import com.nerodev.grandline.fruit.Combat;
import com.nerodev.grandline.fruit.FruitIds;
import com.nerodev.grandline.fruit.FruitManager;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/** PRESS: the arm stretches 9 blocks and punches the first enemy in line. Awakened: through every enemy in line. */
public final class GumPistolAbility extends Ability {

    private static final double RANGE = 9.0;

    public GumPistolAbility() {
        super(new Properties().cooldown(14).staminaCost(12).awardsMastery(FruitIds.MASTERY));
    }

    @Override
    public boolean execute(ServerPlayer player) {
        boolean awakened = FruitManager.isAwakened(player);
        List<LivingEntity> hits = Combat.along(player, RANGE, 0.7);
        int count = awakened ? hits.size() : Math.min(1, hits.size());
        for (int i = 0; i < count; i++) {
            Combat.hit(player, hits.get(i), awakened ? 9.0f : 6.0f, 1.3, false);
        }
        return true;
    }

    @Override
    public void clientEffects(Level level, LivingEntity caster, AbilityPhase phase, float intensity) {
        if (phase != AbilityPhase.USE) {
            return;
        }
        Vec3 eye = caster.getEyePosition();
        Vec3 look = caster.getLookAngle();
        Vec3 from = eye.add(look.scale(0.7)).add(0.0, -0.35, 0.0);
        Vec3 to = eye.add(look.scale(RANGE)).add(0.0, -0.2, 0.0);
        ClientVfx.line(level, from, to, 0xFFC7A0, 24, 0.18f);
        ClientVfx.burst(level, to.x, to.y, to.z, 8, 0xFFFFFF, 0.2f, 0.25f, 8);
        ClientVfx.localShake(caster, 0.35f, 5);
    }
}
