package com.nerodev.grandline.fruit;

import com.nerodev.grandline.GrandLineMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

import java.util.List;

/**
 * Paramecia. A rubber body: stretch punches, grapple pulls, balloon float.
 * Passives: no fall damage, immune to lightning (see FruitEvents).
 * Weakness: edged and piercing damage is not softened here, stamina drains fast during Gatling and
 * Balloon, and the Balloon only stops projectiles (not melee, fire or explosions).
 * Awakening: the stretch reaches through every enemy in line, Rocket pulls the target to you, and
 * the Bazooka hits everything in a wide cone.
 */
public final class GumFruit extends DevilFruit {

    private static final ResourceLocation FALL_ID = GrandLineMod.id("gum_rubber_fall");

    public GumFruit() {
        super(FruitType.PARAMECIA, List.of(
                GrandLineMod.id("gum_pistol"),
                GrandLineMod.id("gum_rocket"),
                GrandLineMod.id("gum_balloon"),
                GrandLineMod.id("gum_bazooka"),
                GrandLineMod.id("gum_gatling")));
    }

    @Override
    public void applyPassives(ServerPlayer player) {
        AttributeInstance fall = player.getAttribute(Attributes.FALL_DAMAGE_MULTIPLIER);
        if (fall != null && !fall.hasModifier(FALL_ID)) {
            fall.addTransientModifier(new AttributeModifier(FALL_ID, -1.0, AttributeModifier.Operation.ADD_MULTIPLIED_BASE));
        }
    }

    @Override
    public void removePassives(ServerPlayer player) {
        AttributeInstance fall = player.getAttribute(Attributes.FALL_DAMAGE_MULTIPLIER);
        if (fall != null) {
            fall.removeModifier(FALL_ID);
        }
    }
}
