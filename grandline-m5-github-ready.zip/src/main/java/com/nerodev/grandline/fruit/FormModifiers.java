package com.nerodev.grandline.fruit;

import com.nerodev.grandline.GrandLineMod;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;

import java.util.List;

/** Applies and removes a set of attribute changes for a body form. Modifier ids are form + key, so removal never depends on the amounts. */
public final class FormModifiers {

    public record Spec(Holder<Attribute> attribute, String key, double amount, AttributeModifier.Operation operation) {
    }

    public static Spec spec(Holder<Attribute> attribute, String key, double amount, AttributeModifier.Operation operation) {
        return new Spec(attribute, key, amount, operation);
    }

    public static void apply(ServerPlayer player, String form, List<Spec> specs) {
        for (Spec spec : specs) {
            AttributeInstance instance = player.getAttribute(spec.attribute());
            if (instance != null) {
                ResourceLocation id = GrandLineMod.id(form + "_" + spec.key());
                instance.removeModifier(id);
                instance.addTransientModifier(new AttributeModifier(id, spec.amount(), spec.operation()));
            }
        }
    }

    public static void remove(ServerPlayer player, String form, List<Spec> specs) {
        for (Spec spec : specs) {
            AttributeInstance instance = player.getAttribute(spec.attribute());
            if (instance != null) {
                instance.removeModifier(GrandLineMod.id(form + "_" + spec.key()));
            }
        }
    }

    private FormModifiers() {
    }
}
