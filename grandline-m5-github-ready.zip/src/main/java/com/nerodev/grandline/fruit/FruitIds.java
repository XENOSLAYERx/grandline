package com.nerodev.grandline.fruit;

import com.nerodev.grandline.GrandLineMod;
import net.minecraft.resources.ResourceLocation;

/** Ids used in more than one place. */
public final class FruitIds {

    public static final ResourceLocation MASTERY = GrandLineMod.id("fruit");
    /** Abilities in this group are body forms; only one can be on at a time. */
    public static final ResourceLocation BODY_FORM = GrandLineMod.id("body_form");

    public static final ResourceLocation GUM = GrandLineMod.id("gum");
    public static final ResourceLocation MERA = GrandLineMod.id("mera");
    public static final ResourceLocation LEOPARD = GrandLineMod.id("leopard");

    public static final ResourceLocation GUM_BALLOON = GrandLineMod.id("gum_balloon");
    public static final ResourceLocation MERA_FLAME_BODY = GrandLineMod.id("mera_flame_body");
    public static final ResourceLocation LEOPARD_HYBRID = GrandLineMod.id("leopard_hybrid");
    public static final ResourceLocation LEOPARD_BEAST = GrandLineMod.id("leopard_beast");

    private FruitIds() {
    }
}
