package com.nerodev.grandline.fruit.ability;

import com.nerodev.grandline.ability.Ability;
import com.nerodev.grandline.ability.AbilityPhase;
import com.nerodev.grandline.client.vfx.ClientVfx;
import com.nerodev.grandline.fruit.Combat;
import com.nerodev.grandline.fruit.FruitIds;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** PRESS (movement): burst forward as flame, scorching everything within 2.5 blocks of where you started. Cost 14, cooldown 2.5 s. */
public final class MeraDashAbility extends Ability {

    public MeraDashAbility() {
        super(new Properties().cooldown(50).staminaCost(14).awardsMastery(FruitIds.MASTERY));
    }

    @Override
    public boolean execute(ServerPlayer player) {
        for (LivingEntity entity : Combat.cone(player, 2.5, 180.0)) {
            Combat.hit(player, entity, 3.0f, 0.6, false);
            entity.igniteForSeconds(3.0f);
        }
        Vec3 look = player.getLookAngle();
        player.setDeltaMovement(look.x * 1.6, 0.25 + Math.max(0.0, look.y * 0.8), look.z * 1.6);
        player.hurtMarked = true;
        player.fallDistance = 0.0f;
        return true;
    }

    @Override
    public void clientEffects(Level level, LivingEntity caster, AbilityPhase phase, float intensity) {
        if (phase != AbilityPhase.USE) {
            return;
        }
        double x = caster.getX();
        double y = caster.getY();
        double z = caster.getZ();
        ClientVfx.ring(level, x, y + 0.2, z, 0.5f, 22, 0xFF8A2A, 0.35f, 0.3f, 12);
        ClientVfx.burst(level, x, y + 0.9, z, 16, 0xFFD060, 0.25f, 0.28f, 12);
        ClientVfx.localFovPunch(caster, 9.0f, 8);
    }
}
