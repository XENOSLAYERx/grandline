package com.nerodev.grandline.fruit.ability;

import com.nerodev.grandline.ability.Ability;
import com.nerodev.grandline.ability.AbilityManager;
import com.nerodev.grandline.ability.AbilityPhase;
import com.nerodev.grandline.client.vfx.ClientVfx;
import com.nerodev.grandline.fruit.Combat;
import com.nerodev.grandline.fruit.FruitIds;
import com.nerodev.grandline.fruit.FruitManager;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * PRESS: a quick claw swipe in a 3.4 block cone, hits up to 3 enemies and leaves them bleeding
 * (poison for 3 s, which never kills). 5 damage, +3 while in Hybrid or Beast form, x1.5 awakened.
 * Cost 10, cooldown 0.6 s.
 */
public final class LeopardClawAbility extends Ability {

    public LeopardClawAbility() {
        super(new Properties().cooldown(12).staminaCost(10).awardsMastery(FruitIds.MASTERY));
    }

    @Override
    public boolean execute(ServerPlayer player) {
        boolean inForm = AbilityManager.isActive(player, FruitIds.LEOPARD_HYBRID)
                || AbilityManager.isActive(player, FruitIds.LEOPARD_BEAST);
        float damage = (5.0f + (inForm ? 3.0f : 0.0f)) * (FruitManager.isAwakened(player) ? 1.5f : 1.0f);
        List<LivingEntity> hits = Combat.cone(player, 3.4, 42.0);
        int count = Math.min(3, hits.size());
        for (int i = 0; i < count; i++) {
            LivingEntity target = hits.get(i);
            Combat.hit(player, target, damage, 0.5, false);
            target.addEffect(new MobEffectInstance(MobEffects.POISON, 60, 0));
        }
        return true;
    }

    @Override
    public void clientEffects(Level level, LivingEntity caster, AbilityPhase phase, float intensity) {
        if (phase != AbilityPhase.USE) {
            return;
        }
        Vec3 at = caster.getEyePosition().add(caster.getLookAngle().scale(1.8)).add(0.0, -0.2, 0.0);
        ClientVfx.slash(level, at.x, at.y, at.z, 0xFFF0C0, 0.9f, 7);
        ClientVfx.sparks(level, at.x, at.y, at.z, 6, 0xFFE6A0, 0.3f);
        ClientVfx.localShake(caster, 0.25f, 4);
    }
}
