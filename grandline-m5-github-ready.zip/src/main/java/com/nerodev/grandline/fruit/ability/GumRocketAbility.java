package com.nerodev.grandline.fruit.ability;

import com.nerodev.grandline.ability.Ability;
import com.nerodev.grandline.ability.AbilityPhase;
import com.nerodev.grandline.client.vfx.ClientVfx;
import com.nerodev.grandline.fruit.Combat;
import com.nerodev.grandline.fruit.FruitIds;
import com.nerodev.grandline.fruit.FruitManager;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * PRESS: the arm stretches up to 24 blocks and grabs the first thing it hits. A wall or an enemy:
 * you are pulled to it. Awakened: an enemy is pulled to you instead. If nothing is in reach the
 * ability is cancelled and costs nothing.
 */
public final class GumRocketAbility extends Ability {

    private static final double RANGE = 24.0;

    public GumRocketAbility() {
        super(new Properties().cooldown(40).staminaCost(10).awardsMastery(FruitIds.MASTERY));
    }

    @Override
    public boolean execute(ServerPlayer player) {
        ServerLevel level = (ServerLevel) player.level();
        Vec3 start = player.getEyePosition();
        Vec3 dir = player.getLookAngle();

        List<LivingEntity> targets = Combat.along(player, RANGE, 0.8);
        if (!targets.isEmpty()) {
            LivingEntity target = targets.get(0);
            if (FruitManager.isAwakened(player)) {
                pull(target, player.position().add(0.0, 0.5, 0.0), 2.0);
            } else {
                pull(player, target.position().add(0.0, 0.5, 0.0), 2.2);
            }
            return true;
        }

        double reach = Combat.blockDistance(level, player, start, start.add(dir.scale(RANGE)));
        if (reach >= RANGE - 0.1) {
            player.displayClientMessage(Component.literal("Nothing in reach to grab."), true);
            return false;
        }
        pull(player, start.add(dir.scale(reach)), 2.2);
        return true;
    }

    /** Sets the entity's velocity toward the anchor, stronger for longer distances. */
    private static void pull(LivingEntity entity, Vec3 anchor, double maxSpeed) {
        Vec3 to = anchor.subtract(entity.position());
        double distance = Math.max(0.5, to.length());
        Vec3 velocity = to.normalize().scale(Math.min(maxSpeed, 0.5 + distance * 0.11));
        entity.setDeltaMovement(velocity.x, velocity.y + 0.15, velocity.z);
        entity.hurtMarked = true;
        entity.fallDistance = 0.0f;
    }

    @Override
    public void clientEffects(Level level, LivingEntity caster, AbilityPhase phase, float intensity) {
        if (phase != AbilityPhase.USE) {
            return;
        }
        Vec3 eye = caster.getEyePosition();
        Vec3 look = caster.getLookAngle();
        ClientVfx.line(level, eye.add(look.scale(0.7)).add(0.0, -0.35, 0.0), eye.add(look.scale(14.0)), 0xFFC7A0, 34, 0.16f);
        ClientVfx.localFovPunch(caster, 6.0f, 8);
    }
}
