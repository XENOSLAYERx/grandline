package com.nerodev.grandline.fruit.ability;

import com.nerodev.grandline.ability.Ability;
import com.nerodev.grandline.ability.ActivationType;
import com.nerodev.grandline.client.vfx.ClientVfx;
import com.nerodev.grandline.fruit.Combat;
import com.nerodev.grandline.fruit.FruitIds;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * HOLD: a stream of flame in front of you while the key is held. Every 5 ticks it burns up to 4
 * enemies in a cone (6 blocks). Costs 4 to start, drains 9 stamina per second. Needs fruit mastery 5.
 */
public final class MeraJetAbility extends Ability {

    public MeraJetAbility() {
        super(new Properties()
                .activation(ActivationType.HOLD)
                .staminaCost(4)
                .upkeepPerSecond(9.0)
                .cooldown(30)
                .requiresMastery(FruitIds.MASTERY, 5)
                .awardsMastery(FruitIds.MASTERY));
    }

    @Override
    public void onHoldTick(ServerPlayer player, int heldTicks) {
        if (heldTicks % 5 != 0) {
            return;
        }
        List<LivingEntity> hits = Combat.cone(player, 6.0, 26.0);
        int count = Math.min(4, hits.size());
        for (int i = 0; i < count; i++) {
            LivingEntity target = hits.get(i);
            Combat.hit(player, target, 1.5f, 0.15, true);
            target.igniteForSeconds(3.0f);
        }
    }

    @Override
    public void clientTick(Level level, LivingEntity caster) {
        Vec3 look = caster.getLookAngle();
        Vec3 origin = caster.getEyePosition().add(look.scale(0.7)).add(0.0, -0.3, 0.0);
        ClientVfx.stream(level, origin, look, 0.22, 6, 0xFF8A2A, 0.5f, 0.3f, 10);
        ClientVfx.stream(level, origin, look, 0.12, 2, 0xFFE070, 0.55f, 0.2f, 8);
    }
}
