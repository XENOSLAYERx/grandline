package com.nerodev.grandline.fruit.item;

import com.nerodev.grandline.GrandLineMod;
import com.nerodev.grandline.fruit.FruitIds;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

/** Items and the creative tab. One item per fruit; its icon is textures/item/devil_fruit_<name>.png. */
public final class GLItems {

    private static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(GrandLineMod.MODID);
    private static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, GrandLineMod.MODID);

    public static final DeferredItem<DevilFruitItem> FRUIT_GUM =
            ITEMS.register("devil_fruit_gum", () -> new DevilFruitItem(FruitIds.GUM));
    public static final DeferredItem<DevilFruitItem> FRUIT_MERA =
            ITEMS.register("devil_fruit_mera", () -> new DevilFruitItem(FruitIds.MERA));
    public static final DeferredItem<DevilFruitItem> FRUIT_LEOPARD =
            ITEMS.register("devil_fruit_leopard", () -> new DevilFruitItem(FruitIds.LEOPARD));

    public static final Supplier<CreativeModeTab> TAB = TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.grandline"))
            .icon(() -> new ItemStack(FRUIT_LEOPARD.get()))
            .displayItems((parameters, output) -> {
                output.accept(FRUIT_GUM.get());
                output.accept(FRUIT_MERA.get());
                output.accept(FRUIT_LEOPARD.get());
            })
            .build());

    public static void register(IEventBus modEventBus) {
        ITEMS.register(modEventBus);
        TABS.register(modEventBus);
    }

    private GLItems() {
    }
}
