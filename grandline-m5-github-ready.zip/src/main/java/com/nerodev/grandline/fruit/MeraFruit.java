package com.nerodev.grandline.fruit;

import com.nerodev.grandline.GrandLineMod;
import net.minecraft.server.level.ServerPlayer;

import java.util.List;

/**
 * Logia (fire). Passive: immune to fire and lava damage. The Flame Body toggle makes attacks from
 * living things pass through you (see FruitEvents / LogiaRules).
 * Weakness: water breaks the flame body; Armament Haki users can still hit you; the Flame Body
 * drains stamina and switches off when it runs out; environmental damage (falls, void,
 * suffocation, explosions from the world) is never negated.
 * Awakening: the Flame Body sets nearby enemies on fire, and the Hiken and Jet burn through
 * everything in their path.
 */
public final class MeraFruit extends DevilFruit {

    public MeraFruit() {
        super(FruitType.LOGIA, List.of(
                GrandLineMod.id("mera_flame_body"),
                GrandLineMod.id("mera_hiken"),
                GrandLineMod.id("mera_dash"),
                GrandLineMod.id("mera_jet")));
    }

    @Override
    public void applyPassives(ServerPlayer player) {
        player.clearFire();
    }
}
