package com.nerodev.grandline.fruit;

public enum FruitType {
    PARAMECIA("Paramecia"),
    ZOAN("Zoan"),
    LOGIA("Logia");

    private final String label;

    FruitType(String label) {
        this.label = label;
    }

    public String label() {
        return label;
    }
}
