package com.nerodev.grandline.fruit.ability;

import com.nerodev.grandline.ability.Ability;
import com.nerodev.grandline.ability.AbilityPhase;
import com.nerodev.grandline.ability.ActivationType;
import com.nerodev.grandline.client.vfx.ClientVfx;
import com.nerodev.grandline.fruit.FormModifiers;
import com.nerodev.grandline.fruit.FruitIds;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;

import java.util.List;

/**
 * TOGGLE (Zoan body form): the full leopard. Smaller (-15%, so it fits through 1-block gaps),
 * +60% speed, +5 attack, much higher jumps, climbs 1-block ledges, takes 80% less fall damage.
 * No extra armour, so it is fragile. Costs 25, drains 3 stamina per second. Needs fruit mastery 15.
 * Replaces the Hybrid form (same group). Model arrives with the leopard model hookup.
 */
public final class LeopardBeastAbility extends Ability {

    private static final String FORM = "leopard_beast";

    private static final List<FormModifiers.Spec> SPECS = List.of(
            FormModifiers.spec(Attributes.SCALE, "scale", -0.15, AttributeModifier.Operation.ADD_MULTIPLIED_BASE),
            FormModifiers.spec(Attributes.MOVEMENT_SPEED, "speed", 0.6, AttributeModifier.Operation.ADD_MULTIPLIED_BASE),
            FormModifiers.spec(Attributes.ATTACK_DAMAGE, "attack", 5.0, AttributeModifier.Operation.ADD_VALUE),
            FormModifiers.spec(Attributes.JUMP_STRENGTH, "jump", 0.25, AttributeModifier.Operation.ADD_VALUE),
            FormModifiers.spec(Attributes.STEP_HEIGHT, "step", 1.0, AttributeModifier.Operation.ADD_VALUE),
            FormModifiers.spec(Attributes.FALL_DAMAGE_MULTIPLIER, "fall", -0.8, AttributeModifier.Operation.ADD_MULTIPLIED_BASE));

    public LeopardBeastAbility() {
        super(new Properties()
                .activation(ActivationType.TOGGLE)
                .staminaCost(25)
                .upkeepPerSecond(3.0)
                .cooldown(60)
                .requiresMastery(FruitIds.MASTERY, 15)
                .group(FruitIds.BODY_FORM)
                .awardsMastery(FruitIds.MASTERY));
    }

    @Override
    public void onToggleOn(ServerPlayer player) {
        FormModifiers.apply(player, FORM, SPECS);
    }

    @Override
    public void onToggleOff(ServerPlayer player) {
        FormModifiers.remove(player, FORM, SPECS);
    }

    @Override
    public void clientEffects(Level level, LivingEntity caster, AbilityPhase phase, float intensity) {
        double x = caster.getX();
        double y = caster.getY();
        double z = caster.getZ();
        if (phase == AbilityPhase.TOGGLE_ON) {
            ClientVfx.shockwave(level, x, y + 0.8, z, 0xE8B040, 0.4f, 3.0f, 8);
            ClientVfx.burst(level, x, y + 0.8, z, 16, 0xE8B040, 0.3f, 0.26f, 10);
            ClientVfx.localFovPunch(caster, 10.0f, 8);
        } else if (phase == AbilityPhase.TOGGLE_OFF) {
            ClientVfx.burst(level, x, y + 0.8, z, 8, 0xE8B040, 0.15f, 0.22f, 10);
        }
    }
}
