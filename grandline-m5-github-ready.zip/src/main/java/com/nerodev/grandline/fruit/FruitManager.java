package com.nerodev.grandline.fruit;

import com.nerodev.grandline.ability.AbilityManager;
import com.nerodev.grandline.data.AbilitySlots;
import com.nerodev.grandline.data.GLPlayerData;
import com.nerodev.grandline.data.PlayerData;
import com.nerodev.grandline.data.Unlocks;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

import java.util.Optional;

/**
 * Everything about holding a fruit. Eating an item and /onepiece fruit give both end up here, so
 * there is one set of rules: one fruit at a time, its abilities go on keys 1..n, passives are
 * applied, and removing it cleans all of that up again.
 */
public final class FruitManager {

    // ---- reading (both sides) ----

    public static Optional<DevilFruit> current(Player player) {
        return GLPlayerData.get(player).equippedFruit().flatMap(GLFruits.REGISTRY::getOptional);
    }

    public static boolean isAwakened(Player player) {
        return GLPlayerData.get(player).fruitAwakened();
    }

    // ---- changing (server) ----

    /**
     * Gives the player the fruit. replace = false (eating): refused if they already hold one, so a
     * second fruit is never wasted. replace = true (Creator tools): swaps the old fruit out.
     */
    public static boolean equip(ServerPlayer player, ResourceLocation fruitId, boolean replace) {
        Optional<DevilFruit> found = GLFruits.REGISTRY.getOptional(fruitId);
        if (found.isEmpty()) {
            return false;
        }
        if (GLPlayerData.get(player).equippedFruit().isPresent()) {
            if (!replace) {
                player.displayClientMessage(Component.literal("Your body already holds a Devil Fruit."), true);
                return false;
            }
            remove(player);
        }

        DevilFruit fruit = found.get();
        GLPlayerData.update(player, data -> {
            Unlocks unlocks = data.unlocks().withFruit(fruitId);
            AbilitySlots slots = data.abilitySlots();
            for (int i = 0; i < fruit.abilities().size() && i < AbilitySlots.COUNT; i++) {
                unlocks = unlocks.withAbility(fruit.abilities().get(i));
                slots = slots.equip(i, fruit.abilities().get(i));
            }
            return data.withUnlocks(unlocks)
                    .withAbilitySlots(slots)
                    .withEquippedFruit(Optional.of(fruitId))
                    .withFruitAwakened(false);
        });
        fruit.applyPassives(player);
        return true;
    }

    public static void remove(ServerPlayer player) {
        Optional<DevilFruit> found = current(player);
        if (found.isEmpty()) {
            return;
        }
        DevilFruit fruit = found.get();
        AbilityManager.endAll(player); // undoes toggles and holds (forms, auras) before their abilities leave the keys
        GLPlayerData.update(player, data -> {
            AbilitySlots slots = data.abilitySlots();
            for (int i = 0; i < AbilitySlots.COUNT; i++) {
                if (slots.get(i).filter(fruit.abilities()::contains).isPresent()) {
                    slots = slots.unequip(i);
                }
            }
            return data.withAbilitySlots(slots)
                    .withEquippedFruit(Optional.empty())
                    .withFruitAwakened(false);
        });
        fruit.removePassives(player);
    }

    /** Creator: force = true skips the mastery requirement. */
    public static boolean awaken(ServerPlayer player, boolean force) {
        Optional<DevilFruit> found = current(player);
        if (found.isEmpty()) {
            player.displayClientMessage(Component.literal("You have no Devil Fruit to awaken."), true);
            return false;
        }
        if (isAwakened(player)) {
            return true;
        }
        DevilFruit fruit = found.get();
        int mastery = GLPlayerData.get(player).mastery().getOrDefault(FruitIds.MASTERY, 0);
        if (!force && mastery < fruit.awakeningMastery()) {
            player.displayClientMessage(Component.literal(
                    "Awakening needs fruit mastery " + fruit.awakeningMastery() + " (you have " + mastery + ")."), true);
            return false;
        }
        GLPlayerData.update(player, data -> data.withFruitAwakened(true));
        fruit.onAwaken(player);
        player.displayClientMessage(Component.empty().append(fruit.displayName())
                .append(Component.literal(" has awakened!")), false);
        return true;
    }

    /** Called when fruit mastery rises: awakens automatically once the requirement is met. */
    public static void awakenIfEarned(ServerPlayer player) {
        Optional<DevilFruit> found = current(player);
        if (found.isPresent() && !isAwakened(player)
                && GLPlayerData.get(player).mastery().getOrDefault(FruitIds.MASTERY, 0) >= found.get().awakeningMastery()) {
            awaken(player, false);
        }
    }

    /** Passives are attribute modifiers that do not survive death or relog, so re-apply them. */
    public static void refreshPassives(ServerPlayer player) {
        current(player).ifPresent(fruit -> fruit.applyPassives(player));
    }

    private FruitManager() {
    }
}
