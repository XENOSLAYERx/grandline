package com.nerodev.grandline.fruit.ability;

import com.nerodev.grandline.ability.Ability;
import com.nerodev.grandline.ability.AbilityPhase;
import com.nerodev.grandline.ability.ActivationType;
import com.nerodev.grandline.client.vfx.ClientVfx;
import com.nerodev.grandline.fruit.Combat;
import com.nerodev.grandline.fruit.FruitIds;
import com.nerodev.grandline.fruit.FruitManager;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * CHARGE (signature move): hold up to 1.5 s, release for a two-handed palm strike in front of
 * you. A longer charge hits harder and throws enemies further. Hits up to 3 enemies; awakened it
 * hits everything in a wide cone. Cost 28, cooldown 4 s, needs fruit mastery 30.
 */
public final class GumBazookaAbility extends Ability {

    public GumBazookaAbility() {
        super(new Properties()
                .activation(ActivationType.CHARGE)
                .charge(8, 30)
                .staminaCost(28)
                .cooldown(80)
                .requiresMastery(FruitIds.MASTERY, 30)
                .awardsMastery(FruitIds.MASTERY));
    }

    @Override
    public boolean executeCharged(ServerPlayer player, float fraction) {
        boolean awakened = FruitManager.isAwakened(player);
        List<LivingEntity> hits = Combat.cone(player, awakened ? 6.0 : 4.5, awakened ? 55.0 : 35.0);
        int count = awakened ? hits.size() : Math.min(3, hits.size());
        float damage = (8.0f + 14.0f * fraction) * (awakened ? 1.3f : 1.0f);
        for (int i = 0; i < count; i++) {
            Combat.hit(player, hits.get(i), damage, 2.0 + 2.2 * fraction, false);
        }
        return true;
    }

    @Override
    public void clientEffects(Level level, LivingEntity caster, AbilityPhase phase, float intensity) {
        Vec3 eye = caster.getEyePosition();
        Vec3 look = caster.getLookAngle();
        if (phase == AbilityPhase.CHARGE_START) {
            ClientVfx.ring(level, caster.getX(), caster.getY() + 0.1, caster.getZ(), 0.5f, 12, 0xFFB0B8, 0.1f, 0.2f, 10);
        } else if (phase == AbilityPhase.CHARGE_RELEASE) {
            Vec3 hit = eye.add(look.scale(3.2));
            ClientVfx.shockwave(level, hit.x, hit.y, hit.z, 0xFFD7D7, 0.6f, 3.0f + 3.0f * intensity, 8);
            ClientVfx.burst(level, hit.x, hit.y, hit.z, (int) (10 + 18 * intensity), 0xFFB0B8, 0.3f + 0.3f * intensity, 0.3f, 12);
            ClientVfx.localShake(caster, 0.6f + 1.0f * intensity, 9);
            ClientVfx.localFovPunch(caster, 8.0f * intensity, 8);
        }
    }
}
