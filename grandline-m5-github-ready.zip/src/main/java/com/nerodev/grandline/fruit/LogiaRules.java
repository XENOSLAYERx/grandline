package com.nerodev.grandline.fruit;

import com.nerodev.grandline.ability.AbilityManager;
import com.nerodev.grandline.haki.HakiIds;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;

/**
 * The one place that decides whether a Logia body lets an attack pass through. A Logia is never
 * invincible: only attacks from living things are negated, and these counters always apply.
 *
 *   - Environment: falls, void, suffocation, lava and the like are never negated (no attacker).
 *   - Water: a Logia standing in water has no flame body.
 *   - Armament Haki: an attacker whose Armament hardening is switched on can hit a Logia.
 *   - Seastone arrives with the weapons milestone and plugs in here too.
 */
public final class LogiaRules {

    public static boolean negates(DamageSource source, ServerPlayer victim) {
        if (!(source.getEntity() instanceof LivingEntity attacker) || attacker == victim) {
            return false;
        }
        if (victim.isInWater()) {
            return false;
        }
        if (attacker instanceof ServerPlayer player && AbilityManager.isActive(player, HakiIds.ARMAMENT)) {
            return false;                                // Armament Haki is on: the body can be hit
        }
        return true;
    }

    private LogiaRules() {
    }
}
