package com.nerodev.grandline.fruit.ability;

import com.nerodev.grandline.ability.Ability;
import com.nerodev.grandline.ability.AbilityPhase;
import com.nerodev.grandline.ability.ActivationType;
import com.nerodev.grandline.client.vfx.ClientVfx;
import com.nerodev.grandline.fruit.Combat;
import com.nerodev.grandline.fruit.FruitIds;
import com.nerodev.grandline.fruit.FruitManager;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * CHARGE (signature move): release a beam of fire along your line of sight. A longer charge
 * makes it longer, wider, hotter and sets targets on fire for longer. Stopped by walls. Hits up
 * to 3 enemies, awakened it burns through all of them. Cost 26, cooldown 3.5 s, needs fruit mastery 25.
 */
public final class MeraHikenAbility extends Ability {

    public MeraHikenAbility() {
        super(new Properties()
                .activation(ActivationType.CHARGE)
                .charge(6, 24)
                .staminaCost(26)
                .cooldown(70)
                .requiresMastery(FruitIds.MASTERY, 25)
                .awardsMastery(FruitIds.MASTERY));
    }

    @Override
    public boolean executeCharged(ServerPlayer player, float fraction) {
        boolean awakened = FruitManager.isAwakened(player);
        double range = (14.0 + 10.0 * fraction) * (awakened ? 1.4 : 1.0);
        List<LivingEntity> hits = Combat.along(player, range, 0.9 + 0.6 * fraction);
        int count = awakened ? hits.size() : Math.min(3, hits.size());
        for (int i = 0; i < count; i++) {
            LivingEntity target = hits.get(i);
            Combat.hit(player, target, 7.0f + 11.0f * fraction, 1.2, false);
            target.igniteForSeconds(4.0f + 4.0f * fraction);
        }
        return true;
    }

    @Override
    public void clientEffects(Level level, LivingEntity caster, AbilityPhase phase, float intensity) {
        Vec3 eye = caster.getEyePosition();
        Vec3 look = caster.getLookAngle();
        if (phase == AbilityPhase.CHARGE_START) {
            ClientVfx.ring(level, caster.getX(), caster.getY() + 0.1, caster.getZ(), 0.4f, 14, 0xFF8A2A, 0.12f, 0.22f, 10);
        } else if (phase == AbilityPhase.CHARGE_RELEASE) {
            double length = 14.0 + 10.0 * intensity;
            Vec3 from = eye.add(look.scale(0.8)).add(0.0, -0.3, 0.0);
            Vec3 to = eye.add(look.scale(length));
            ClientVfx.line(level, from, to, 0xFF7A1A, (int) (24 + 30 * intensity), 0.34f);
            ClientVfx.line(level, from, to, 0xFFE070, (int) (16 + 20 * intensity), 0.18f);
            ClientVfx.burst(level, to.x, to.y, to.z, (int) (12 + 20 * intensity), 0xFF8A2A, 0.35f, 0.35f, 14);
            ClientVfx.localShake(caster, 0.5f + 0.9f * intensity, 8);
            ClientVfx.localFovPunch(caster, 8.0f * intensity, 8);
        }
    }
}
