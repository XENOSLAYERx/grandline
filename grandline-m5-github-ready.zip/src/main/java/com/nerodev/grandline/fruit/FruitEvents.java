package com.nerodev.grandline.fruit;

import com.nerodev.grandline.ability.AbilityManager;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;

import java.util.Optional;

/** Fruit passives that need an event: damage immunities and the Logia / Balloon rules. */
public final class FruitEvents {

    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            FruitManager.refreshPassives(player);
        }
    }

    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            FruitManager.refreshPassives(player);
        }
    }

    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer victim)) {
            return;
        }
        Optional<DevilFruit> fruit = FruitManager.current(victim);
        if (fruit.isEmpty()) {
            return;
        }
        DamageSource source = event.getSource();

        if (fruit.get() instanceof GumFruit && source.is(DamageTypeTags.IS_LIGHTNING)) {
            event.setCanceled(true);                      // rubber
            return;
        }
        if (AbilityManager.isActive(victim, FruitIds.GUM_BALLOON) && source.is(DamageTypeTags.IS_PROJECTILE)) {
            event.setCanceled(true);                      // projectiles bounce off the balloon
            return;
        }
        if (fruit.get() instanceof MeraFruit) {
            if (source.is(DamageTypeTags.IS_FIRE)) {
                event.setCanceled(true);                  // fire cannot burn fire
                victim.clearFire();
                return;
            }
            if (AbilityManager.isActive(victim, FruitIds.MERA_FLAME_BODY) && LogiaRules.negates(source, victim)) {
                event.setCanceled(true);                  // the attack passes through the flame body
            }
        }
    }

    private FruitEvents() {
    }
}
