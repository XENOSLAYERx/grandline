package com.nerodev.grandline.fruit.ability;

import com.nerodev.grandline.ability.Ability;
import com.nerodev.grandline.ability.ActivationType;
import com.nerodev.grandline.ability.AbilityPhase;
import com.nerodev.grandline.client.vfx.ClientVfx;
import com.nerodev.grandline.fruit.FormModifiers;
import com.nerodev.grandline.fruit.FruitIds;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;

import java.util.List;

/**
 * TOGGLE (body form): puff up. Bigger, floaty (much lower gravity) and projectiles bounce off
 * (see FruitEvents). Melee, fire and explosions still hurt. Costs 10, drains 5 stamina per second,
 * needs fruit mastery 15.
 */
public final class GumBalloonAbility extends Ability {

    private static final String FORM = "gum_balloon";
    private static final int COLOR = 0xFFB0B8;

    private static final List<FormModifiers.Spec> SPECS = List.of(
            FormModifiers.spec(Attributes.GRAVITY, "gravity", -0.7, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL),
            FormModifiers.spec(Attributes.SCALE, "scale", 0.3, AttributeModifier.Operation.ADD_MULTIPLIED_BASE));

    public GumBalloonAbility() {
        super(new Properties()
                .activation(ActivationType.TOGGLE)
                .staminaCost(10)
                .upkeepPerSecond(5.0)
                .cooldown(40)
                .requiresMastery(FruitIds.MASTERY, 15)
                .group(FruitIds.BODY_FORM)
                .awardsMastery(FruitIds.MASTERY));
    }

    @Override
    public void onToggleOn(ServerPlayer player) {
        FormModifiers.apply(player, FORM, SPECS);
        player.fallDistance = 0.0f;
    }

    @Override
    public void onToggleOff(ServerPlayer player) {
        FormModifiers.remove(player, FORM, SPECS);
    }

    @Override
    public void clientEffects(Level level, LivingEntity caster, AbilityPhase phase, float intensity) {
        if (phase == AbilityPhase.TOGGLE_ON) {
            ClientVfx.burst(level, caster.getX(), caster.getY() + 1.0, caster.getZ(), 14, COLOR, 0.2f, 0.28f, 12);
            ClientVfx.localFovPunch(caster, 5.0f, 8);
        } else if (phase == AbilityPhase.TOGGLE_OFF) {
            ClientVfx.burst(level, caster.getX(), caster.getY() + 1.2, caster.getZ(), 10, COLOR, 0.12f, 0.22f, 10);
        }
    }

    @Override
    public void clientTick(Level level, LivingEntity caster) {
        if (caster.tickCount % 6 == 0) {
            ClientVfx.rise(level, caster, COLOR, 1);
        }
    }
}
