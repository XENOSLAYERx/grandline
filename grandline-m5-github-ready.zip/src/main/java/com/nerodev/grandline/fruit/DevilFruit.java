package com.nerodev.grandline.fruit;

import net.minecraft.Util;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;

import java.util.List;

/**
 * A Devil Fruit: a type, 4-6 abilities (put on keys 1..n in this order), passives, a weakness and
 * an awakening. Each fruit class decides how its own abilities and passives work; there is no
 * shared ability template.
 */
public abstract class DevilFruit {

    private final FruitType type;
    private final List<ResourceLocation> abilities;

    protected DevilFruit(FruitType type, List<ResourceLocation> abilities) {
        if (abilities.size() < 1 || abilities.size() > 5) {
            throw new IllegalArgumentException("a fruit has 1-5 key abilities");
        }
        this.type = type;
        this.abilities = List.copyOf(abilities);
    }

    public FruitType type() {
        return type;
    }

    public List<ResourceLocation> abilities() {
        return abilities;
    }

    public ResourceLocation id() {
        return GLFruits.REGISTRY.getKey(this);
    }

    public String descriptionId() {
        return Util.makeDescriptionId("fruit", id());
    }

    public Component displayName() {
        return Component.translatable(descriptionId());
    }

    /** Fruit mastery needed to awaken without Creator tools. */
    public int awakeningMastery() {
        return 100;
    }

    /** Permanent effects while the fruit is held. Must be undone by removePassives. Re-applied on login and respawn. */
    public void applyPassives(ServerPlayer player) {
    }

    public void removePassives(ServerPlayer player) {
    }

    public void onAwaken(ServerPlayer player) {
    }
}
