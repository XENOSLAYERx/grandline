package com.nerodev.grandline.fruit.ability;

import com.nerodev.grandline.ability.Ability;
import com.nerodev.grandline.ability.AbilityPhase;
import com.nerodev.grandline.ability.ActivationType;
import com.nerodev.grandline.client.vfx.ClientVfx;
import com.nerodev.grandline.fruit.Combat;
import com.nerodev.grandline.fruit.FormModifiers;
import com.nerodev.grandline.fruit.FruitIds;
import com.nerodev.grandline.fruit.FruitManager;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;

import java.util.List;

/**
 * TOGGLE (Logia body): your body turns to flame. Attacks from living things pass through you
 * (FruitEvents / LogiaRules), you move faster, and fire cannot touch you.
 * Counters: water breaks it, Armament Haki users still hit you, the world still hurts you, and it
 * drains 6 stamina per second and switches itself off when stamina runs out.
 * Awakened: enemies within 3.5 blocks are set on fire once a second.
 * Costs 15, needs fruit mastery 10.
 */
public final class MeraFlameBodyAbility extends Ability {

    private static final String FORM = "mera_flame_body";
    private static final int ORANGE = 0xFF8A2A;
    private static final int YELLOW = 0xFFD060;

    private static final List<FormModifiers.Spec> SPECS = List.of(
            FormModifiers.spec(Attributes.MOVEMENT_SPEED, "speed", 0.15, AttributeModifier.Operation.ADD_MULTIPLIED_BASE));

    public MeraFlameBodyAbility() {
        super(new Properties()
                .activation(ActivationType.TOGGLE)
                .staminaCost(15)
                .upkeepPerSecond(6.0)
                .cooldown(60)
                .requiresMastery(FruitIds.MASTERY, 10)
                .group(FruitIds.BODY_FORM)
                .awardsMastery(FruitIds.MASTERY));
    }

    @Override
    public void onToggleOn(ServerPlayer player) {
        FormModifiers.apply(player, FORM, SPECS);
        player.clearFire();
    }

    @Override
    public void onToggleOff(ServerPlayer player) {
        FormModifiers.remove(player, FORM, SPECS);
    }

    @Override
    public void onToggleTick(ServerPlayer player) {
        if (player.tickCount % 20 != 0 || !FruitManager.isAwakened(player)) {
            return;
        }
        for (LivingEntity entity : Combat.cone(player, 3.5, 180.0)) {
            entity.igniteForSeconds(3.0f);
        }
    }

    @Override
    public void clientEffects(Level level, LivingEntity caster, AbilityPhase phase, float intensity) {
        double x = caster.getX();
        double y = caster.getY();
        double z = caster.getZ();
        if (phase == AbilityPhase.TOGGLE_ON) {
            ClientVfx.shockwave(level, x, y + 1.0, z, ORANGE, 0.5f, 4.0f, 9);
            ClientVfx.burst(level, x, y + 1.0, z, 22, ORANGE, 0.3f, 0.32f, 14);
            ClientVfx.localFovPunch(caster, 6.0f, 8);
            ClientVfx.localShake(caster, 0.4f, 6);
        } else if (phase == AbilityPhase.TOGGLE_OFF) {
            ClientVfx.burst(level, x, y + 1.0, z, 12, YELLOW, 0.15f, 0.25f, 12);
        }
    }

    @Override
    public void clientTick(Level level, LivingEntity caster) {
        if (caster.tickCount % 2 == 0) {
            ClientVfx.rise(level, caster, ORANGE, 3);
            ClientVfx.rise(level, caster, YELLOW, 1);
        }
    }
}
