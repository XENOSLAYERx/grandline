package com.nerodev.grandline.fruit;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Shared server-side helpers for abilities. Every query runs once when an ability fires (or every
 * few ticks for holds), never per tick for everyone.
 */
public final class Combat {

    public static boolean canTarget(ServerPlayer attacker, LivingEntity target) {
        if (target == attacker || !target.isAlive() || target.isSpectator()) {
            return false;
        }
        if (target instanceof Player && !attacker.server.isPvpAllowed()) {
            return false;
        }
        return !(target instanceof TamableAnimal pet && pet.isOwnedBy(attacker));
    }

    /** Distance from start to the first solid block toward end (or the full distance if clear). */
    public static double blockDistance(ServerLevel level, LivingEntity from, Vec3 start, Vec3 end) {
        var hit = level.clip(new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, from));
        return hit.getType() == HitResult.Type.MISS ? start.distanceTo(end) : start.distanceTo(hit.getLocation());
    }

    /** Entities along the player's look line, nearest first, stopped by walls. */
    public static List<LivingEntity> along(ServerPlayer player, double range, double radius) {
        ServerLevel level = (ServerLevel) player.level();
        Vec3 start = player.getEyePosition();
        Vec3 dir = player.getLookAngle();
        double reach = blockDistance(level, player, start, start.add(dir.scale(range)));
        Vec3 end = start.add(dir.scale(reach));
        AABB box = new AABB(start, end).inflate(radius + 1.0);

        List<LivingEntity> found = new ArrayList<>();
        for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, box, e -> canTarget(player, e))) {
            Vec3 center = entity.getBoundingBox().getCenter();
            double along = center.subtract(start).dot(dir);
            if (along < 0.0 || along > reach + 0.5) {
                continue;
            }
            double off = center.distanceTo(start.add(dir.scale(along)));
            if (off <= radius + entity.getBbWidth() / 2.0) {
                found.add(entity);
            }
        }
        found.sort(Comparator.comparingDouble(e -> e.distanceToSqr(player)));
        return found;
    }

    /** Entities in a cone in front of the player, nearest first. */
    public static List<LivingEntity> cone(ServerPlayer player, double range, double halfAngleDegrees) {
        ServerLevel level = (ServerLevel) player.level();
        Vec3 origin = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        double minCos = Math.cos(Math.toRadians(halfAngleDegrees));

        List<LivingEntity> found = new ArrayList<>();
        for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class,
                player.getBoundingBox().inflate(range + 1.0), e -> canTarget(player, e))) {
            Vec3 to = entity.getBoundingBox().getCenter().subtract(origin);
            double distance = to.length();
            if (distance < 1.0e-4 || distance > range + entity.getBbWidth() / 2.0) {
                continue;
            }
            if (to.scale(1.0 / distance).dot(look) >= minCos) {
                found.add(entity);
            }
        }
        found.sort(Comparator.comparingDouble(e -> e.distanceToSqr(player)));
        return found;
    }

    /** Damages the target as the player. resetInvulnerability lets rapid hits (Gatling, Jet) land every time. */
    public static boolean hit(ServerPlayer attacker, LivingEntity target, float damage, double knockback, boolean resetInvulnerability) {
        if (resetInvulnerability) {
            target.invulnerableTime = 0;
        }
        boolean hurt = target.hurt(attacker.damageSources().playerAttack(attacker), damage);
        if (knockback > 0.0) {
            Vec3 away = target.position().subtract(attacker.position());
            double length = Math.max(1.0e-4, Math.hypot(away.x, away.z));
            // knockback pushes away from the vector it is given, so give it the direction toward the attacker
            target.knockback(knockback, -away.x / length, -away.z / length);
            target.hurtMarked = true;
        }
        return hurt;
    }

    private Combat() {
    }
}
