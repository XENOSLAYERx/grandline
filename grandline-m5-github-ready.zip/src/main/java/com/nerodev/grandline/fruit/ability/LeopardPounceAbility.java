package com.nerodev.grandline.fruit.ability;

import com.nerodev.grandline.ability.Ability;
import com.nerodev.grandline.ability.AbilityPhase;
import com.nerodev.grandline.ability.ActivationType;
import com.nerodev.grandline.client.vfx.ClientVfx;
import com.nerodev.grandline.fruit.Combat;
import com.nerodev.grandline.fruit.FruitIds;
import com.nerodev.grandline.fruit.FruitManager;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * CHARGE: crouch and release to leap where you look, clawing everything in front of you as you
 * launch. A longer charge leaps further and hits harder (4 to 8 damage, double when awakened).
 * Cost 22, cooldown 3.5 s, needs fruit mastery 20.
 */
public final class LeopardPounceAbility extends Ability {

    public LeopardPounceAbility() {
        super(new Properties()
                .activation(ActivationType.CHARGE)
                .charge(4, 18)
                .staminaCost(22)
                .cooldown(70)
                .requiresMastery(FruitIds.MASTERY, 20)
                .awardsMastery(FruitIds.MASTERY));
    }

    @Override
    public boolean executeCharged(ServerPlayer player, float fraction) {
        float damage = (4.0f + 4.0f * fraction) * (FruitManager.isAwakened(player) ? 2.0f : 1.0f);
        List<LivingEntity> hits = Combat.cone(player, 3.8, 40.0);
        int count = Math.min(3, hits.size());
        for (int i = 0; i < count; i++) {
            Combat.hit(player, hits.get(i), damage, 1.0, false);
        }
        Vec3 look = player.getLookAngle();
        double speed = 0.9 + 1.4 * fraction;
        player.setDeltaMovement(look.x * speed, 0.35 + 0.3 * fraction + Math.max(0.0, look.y * 0.4), look.z * speed);
        player.hurtMarked = true;
        player.fallDistance = 0.0f;
        return true;
    }

    @Override
    public void clientEffects(Level level, LivingEntity caster, AbilityPhase phase, float intensity) {
        double x = caster.getX();
        double y = caster.getY();
        double z = caster.getZ();
        if (phase == AbilityPhase.CHARGE_START) {
            ClientVfx.ring(level, x, y + 0.1, z, 0.35f, 12, 0xE8B040, 0.1f, 0.2f, 10);
        } else if (phase == AbilityPhase.CHARGE_RELEASE) {
            ClientVfx.burst(level, x, y + 0.5, z, (int) (10 + 16 * intensity), 0xE8B040, 0.3f + 0.3f * intensity, 0.3f, 12);
            ClientVfx.sparks(level, x, y + 0.8, z, 8, 0xFFE6A0, 0.4f);
            ClientVfx.localShake(caster, 0.3f + 0.5f * intensity, 7);
            ClientVfx.localFovPunch(caster, 8.0f * intensity, 8);
        }
    }
}
