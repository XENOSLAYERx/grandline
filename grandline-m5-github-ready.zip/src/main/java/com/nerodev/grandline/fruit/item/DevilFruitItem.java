package com.nerodev.grandline.fruit.item;

import com.nerodev.grandline.fruit.FruitManager;
import com.nerodev.grandline.fruit.GLFruits;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

/**
 * Eat it to gain the fruit's power. Uses the vanilla eating animation and sound. If the player
 * already holds a fruit the item is NOT consumed. The item only stores which fruit it is; the
 * rules live in FruitManager so eating and Creator commands behave the same.
 */
public class DevilFruitItem extends Item {

    private static final FoodProperties FOOD = new FoodProperties.Builder()
            .nutrition(0)
            .saturationModifier(0.0f)
            .alwaysEdible()
            .build();

    private final ResourceLocation fruitId;

    public DevilFruitItem(ResourceLocation fruitId) {
        super(new Item.Properties().stacksTo(1).food(FOOD));
        this.fruitId = fruitId;
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        if (!level.isClientSide && entity instanceof ServerPlayer player) {
            if (!FruitManager.equip(player, fruitId, false)) {
                return stack; // refused: keep the fruit
            }
            if (!player.getAbilities().instabuild) {
                stack.shrink(1);
            }
        }
        return stack;
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        GLFruits.REGISTRY.getOptional(fruitId).ifPresent(fruit -> {
            tooltip.add(Component.literal(fruit.type().label()).withStyle(ChatFormatting.GOLD));
            tooltip.add(Component.translatable(fruit.descriptionId() + ".desc").withStyle(ChatFormatting.GRAY));
        });
        tooltip.add(Component.literal("Eat it to gain its power. You can only hold one.").withStyle(ChatFormatting.DARK_GRAY));
    }
}
