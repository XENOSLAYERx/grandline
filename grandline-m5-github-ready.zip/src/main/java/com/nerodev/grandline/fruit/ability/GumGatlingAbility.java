package com.nerodev.grandline.fruit.ability;

import com.nerodev.grandline.ability.Ability;
import com.nerodev.grandline.ability.ActivationType;
import com.nerodev.grandline.client.vfx.ClientVfx;
import com.nerodev.grandline.fruit.Combat;
import com.nerodev.grandline.fruit.FruitIds;
import com.nerodev.grandline.fruit.FruitManager;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * HOLD: a flurry of punches in front of you while the key is held, one volley every 3 ticks.
 * Each volley hits up to 3 enemies in a narrow cone (awakened: everything in it). Costs 5 to
 * start and drains 10 stamina per second, so it ends quickly. Needs fruit mastery 20.
 */
public final class GumGatlingAbility extends Ability {

    public GumGatlingAbility() {
        super(new Properties()
                .activation(ActivationType.HOLD)
                .staminaCost(5)
                .upkeepPerSecond(10.0)
                .cooldown(30)
                .requiresMastery(FruitIds.MASTERY, 20)
                .awardsMastery(FruitIds.MASTERY));
    }

    @Override
    public void onHoldTick(ServerPlayer player, int heldTicks) {
        if (heldTicks % 3 != 0) {
            return;
        }
        boolean awakened = FruitManager.isAwakened(player);
        List<LivingEntity> hits = Combat.cone(player, 4.5, 32.0);
        int count = awakened ? hits.size() : Math.min(3, hits.size());
        for (int i = 0; i < count; i++) {
            Combat.hit(player, hits.get(i), awakened ? 3.5f : 2.0f, 0.35, true);
        }
    }

    @Override
    public void clientTick(Level level, LivingEntity caster) {
        Vec3 spot = caster.getEyePosition().add(caster.getLookAngle().scale(2.0)).add(
                (caster.getRandom().nextDouble() - 0.5) * 0.9,
                (caster.getRandom().nextDouble() - 0.5) * 0.7 - 0.3,
                (caster.getRandom().nextDouble() - 0.5) * 0.9);
        ClientVfx.burst(level, spot.x, spot.y, spot.z, 3, 0xFFC7A0, 0.1f, 0.22f, 6);
    }
}
