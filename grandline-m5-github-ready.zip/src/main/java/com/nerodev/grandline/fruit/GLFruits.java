package com.nerodev.grandline.fruit;

import com.nerodev.grandline.GrandLineMod;
import com.nerodev.grandline.registry.GLRegistries;
import net.minecraft.core.Registry;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

/** The fruit registry. Adding a fruit = one class + one line here + its abilities + an item sprite. */
public final class GLFruits {

    public static final Registry<DevilFruit> REGISTRY = GLRegistries.create("fruit");

    private static final DeferredRegister<DevilFruit> FRUITS = DeferredRegister.create(REGISTRY, GrandLineMod.MODID);

    public static final Supplier<DevilFruit> GUM = FRUITS.register("gum", () -> new GumFruit());
    public static final Supplier<DevilFruit> MERA = FRUITS.register("mera", () -> new MeraFruit());
    public static final Supplier<DevilFruit> LEOPARD = FRUITS.register("leopard", () -> new LeopardFruit());

    public static void register(IEventBus modEventBus) {
        FRUITS.register(modEventBus);
    }

    private GLFruits() {
    }
}
